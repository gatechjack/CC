"""MACE execution — order lifecycle over the async OptionsBrokerPort.

This is the safety-critical layer. It owns EVERY side effect that touches money:
the entry credit ladder, the emulated-market exit debit ladder, the resting-GTC
profit-target lifecycle, and the reconcile state machine — plus every `mace_rung`
write. It drives the neutral async `OptionsBrokerPort`; it imports domain +
strategy date-helpers + broker_port + notify only. It NEVER imports
`trading_corp.brokers.*` (that boundary lives in `rh_broker.py`; an AST test
enforces it).

Load-bearing invariants (plan § Behavior specifications):

  FAKE-FILL GUARD (absolute). A booking is written ONLY against a broker order
  whose confirmed terminal state == "filled". An HTTP error, a timeout, an
  exception, a partial fill, or an unconfirmable state NEVER books a fill and
  NEVER places a second order that could double-fill. When execution cannot
  prove what the broker did, it leaves the durable `mace_rung` anchor for the
  reconcile loop and (for exits) escalates URGENT rather than guessing.

  FAKE-CANCEL GUARD (absolute, sibling of the above). A cancellation is believed
  ONLY on a confirmed TERMINAL state read back from `port.order_status` — never
  on `port.cancel` returning, and never on any HTTP response (a 200 on the cancel
  POST included). Before any exit, `close_rung` cancels the resting PT and then
  `_poll_until_terminal` on it: a non-terminal / unconfirmable read-back ABORTS
  the exit (it never places a closing order that could double up against a still-
  live PT). The entry cancel-race and the reconcile drain apply the same rule.
  The cancel-path fix (rh_broker cancels via the order's own server `cancel_url`)
  changes HOW the request is issued; it does NOT relax this guard — the truth is
  always the terminal read-back, not the request.

  MARKETABILITY DIRECTION (trap 6). A CREDIT (entry) order is more marketable at
  a LOWER limit — the entry ladder walks the credit DOWN (mid − offset − k·tick)
  toward marketability, never below the 0.30×width credit floor. A DEBIT (exit)
  order is more marketable at a HIGHER limit — the exit ladder walks the debit UP
  from natural, never above the width×ceiling. The $0.01-credit "unfillable"
  inversion the Phase-0 probe caught is impossible here by construction.

  DETERMINISTIC IDS. Every attempt carries a distinct ref_id derived from the
  rung's deterministic combo_id (`mace-{sym}-{expiry}-{strikes}-{yyyymmdd}`):
  entry `-a{k}`, exit `-x{k}`, PT `-pt`. RH dedupes a repeated ref_id, so a fresh
  id per attempt is required; reconcile matches a crash-orphaned `submitting`
  rung against broker orders by that combo_id prefix.

  CREDIT BASIS. `credit_actual` is the marketable limit of the attempt that
  filled. A net-credit order fills at its limit or better, so this is the
  conservative (never-overstated) credit basis, and it is broker-neutral (no raw
  order-dict parsing crosses the port). It is persisted onto the `submitting`
  anchor BEFORE each place so a crash between fill and promote recovers the right
  credit in reconcile. Realized P&L = (credit_actual − exit_debit)·100·contracts.
"""
from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from datetime import date, datetime, time as dtime
from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP, ROUND_UP
from typing import Callable, Optional, Sequence

from trading_corp.mace import broker_port as bp
from trading_corp.mace.broker_port import OpenOrder, OptionsBrokerPort, OrderResult
from trading_corp.mace.config import MaceConfig
from trading_corp.mace.domain import (
    CondorSpec, OptionQuote, QuoteSnapshot, RungState, iso_week,
    RUNG_ABANDONED, RUNG_CLOSED, RUNG_CLOSING, RUNG_OPEN, RUNG_SUBMITTING,
    EXIT_PT, EXIT_EXPIRED,
)
from trading_corp.mace.disposition import exit_disposition_line
from trading_corp.mace.notify import MaceNotifier
from trading_corp.mace.strategy import business_sessions_between
from trading_corp.utils.time import now_et, now_utc, to_et

_LOG = logging.getLogger("mace.execution")


class MaceRiskRejected(Exception):
    """Raised by the SINGLE place-funnel when the risk gate rejects (or is absent).
    MACE's execution drives the broker port directly and bypasses data_exec /
    ceo_graph, so the per-leg RiskAgent gate threaded through this funnel is MACE's
    ONLY instance of the platform's single-risk-chokepoint invariant. An
    unevaluated / rejected order RAISES here — it is never placed. Enforced
    structurally (an AST test pins every port.place_condor / place_resting_close
    call to the funnel), not by convention."""

# Horizon (business sessions) past which an un-drained `submitting` anchor with
# no fill and no working order is abandoned + alerted (plan § Reconcile loop).
_ABANDON_HORIZON_SESSIONS = 2

# Sentinel: an open-orders sweep could not be read (broker error). The caller treats
# "unknown" as "assume a working order might exist" -> the conservative (fail-closed) branch.
_SWEEP_UNKNOWN = object()


# ── tick rounding ─────────────────────────────────────────────────────────

def round_to_tick(value: float, tick: float, mode: str = "nearest") -> float:
    """Round `value` to the nearest multiple of `tick`.

    All MACE prices are non-negative, so ROUND_UP == ceiling and ROUND_DOWN ==
    floor. `mode`:
      - "down"    — floor to tick (entry credit: never demand more credit than the
                    formula, and floor makes a credit order MORE marketable)
      - "up"      — ceiling to tick (exit debit: the plan's "natural rounded UP to
                    tick", and ceiling makes a debit order MORE marketable)
      - "nearest" — half-up round (PT target)
    """
    if tick <= 0:
        return float(value)
    d = Decimal(str(value)) / Decimal(str(tick))
    if mode == "up":
        n = d.to_integral_value(rounding=ROUND_UP)
    elif mode == "down":
        n = d.to_integral_value(rounding=ROUND_DOWN)
    else:
        n = d.to_integral_value(rounding=ROUND_HALF_UP)
    return float(n * Decimal(str(tick)))


# ── mace_rung persistence (owned here; execution is the ONLY writer) ───────

def _legs_json(spec: CondorSpec) -> str:
    """Serialize the 4 opening legs (type/strike/side/effect). option_id +
    fill_price are unknown at build time (opaque handles never cross the port);
    they stay null — the rung is keyed by the deterministic strikes."""
    legs = [
        {"type": leg.opt_type, "strike": leg.strike, "side": leg.side,
         "effect": leg.effect, "option_id": None, "fill_price": None}
        for leg in spec.opening_legs()
    ]
    return json.dumps(legs)


def _spec_from_legs_json(legs_json_str: Optional[str], symbol: str,
                         expiry_str: str, width_dollars: float) -> CondorSpec:
    """Reconstruct a CondorSpec from a stored legs_json row (mirrors the
    shadow_eval reader). Falls back to a zero-strike placeholder if unparseable
    (non-zero width preserved to avoid div-by-zero downstream)."""
    try:
        legs = json.loads(legs_json_str) if legs_json_str else None
        if isinstance(legs, list) and len(legs) == 4:
            by: dict[tuple[str, str], float] = {}
            for leg in legs:
                t = str(leg.get("type") or leg.get("opt_type") or "").lower()
                s = str(leg.get("side") or "").lower()
                k = leg.get("strike", leg.get("strike_price"))
                if t and s and k is not None:
                    by[(t, s)] = float(k)
            sp, lp = by.get(("put", "sell")), by.get(("put", "buy"))
            sc, lc = by.get(("call", "sell")), by.get(("call", "buy"))
            if None not in (sp, lp, sc, lc):
                return CondorSpec(symbol=symbol, expiry=date.fromisoformat(expiry_str),
                                  short_put=sp, long_put=lp, short_call=sc,
                                  long_call=lc, width_dollars=float(width_dollars))
    except Exception:  # noqa: BLE001 — any parse failure -> placeholder
        pass
    return CondorSpec(symbol=symbol, expiry=date.fromisoformat(expiry_str),
                      short_put=0.0, long_put=0.0, short_call=0.0, long_call=0.0,
                      width_dollars=float(width_dollars))


def _parse_extra(extra_json_str: Optional[str]) -> Optional[dict]:
    """Parse mace_rung.extra_json into a dict (RungState.extra). A NULL column,
    empty string, non-dict, or unparseable JSON -> None (callers treat as {});
    a parse error must never sink a rung load."""
    if not extra_json_str:
        return None
    try:
        obj = json.loads(extra_json_str)
        return obj if isinstance(obj, dict) else None
    except Exception:  # noqa: BLE001 — a malformed extra_json must not sink the load
        return None


_RUNG_COLS = (
    "rung_id, symbol, status, expiry, legs_json, width_dollars, contracts, "
    "credit_actual, max_risk_usd, entry_ts, entry_order_id, pt_order_id, "
    "pt_debit, exit_ts, exit_reason, exit_debit, realized_pnl, entry_iso_week, "
    "extra_json"
)


class RungStore:
    """Thin sqlite persistence for `mace_rung`. Autocommit (the house `db.connect`
    opens with `isolation_level=None`), so every write is durable immediately —
    load-bearing for crash recovery. Tests pass an in-memory connection seeded
    with `db.SCHEMA`."""

    def __init__(self, conn) -> None:
        self.conn = conn

    # -- reads --
    def _row_to_rung(self, r) -> RungState:
        spec = _spec_from_legs_json(r["legs_json"], r["symbol"], r["expiry"],
                                    r["width_dollars"])
        return RungState(
            rung_id=r["rung_id"], symbol=r["symbol"], status=r["status"],
            expiry=date.fromisoformat(r["expiry"]), spec=spec,
            width_dollars=float(r["width_dollars"] or 0.0),
            contracts=int(r["contracts"] or 0),
            credit_actual=_f(r["credit_actual"]), max_risk_usd=_f(r["max_risk_usd"]),
            entry_ts=r["entry_ts"], entry_order_id=r["entry_order_id"],
            pt_order_id=r["pt_order_id"], pt_debit=_f(r["pt_debit"]),
            exit_ts=r["exit_ts"], exit_reason=r["exit_reason"],
            exit_debit=_f(r["exit_debit"]), realized_pnl=_f(r["realized_pnl"]),
            entry_iso_week=r["entry_iso_week"],
            extra=_parse_extra(r["extra_json"]),
        )

    def get(self, rung_id: str) -> Optional[RungState]:
        r = self.conn.execute(
            f"SELECT {_RUNG_COLS} FROM mace_rung WHERE rung_id=?", (rung_id,)
        ).fetchone()
        return self._row_to_rung(r) if r is not None else None

    def load_by_status(self, *statuses: str) -> list[RungState]:
        if not statuses:
            return []
        qs = ",".join("?" * len(statuses))
        rows = self.conn.execute(
            f"SELECT {_RUNG_COLS} FROM mace_rung WHERE status IN ({qs})", statuses
        ).fetchall()
        return [self._row_to_rung(r) for r in rows]

    def load_all(self) -> list[RungState]:
        """Every rung, any status — the strategy derives all per-symbol
        aggregates (open counts, weekly budget, cooldown, realized P&L) from this."""
        rows = self.conn.execute(f"SELECT {_RUNG_COLS} FROM mace_rung").fetchall()
        return [self._row_to_rung(r) for r in rows]

    # -- writes --
    def insert_submitting(self, rung_id: str, spec: CondorSpec, contracts: int,
                          *, entry_ts: str, entry_iso_week: str,
                          max_risk_usd: Optional[float]) -> None:
        """Durable crash-recovery anchor written BEFORE the first place. INSERT OR
        IGNORE so a re-entry of the same session/strikes never clobbers a live
        rung."""
        self.conn.execute(
            "INSERT OR IGNORE INTO mace_rung "
            "(rung_id, symbol, status, expiry, legs_json, width_dollars, contracts, "
            " max_risk_usd, entry_ts, entry_iso_week) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (rung_id, spec.symbol, RUNG_SUBMITTING, spec.expiry.isoformat(),
             _legs_json(spec), float(spec.width_dollars), int(contracts),
             max_risk_usd, entry_ts, entry_iso_week),
        )

    def set_pending_credit(self, rung_id: str, credit_limit: float) -> None:
        """Persist the prospective credit (this attempt's marketable limit) while
        still `submitting`, BEFORE the place, so a crash between fill and promote
        recovers the right credit basis."""
        self.conn.execute(
            "UPDATE mace_rung SET credit_actual=? WHERE rung_id=? AND status=?",
            (credit_limit, rung_id, RUNG_SUBMITTING),
        )

    def set_entry_order(self, rung_id: str, order_id: str) -> None:
        """Persist the BROKER order id the moment `place` returns it (pending or
        filled), so reconcile can `order_status` a real id after a crash. Only the
        broker id is stored here — never the ref/combo_id — so a crash-drain never
        statuses a non-order string."""
        self.conn.execute(
            "UPDATE mace_rung SET entry_order_id=? WHERE rung_id=? AND status=?",
            (order_id, rung_id, RUNG_SUBMITTING),
        )

    def promote_open(self, rung_id: str, *, credit_actual: float,
                     entry_order_id: Optional[str], entry_ts: str,
                     entry_atm_iv: Optional[float] = None) -> None:
        row = self.conn.execute(
            "SELECT width_dollars, contracts FROM mace_rung WHERE rung_id=?",
            (rung_id,)
        ).fetchone()
        w = float(row["width_dollars"]) if row else 0.0
        c = int(row["contracts"]) if row else 0
        max_risk = (w - credit_actual) * 100.0 * c
        # entry_atm_iv (A3): the durable per-rung entry ATM IV, captured ONCE here.
        # Written ONLY when actually available on the fill tick — a None (IV
        # unavailable) leaves the column NULL rather than silently recording a
        # bogus "0 vol"; the T+0 payoff then falls back to the daily IV (labeled).
        if entry_atm_iv is not None:
            self.conn.execute(
                "UPDATE mace_rung SET status=?, credit_actual=?, max_risk_usd=?, "
                "entry_order_id=?, entry_ts=?, entry_atm_iv=? WHERE rung_id=?",
                (RUNG_OPEN, credit_actual, max_risk, entry_order_id, entry_ts,
                 float(entry_atm_iv), rung_id),
            )
        else:
            self.conn.execute(
                "UPDATE mace_rung SET status=?, credit_actual=?, max_risk_usd=?, "
                "entry_order_id=?, entry_ts=? WHERE rung_id=?",
                (RUNG_OPEN, credit_actual, max_risk, entry_order_id, entry_ts, rung_id),
            )

    def set_pt(self, rung_id: str, pt_order_id: str, pt_debit: float) -> None:
        self.conn.execute(
            "UPDATE mace_rung SET pt_order_id=?, pt_debit=? WHERE rung_id=?",
            (pt_order_id, pt_debit, rung_id),
        )

    def set_pt_target(self, rung_id: str, pt_debit: float) -> None:
        """T9 SYNTHETIC PT: record the profit-target debit WITHOUT a resting order
        (pt_order_id stays NULL). The manage loop closes when mark <= pt_debit; the
        dashboard + entry notification read pt_debit."""
        self.conn.execute(
            "UPDATE mace_rung SET pt_debit=? WHERE rung_id=?", (pt_debit, rung_id),
        )

    def set_live_state(self, rung_id: str, symbol: str,
                       mark: Optional[float], spot: Optional[float],
                       ts: str) -> None:
        """UI-rebuild (2026-08-14): upsert this rung's VOLATILE live state
        (per-contract mark + underlying spot) into mace_rung_live for the /mace
        read model. INSERT OR REPLACE keyed on rung_id — one current row per rung,
        no history; the view judges staleness off `ts`. Dashboard write ONLY: it
        never affects an exit decision, and the caller (_manage_one) wraps it
        fail-safe so a write error can never sink a manage tick. mark/spot may be
        None (unpriceable / quote miss) — stored as NULL, which the view renders as
        an honest '—' (never a fabricated number)."""
        self.conn.execute(
            "INSERT OR REPLACE INTO mace_rung_live (rung_id, symbol, mark, spot, ts) "
            "VALUES (?,?,?,?,?)",
            (rung_id, symbol, mark, spot, ts),
        )

    def get_live_state(self, rung_id: str) -> Optional[tuple]:
        """Read the last persisted (mark, ts) for a rung from mace_rung_live, or None if absent.
        Used by the PT mark-trust guard to read the PRIOR tick's mark BEFORE set_live_state overwrites
        it (the guard's timeliness/frozen check). Read-only; mark may be None (unpriceable last tick)."""
        r = self.conn.execute(
            "SELECT mark, ts FROM mace_rung_live WHERE rung_id=?", (rung_id,)
        ).fetchone()
        if r is None:
            return None
        return (_f(r["mark"]), r["ts"])

    def clear_pt(self, rung_id: str) -> None:
        self.conn.execute(
            "UPDATE mace_rung SET pt_order_id=NULL WHERE rung_id=?", (rung_id,)
        )

    def _read_extra(self, rung_id: str) -> dict:
        r = self.conn.execute(
            "SELECT extra_json FROM mace_rung WHERE rung_id=?", (rung_id,)
        ).fetchone()
        return (_parse_extra(r["extra_json"]) or {}) if r is not None else {}

    def _merge_extra(self, rung_id: str, patch: dict) -> None:
        """Read-modify-write a shallow merge into mace_rung.extra_json. A key set to
        None in `patch` is DELETED (so the JSON stays small); other keys overwrite.
        Autocommit + single-threaded manage/reconcile loop -> no lost-update race.
        Preserves unrelated keys (e.g. abandon_detail coexists with a closing block)."""
        cur = self._read_extra(rung_id)
        for k, v in patch.items():
            if v is None:
                cur.pop(k, None)
            else:
                cur[k] = v
        self.conn.execute(
            "UPDATE mace_rung SET extra_json=? WHERE rung_id=?",
            (json.dumps(cur) if cur else None, rung_id),
        )

    def mark_closing(self, rung_id: str, *, exit_reason: Optional[str] = None,
                     ts: Optional[str] = None) -> None:
        """Latch a rung CLOSING (committed marketable close in progress; crash-recoverable).
        2026-10-09: now PERSISTS exit_reason (COALESCE -- a provided reason sets it, None keeps
        the existing so an idempotent re-latch never wipes it) so a re-driven CLOSING rung is no
        longer relabelled 'manual' (reason-amnesia fix), and stamps a one-time closing bookkeeping
        block {since, redrives:0} used by the capped re-drive. The block is written ONLY on the
        FIRST latch (absent-guarded) so _exit_exhausted's idempotent re-calls never reset redrives."""
        if exit_reason is not None:
            self.conn.execute(
                "UPDATE mace_rung SET status=?, exit_reason=? WHERE rung_id=?",
                (RUNG_CLOSING, exit_reason, rung_id))
        else:
            self.conn.execute(
                "UPDATE mace_rung SET status=? WHERE rung_id=?", (RUNG_CLOSING, rung_id))
        if ts is not None and "closing" not in self._read_extra(rung_id):
            self._merge_extra(rung_id, {"closing": {"since": ts, "redrives": 0}})

    def mark_closed(self, rung_id: str, *, exit_reason: str, exit_debit: float,
                    realized_pnl: float, exit_ts: str) -> None:
        self.conn.execute(
            "UPDATE mace_rung SET status=?, exit_reason=?, exit_debit=?, "
            "realized_pnl=?, exit_ts=? WHERE rung_id=?",
            (RUNG_CLOSED, exit_reason, exit_debit, realized_pnl, exit_ts, rung_id),
        )

    def mark_abandoned(self, rung_id: str, detail: str) -> None:
        self.conn.execute(
            "UPDATE mace_rung SET status=? WHERE rung_id=?", (RUNG_ABANDONED, rung_id))
        self._merge_extra(rung_id, {"abandon_detail": detail})

    # -- CLOSING un-latch bookkeeping (2026-10-09 exit-redesign) --------------
    def bump_closing_redrive(self, rung_id: str, ts: str) -> int:
        """Increment and return the CLOSING re-drive counter for a committed close that
        couldn't fill. Initialises the block for a legacy wedged rung that predates it.
        The manager parks the rung once this exceeds max_closing_redrives (bounds the
        pre-2026-10-09 infinite ~15-min re-drive loop)."""
        cur = self._read_extra(rung_id)
        blk = dict(cur.get("closing") or {})
        blk["redrives"] = int(blk.get("redrives") or 0) + 1
        if "since" not in blk:
            blk["since"] = ts
        self._merge_extra(rung_id, {"closing": blk})
        return blk["redrives"]

    def set_closing_parked(self, rung_id: str, ts: str) -> None:
        """Mark a CLOSING rung PARKED (re-drive cap hit): the manager stops the tight
        re-drive and only pulses occasionally, with a single URGENT operator alert."""
        cur = self._read_extra(rung_id)
        blk = dict(cur.get("closing") or {})
        blk["parked"] = ts
        self._merge_extra(rung_id, {"closing": blk})

    def set_exit_order(self, rung_id: str, order_id: str, limit: float,
                       reason: str) -> None:
        """Persist an in-flight exit order id the instant _place returns it (crash-recovery:
        the entry ladder already does this for entries; the exit ladder did not, so a crash
        between place and cancel-confirm orphaned a live close order the DB didn't know about).
        close_rung's preamble polls/cancels a persisted exit order before laddering again."""
        self._merge_extra(rung_id, {"exit_order_id": order_id,
                                    "exit_order_limit": limit, "exit_order_reason": reason})

    def clear_exit_order(self, rung_id: str) -> None:
        self._merge_extra(rung_id, {"exit_order_id": None, "exit_order_limit": None,
                                    "exit_order_reason": None})

    def set_riding(self, rung_id: str, *, why: str, ts: str, detail: str = "") -> None:
        """Mark an OPEN rung RIDING-to-expiry (2026-10-09): a dead-wing OTM winner whose close is
        not executable rides to expiration (Jack's ruling) instead of looping an unfillable close.
        Riding is a DISPOSITION in extra_json, NOT a status -- the rung stays `open` (it is still a
        live position needing stop protection; capacity/reconcile/PnL/UI all key on status)."""
        self._merge_extra(rung_id, {"disposition": "riding",
                                    "ride": {"why": why, "since": ts, "detail": detail}})

    def clear_riding(self, rung_id: str) -> None:
        self._merge_extra(rung_id, {"disposition": None, "ride": None})

    def reopen_from_closing(self, rung_id: str) -> bool:
        """Transition a CLOSING rung back to OPEN -- the un-latch (2026-10-09). Guarded in SQL
        exactly like reports/mace/mace_xle_reset.py: ONLY a rung still `closing` with NO booked
        close (exit_ts / exit_debit / realized_pnl all NULL) is eligible, so a genuinely-closed
        rung can never be reopened. Clears exit_reason + the closing/exit_order bookkeeping.
        Returns True iff exactly one row transitioned (the manager guards the WHEN -- dead wing,
        no working order -- this guards the INVARIANT). Caller sets the riding disposition."""
        cur = self.conn.execute(
            "UPDATE mace_rung SET status=?, exit_reason=NULL WHERE rung_id=? AND status=? "
            "AND exit_ts IS NULL AND exit_debit IS NULL AND realized_pnl IS NULL",
            (RUNG_OPEN, rung_id, RUNG_CLOSING))
        if cur.rowcount == 1:
            self._merge_extra(rung_id, {"closing": None, "exit_order_id": None,
                                        "exit_order_limit": None, "exit_order_reason": None})
            return True
        return False

    def delete_submitting(self, rung_id: str) -> None:
        """Remove a `submitting` anchor after a CLEAN stand-down (every attempt
        confirmed dead, nothing filled, nothing working). Guarded on status so it
        can never delete a promoted/closing rung."""
        self.conn.execute(
            "DELETE FROM mace_rung WHERE rung_id=? AND status=?",
            (rung_id, RUNG_SUBMITTING),
        )


def _f(v) -> Optional[float]:
    if v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# ── outcome records (returned to the manager + asserted in tests) ─────────

@dataclass(frozen=True)
class EntryOutcome:
    rung_id: str
    filled: bool
    credit: Optional[float] = None
    attempts: int = 0
    order_id: Optional[str] = None
    standdown_reason: Optional[str] = None  # cutoff|credit_floor_drift|exhausted|error|unconfirmed|partial|unpriceable


@dataclass(frozen=True)
class ExitOutcome:
    rung_id: str
    closed: bool
    reason: Optional[str] = None
    exit_debit: Optional[float] = None
    realized_pnl: Optional[float] = None
    attempts: int = 0
    exhausted: bool = False   # ladder ran out / unconfirmed / error -> stays CLOSING + URGENT
    pt_race: bool = False     # PT filled during the pre-exit cancel-and-confirm
    aborted: bool = False     # could not confirm PT dead -> refused to double-close
    deferred: bool = False    # winner (TIME>floor / PT) unfilled within mid+band -> stays OPEN, retries


# ── the executor ──────────────────────────────────────────────────────────

class MaceExecutor:
    """Drives the async port through the entry/exit/PT/reconcile lifecycle and
    writes `mace_rung`. Constructed from a MaceConfig + injected port + store +
    notifier (no singletons, no yaml re-reads — the manager owns wiring). Clocks
    and poll cadence are injected for deterministic tests."""

    def __init__(
        self,
        cfg: MaceConfig,
        port: OptionsBrokerPort,
        store: RungStore,
        notifier: MaceNotifier,
        *,
        risk_gate: Optional[Callable[[CondorSpec, int, str], bool]] = None,
        audit: Optional[Callable[..., None]] = None,
        now_utc_fn: Callable[[], datetime] = now_utc,
        now_et_fn: Callable[[], datetime] = now_et,
        poll_interval_s: float = 1.0,
        poll_timeout_s: float = 30.0,
        resting_pt: bool = False,
    ) -> None:
        self.cfg = cfg
        self.port = port
        self.store = store
        self.notifier = notifier
        # PT mechanism (Board ruling 2026-08-10 — go-live on the T9 basis): default
        # FALSE = the T9 SYNTHETIC PT (no resting-GTC order; the manage loop closes
        # when mark <= pt_debit). True = the resting-GTC PT (place_resting_close +
        # reconcile poll). The seam is deliberately contained to a single flag: the
        # cancel-path fix (2026-08-10) proved the LADDER cancel, not a resting order,
        # so resting-GTC PT stays OFF until it is separately proven + re-ruled.
        self._resting_pt = resting_pt
        # The per-leg risk gate: risk_gate(spec, contracts, direction) -> bool.
        # REQUIRED for any placement — None is fail-closed (see _require_risk).
        # The manager builds it from RiskAgent.evaluate over every leg.
        self._risk_gate = risk_gate
        self._audit_fn = audit
        self._now_utc = now_utc_fn
        self._now_et = now_et_fn
        self._poll_interval_s = poll_interval_s
        self._poll_timeout_s = poll_timeout_s
        # Expiry-sweep de-dupe (2026-10-09): rung_ids already alerted as "past expiry with OPEN
        # legs remaining" (possible assignment) so the reconcile sweep warns ONCE, not every tick.
        # In-memory (resets on restart -> at most one re-alert per rung per restart).
        self._expiry_alerted: set[str] = set()

    # -- small helpers --------------------------------------------------------
    def _utc_iso(self) -> str:
        return self._now_utc().isoformat(timespec="seconds")

    def _audit(self, kind: str, **payload) -> None:
        if self._audit_fn is not None:
            try:
                self._audit_fn(kind, **payload)
            except Exception:  # noqa: BLE001 — audit must never break the loop
                _LOG.exception("mace audit hook failed: %s", kind)
        _LOG.info("mace.%s %s", kind, payload)

    async def _sleep(self, secs: float) -> None:
        if secs > 0:
            await asyncio.sleep(secs)

    async def _fresh_quotes(self, spec: CondorSpec) -> dict[str, Optional[OptionQuote]]:
        sp = await self.port.leg_quote(spec.symbol, spec.expiry, "put", spec.short_put)
        lp = await self.port.leg_quote(spec.symbol, spec.expiry, "put", spec.long_put)
        sc = await self.port.leg_quote(spec.symbol, spec.expiry, "call", spec.short_call)
        lc = await self.port.leg_quote(spec.symbol, spec.expiry, "call", spec.long_call)
        return {"sp": sp, "lp": lp, "sc": sc, "lc": lc}

    @staticmethod
    def _credit_mid(q: dict[str, Optional[OptionQuote]]) -> Optional[float]:
        """Net credit at mid = (short mids) − (long mids). None if any leg
        unpriceable. Also the management MARK (cost-to-close at mid)."""
        legs = (q["sp"], q["lp"], q["sc"], q["lc"])
        if any(x is None or x.mid is None for x in legs):
            return None
        return (q["sp"].mid - q["lp"].mid) + (q["sc"].mid - q["lc"].mid)

    @staticmethod
    def _natural_debit(q: dict[str, Optional[OptionQuote]]) -> Optional[float]:
        """Net natural debit to close = buy shorts @ ask, sell wings @ bid. None
        if any required side is missing. STRICT (a no-bid wing -> None): this is the gate's
        executable-closeability basis, so a dead wing must read as uncloseable, not be given away."""
        sp, lp, sc, lc = q["sp"], q["lp"], q["sc"], q["lc"]
        if sp is None or lp is None or sc is None or lc is None:
            return None
        if sp.ask is None or sc.ask is None or lp.bid is None or lc.bid is None:
            return None
        return (sp.ask + sc.ask) - (lp.bid + lc.bid)

    @staticmethod
    def _natural_debit_floored(q: dict[str, Optional[OptionQuote]]) -> Optional[float]:
        """Marketable-EXECUTION natural: buy shorts @ ask, sell wings @ (bid or 0). A dead wing
        (no bid) is GIVEN AWAY at 0 rather than making the close unpriceable, so a COMMITTED close
        (stop/exdiv/gap, or a gated time-floor close) can always price + fill -- the stop-liveness
        fix (2026-10-09). Byte-identical to _natural_debit when both wings are two-sided. None only
        when a SHORT ask is missing (can't buy the short back at all). The STRICT _natural_debit
        remains the gate's basis; only the committed marketable ladder floors."""
        sp, lp, sc, lc = q["sp"], q["lp"], q["sc"], q["lc"]
        if sp is None or sc is None or sp.ask is None or sc.ask is None:
            return None
        lp_bid = lp.bid if (lp is not None and lp.bid is not None) else 0.0
        lc_bid = lc.bid if (lc is not None and lc.bid is not None) else 0.0
        return (sp.ask + sc.ask) - (lp_bid + lc_bid)

    async def quote_snapshot(self, spec: CondorSpec) -> QuoteSnapshot:
        """ONE fresh 4-leg quote fetch per manage tick (2026-10-09). The manager derives mark,
        per-leg mids (guard), and natural/wings (closeability gate) from this SINGLE snapshot, so
        the trigger and the guard can never disagree across two fetches (the old mark()-vs-leg_mids()
        race) and the hot path makes 4 broker calls per rung instead of 8. None-tolerant: a broker
        outage returns an all-None snapshot (+ benign audit), mirroring mark() -- mark becomes None
        (stop/PT skipped, time/exdiv still fire) and the gate reads uncloseable (holds, never closes
        on missing data)."""
        try:
            q = await self._fresh_quotes(spec)
            return QuoteSnapshot(sp=q["sp"], lp=q["lp"], sc=q["sc"], lc=q["lc"])
        except Exception as exc:  # noqa: BLE001 — a broker outage must not sink the manage loop
            self._audit("mace_mark_unavailable", symbol=spec.symbol, error=str(exc))
            return QuoteSnapshot(None, None, None, None)

    async def mark(self, spec: CondorSpec) -> Optional[float]:
        """Per-contract cost-to-close at mid, for the management loop's stop
        compare (strategy owns the precedence; execution owns the fresh quotes).

        P1.4 None-tolerance: an RH session outage returns None broker responses
        whose leg-quote parse `.get`s on None and RAISES (the 8/20 manage-loop
        crashes). Catch it so the tick degrades to a None mark -- evaluate_management
        then skips stop/PT (both guarded on `mark is not None`) but STILL evaluates
        time/exdiv -- instead of crashing per rung. DECISION logic is untouched;
        this only converts a broker-outage crash into a clean None + benign audit."""
        try:
            return self._credit_mid(await self._fresh_quotes(spec))
        except Exception as exc:  # noqa: BLE001 — a broker outage must not sink the manage loop
            self._audit("mace_mark_unavailable", symbol=spec.symbol, error=str(exc))
            return None

    async def leg_mids(self, spec: CondorSpec) -> "dict[str, Optional[float]]":
        """The four per-leg mids {sp,lp,sc,lc} for the PT mark-trust guard's intra-condor leg-sanity
        check (2026-10-02). Fetched by the guard ONLY on a PT-eligible tick (keeps the hot manage
        path untouched). None-tolerant: a broker outage / missing leg -> that key is None (the guard
        skips the inverted-wing comparison for a None leg), mirroring `mark()`'s fail-safe so a quote
        miss never sinks the manage loop."""
        try:
            q = await self._fresh_quotes(spec)
            return {k: (v.mid if v is not None else None) for k, v in q.items()}
        except Exception as exc:  # noqa: BLE001 — a broker outage must not sink the manage loop
            self._audit("mace_mark_unavailable", symbol=spec.symbol, error=str(exc))
            return {"sp": None, "lp": None, "sc": None, "lc": None}

    async def _poll_until_terminal(self, order_id: str) -> Optional[OrderResult]:
        """Poll `order_status` to a terminal state. Returns the terminal
        OrderResult, or the last non-terminal one (or None) if it never confirmed
        within the bounded budget — the caller treats a non-terminal/None return
        as UNCONFIRMED and refuses to place a second order (double-fill guard).
        An exception is swallowed and retried (never books)."""
        polls = max(1, int(self._poll_timeout_s / max(self._poll_interval_s, 1e-9)))
        last: Optional[OrderResult] = None
        for _ in range(polls):
            try:
                r = await self.port.order_status(order_id)
            except Exception as exc:  # noqa: BLE001
                self._audit("mace_poll_error", order_id=order_id, error=str(exc))
                await self._sleep(self._poll_interval_s)
                continue
            last = r
            if r.is_terminal:
                return r
            await self._sleep(self._poll_interval_s)
        return last

    def _pt_debit_for(self, credit: float) -> float:
        return round_to_tick(credit * self.cfg.management.pt_pct_of_credit,
                             self.cfg.execution.entry_tick_usd, mode="nearest")

    def _floor_for(self, spec: CondorSpec) -> float:
        return self.cfg.entry.credit_floor_pct_of_width * spec.width_dollars

    # -- SINGLE RISK CHOKEPOINT (every placement funnels through here) --------
    def _require_risk(self, spec: CondorSpec, contracts: int, direction: str) -> None:
        """The single-chokepoint guard. Fail-CLOSED: a missing gate raises (an
        unevaluated order is never placed), and any leg the gate rejects raises.
        Called by _place / _place_resting BEFORE any broker place — those are the
        ONLY two methods that touch port.place_condor / port.place_resting_close
        (pinned by the AST structural test)."""
        if self._risk_gate is None:
            raise MaceRiskRejected(
                f"{spec.symbol}: no risk gate wired — the MACE single-chokepoint "
                f"invariant refuses to place {direction} x{contracts}")
        try:
            approved = self._risk_gate(spec, contracts, direction)
        except Exception as exc:  # noqa: BLE001 — a gate error is a rejection
            raise MaceRiskRejected(
                f"{spec.symbol}: risk gate raised ({exc}) — refusing to place") from exc
        if not approved:
            raise MaceRiskRejected(
                f"{spec.symbol}: risk gate rejected {direction} x{contracts}")

    async def _place(self, spec: CondorSpec, contracts: int, net_limit: float,
                     combo_id: str, *, direction: str, time_in_force: str,
                     fill_timeout_s: float) -> OrderResult:
        """The ONLY method that calls port.place_condor. Risk-gates every leg first."""
        self._require_risk(spec, contracts, direction)
        return await self.port.place_condor(
            spec, contracts, net_limit, combo_id, direction=direction,
            time_in_force=time_in_force, fill_timeout_s=fill_timeout_s)

    async def _place_resting(self, spec: CondorSpec, contracts: int,
                             net_debit_limit: float, ref_id: str) -> str:
        """The ONLY method that calls port.place_resting_close. Risk-gates first
        (the resting PT is a net-debit close)."""
        self._require_risk(spec, contracts, bp.DIR_DEBIT)
        return await self.port.place_resting_close(spec, contracts, net_debit_limit, ref_id)

    # -- ENTRY LADDER ---------------------------------------------------------
    async def run_entry(self, ev, session_date: date, *,
                        deadline: Optional[datetime] = None,
                        halt_fn: Optional[Callable[[], bool]] = None,
                        entry_atm_iv: Optional[float] = None) -> EntryOutcome:
        """Entry credit ladder (plan § Entry ladder). `ev` is a strategy
        EvalResult with `entered=True` carrying spec/contracts/max_risk_usd.
        Writes the durable `submitting` anchor first, walks the credit DOWN toward
        marketability across ≤ entry_max_attempts, books ONLY on a confirmed
        `filled`, and stands down (no fill = no trade) on floor-drift / cutoff /
        exhaustion. `deadline` (OQ-2) is the manager's per-symbol share of the
        entry window — past it, stand down `window_budget` so later symbols
        still get their turn; the global 15:58 cutoff always wins the reason.
        `halt_fn` is the operator /mace halt latch, re-checked per attempt —
        a resting order still completes its fill-or-cancel cycle (honest
        latency); precedence: cutoff > operator_halt > window_budget."""
        spec: CondorSpec = ev.spec
        contracts: int = ev.contracts
        rung_id = spec.rung_id(session_date)
        x = self.cfg.execution
        floor = self._floor_for(spec)
        cutoff = dtime.fromisoformat(self.cfg.entry.entry_cutoff_et)

        self.store.insert_submitting(
            rung_id, spec, contracts, entry_ts=self._utc_iso(),
            entry_iso_week=iso_week(session_date), max_risk_usd=ev.max_risk_usd)
        self._audit("mace_entry_start", rung_id=rung_id, symbol=spec.symbol,
                    contracts=contracts, strikes=spec.strikes_label())

        last_price: Optional[float] = None
        for k in range(1, x.entry_max_attempts + 1):
            # 15:58 cutoff — SESSION-DATE-AWARE (P1.5). Compare the full ET
            # (date, time) against THIS session's cutoff, not wall-clock time-of-day
            # alone: an off-hours restart can run this after midnight, where a
            # time-only check (00:06 < 15:58) would wrongly PASS and place a
            # STALE-session entry. A clean stand-down deletes the anchor.
            now_dt = self._now_et()
            if (now_dt.date(), now_dt.time()) >= (session_date, cutoff):
                return self._entry_standdown(spec, rung_id, k - 1, last_price,
                                             "cutoff", clean=True)
            # Operator halt latch (/mace HALT button) — before window_budget so a
            # deliberate operator action wins the reason over a passive timeout.
            if halt_fn is not None and halt_fn():
                return self._entry_standdown(spec, rung_id, k - 1, last_price,
                                             "operator_halt", clean=True)
            # OQ-2 window budget (checked AFTER cutoff so the global cutoff always
            # wins the reason) — the manager's per-symbol share of the window ran out.
            if deadline is not None and now_dt.time() >= deadline.time():
                return self._entry_standdown(spec, rung_id, k - 1, last_price,
                                             "window_budget", clean=True)

            quotes = await self._fresh_quotes(spec)
            credit_mid = self._credit_mid(quotes)
            if credit_mid is None:
                self._audit("mace_entry_unpriceable", rung_id=rung_id, attempt=k)
                continue  # bounded by attempts; no place without a fresh price

            raw = credit_mid - x.entry_start_offset_usd - (k - 1) * x.entry_tick_usd
            limit = round_to_tick(raw, x.entry_tick_usd, mode="down")
            if limit < floor:
                # Walking further down would cross the 0.30×width floor — stand down.
                return self._entry_standdown(spec, rung_id, k - 1, last_price,
                                             "credit_floor_drift", clean=True)

            last_price = limit
            combo_id = f"{rung_id}-a{k}"
            # Persist the prospective credit BEFORE placing (crash-recovery basis).
            self.store.set_pending_credit(rung_id, limit)

            try:
                res = await self._place(
                    spec, contracts, limit, combo_id, direction=bp.DIR_CREDIT,
                    time_in_force="gfd", fill_timeout_s=x.entry_fill_wait_sec)
            except MaceRiskRejected as rej:
                # Single-chokepoint catch: risk gate rejected -> NO order placed.
                # Clean stand-down (every prior attempt was confirmed dead).
                self._audit("mace_entry_risk_reject", rung_id=rung_id, attempt=k, detail=str(rej))
                self.notifier.reject(symbol=spec.symbol, detail=f"entry risk-rejected: {rej}")
                return self._entry_standdown(spec, rung_id, k - 1, last_price,
                                             "risk_reject", clean=True)
            except bp.MaceOrderRejected as rej:
                # DEFINITIVE broker reject (no order id -> nothing placed at the
                # broker; e.g. the position_effect collision reject). Unlike an
                # ambiguous error, there is NO order to reconcile -> clean stand-down
                # DELETES the anchor now, freeing the capacity slot THIS session
                # (was: stranded as `submitting` until the 2-session abandon horizon).
                self._audit("mace_entry_rejected", rung_id=rung_id, attempt=k, detail=str(rej))
                self.notifier.reject(symbol=spec.symbol, detail=f"entry rejected: {rej}")
                return self._entry_standdown(spec, rung_id, k - 1, last_price,
                                             "rejected", clean=True)
            except Exception as exc:  # noqa: BLE001
                # FAKE-FILL GUARD: an AMBIGUOUS exception (network/timeout/lost
                # response) NEVER books. The order MIGHT exist at the broker
                # -> leave the anchor for reconcile to drain by combo_id; do NOT
                # delete, do NOT place another. (Definitive rejects are handled
                # above via MaceOrderRejected -> anchor deleted.)
                self._audit("mace_entry_error", rung_id=rung_id, attempt=k, error=str(exc))
                self.notifier.reject(symbol=spec.symbol,
                                     detail=f"entry attempt {k} error: {exc}")
                return EntryOutcome(rung_id, False, attempts=k, order_id=combo_id,
                                    standdown_reason="error")

            # Persist the broker order id the instant we have it (crash-recovery).
            if res.order_id:
                self.store.set_entry_order(rung_id, res.order_id)

            # confirmed filled -> book (the normal in-window fill).
            if res.is_filled:
                return await self._book_entry_fill(rung_id, spec, contracts, limit,
                                                   res, k, entry_atm_iv=entry_atm_iv)
            # a terminal partial = broken structure (naked legs) -> URGENT, never book.
            if self._is_partial(res):
                return self._entry_partial(spec, rung_id, k, res)

            oid = res.order_id
            if oid is not None:
                # not filled in the fill window -> cancel and confirm (cancel race).
                try:
                    await self.port.cancel(oid)
                except Exception as exc:  # noqa: BLE001
                    self._audit("mace_entry_cancel_error", rung_id=rung_id, order_id=oid, error=str(exc))
                confirmed = await self._poll_until_terminal(oid)
                if confirmed is not None and confirmed.is_filled:
                    # Filled in the cancel race — the ONE entry-side manual booking,
                    # guarded by confirmed state == "filled".
                    return await self._book_entry_fill(rung_id, spec, contracts,
                                                       limit, confirmed, k,
                                                       entry_atm_iv=entry_atm_iv)
                if confirmed is not None and self._is_partial(confirmed):
                    return self._entry_partial(spec, rung_id, k, confirmed)
                if confirmed is None or not confirmed.is_terminal:
                    # UNCONFIRMED terminal -> the order may still be live. Placing
                    # another attempt could double-fill. Stand down THIS run;
                    # reconcile owns the anchor. Do NOT delete.
                    self.notifier.reject(
                        symbol=spec.symbol,
                        detail=f"entry attempt {k}: unconfirmed terminal on {oid}; reconcile owns")
                    self._audit("mace_entry_unconfirmed", rung_id=rung_id, attempt=k, order_id=oid)
                    return EntryOutcome(rung_id, False, attempts=k, order_id=oid,
                                        standdown_reason="unconfirmed")
                # confirmed dead (cancelled/rejected) -> next attempt.
            # no order id (and not filled): treat as a spent attempt -> next.

        # attempts exhausted, all confirmed dead -> clean stand-down.
        return self._entry_standdown(spec, rung_id, x.entry_max_attempts, last_price,
                                     "exhausted", clean=True)

    def _entry_standdown(self, spec: CondorSpec, rung_id: str, attempts: int,
                         last_price: Optional[float], reason: str,
                         *, clean: bool) -> EntryOutcome:
        if clean:
            # Every attempt was confirmed dead and nothing filled -> the anchor
            # never became a position; remove it so reconcile doesn't later abandon+alert.
            self.store.delete_submitting(rung_id)
        self.notifier.standdown(symbol=spec.symbol, attempts=attempts,
                                max_attempts=self.cfg.execution.entry_max_attempts,
                                last_price=last_price)
        self._audit("mace_entry_standdown", rung_id=rung_id, reason=reason,
                    attempts=attempts, last_price=last_price)
        return EntryOutcome(rung_id, False, attempts=attempts, standdown_reason=reason)

    def _entry_partial(self, spec: CondorSpec, rung_id: str, k: int,
                       res: OrderResult) -> EntryOutcome:
        # A partially-filled condor is a broken structure — never book it as a
        # clean open. Leave the anchor (reconcile/manual) and escalate URGENT.
        self.notifier.breaker(
            condition=f"{spec.symbol} ENTRY PARTIAL FILL — broken structure",
            lines=[f"rung {rung_id}", f"attempt {k}", f"order {res.order_id}",
                   f"filled {res.processed_quantity}"],
            suggested_action="inspect/flatten the partial legs manually")
        self._audit("mace_entry_partial", rung_id=rung_id, attempt=k,
                    order_id=res.order_id, processed=res.processed_quantity)
        return EntryOutcome(rung_id, False, attempts=k, order_id=res.order_id,
                            standdown_reason="partial")

    async def _book_entry_fill(self, rung_id: str, spec: CondorSpec, contracts: int,
                               credit: float, res: OrderResult, attempts: int,
                               entry_atm_iv: Optional[float] = None) -> EntryOutcome:
        # FAKE-FILL GUARD: only reached with a confirmed state == "filled".
        entry_ts = self._utc_iso()
        self.store.promote_open(rung_id, credit_actual=credit,
                                entry_order_id=res.order_id or rung_id, entry_ts=entry_ts,
                                entry_atm_iv=entry_atm_iv)
        max_risk = (spec.width_dollars - credit) * 100.0 * contracts
        pt_debit = self._pt_debit_for(credit)
        self.notifier.entry(
            symbol=spec.symbol, expiry=spec.expiry.isoformat(),
            sp=spec.short_put, lp=spec.long_put, sc=spec.short_call, lc=spec.long_call,
            contracts=contracts, credit=credit, floor=self._floor_for(spec),
            pt=pt_debit, max_risk=max_risk)
        self._audit("mace_entry_fill", rung_id=rung_id, credit=credit,
                    order_id=res.order_id, attempts=attempts, max_risk=max_risk)
        await self._register_pt(rung_id, spec, contracts, credit, pt_debit=pt_debit)
        return EntryOutcome(rung_id, True, credit=credit, attempts=attempts,
                            order_id=res.order_id)

    async def _register_pt(self, rung_id: str, spec: CondorSpec, contracts: int,
                           credit: float, *, pt_debit: Optional[float] = None) -> None:
        """Set up the profit target after a fill. resting_pt=True places the
        resting-GTC buy-to-close (+ reconcile poll); default (T9 basis) records the
        synthetic target only (pt_order_id stays NULL) and the manage tick closes
        when mark <= pt_debit. Single seam so entry-fill and drain-promote agree."""
        if pt_debit is None:
            pt_debit = self._pt_debit_for(credit)
        if self._resting_pt:
            await self._ensure_pt(rung_id, spec, contracts, credit, pt_debit=pt_debit)
        else:
            self.store.set_pt_target(rung_id, pt_debit)
            self._audit("mace_pt_synthetic", rung_id=rung_id, pt_debit=pt_debit)

    # -- RESTING-GTC PROFIT TARGET -------------------------------------------
    async def _ensure_pt(self, rung_id: str, spec: CondorSpec, contracts: int,
                         credit: float, *, pt_debit: Optional[float] = None) -> Optional[str]:
        """Place (or re-place) the resting GTC buy-to-close at pt_pct×credit. A
        failure alerts (non-urgent) and leaves pt_order_id NULL — the reconcile /
        manage loop re-places it next tick. Never blocks the entry booking."""
        if pt_debit is None:
            pt_debit = self._pt_debit_for(credit)
        ref = f"{rung_id}-pt"
        try:
            pt_id = await self._place_resting(spec, contracts, pt_debit, ref)
        except Exception as exc:  # noqa: BLE001
            self.notifier.reject(symbol=spec.symbol,
                                 detail=f"resting PT placement failed: {exc}; reconcile will retry")
            self._audit("mace_pt_error", rung_id=rung_id, error=str(exc))
            return None
        self.store.set_pt(rung_id, pt_id, pt_debit)
        self._audit("mace_pt_placed", rung_id=rung_id, pt_order_id=pt_id, pt_debit=pt_debit)
        return pt_id

    # -- EXIT: cancel PT first, then the emulated-market debit ladder ---------
    async def close_rung(self, rung: RungState, reason: str, *,
                         pricing: str = "marketable",
                         defer_on_unfilled: bool = False,
                         trigger_mid: Optional[float] = None) -> ExitOutcome:
        """Close a whole condor for a management reason (stop/time/exdiv/gap/pt).
        FIRST cancel-and-confirm the resting PT; if the PT filled in that race,
        book the PT exit and stop. Then walk a DEBIT ladder:
          pricing="marketable" (stop/exdiv/gap/time<=floor): start at NATURAL
              (cross-the-spread), walk UP by tick to the width cap -- a loser/deadline
              MUST fill. exhaustion/unconfirmed/error -> CLOSING + URGENT.
          pricing="winner" (time-exit>floor / PT -- GDX P1 2026-09-11): price at the fresh
              MID and cap the debit at `trigger_mid + exit_winner_band`, where trigger_mid is
              the mid at the MOMENT the exit fired (the manager's decision mark, passed in;
              falls back to the first priceable mid this call). The cap is FIXED for the whole
              ladder -- it does NOT re-anchor to the current mid on later attempts, so an
              adverse re-inflation during the ~2-min walk cannot chase the ceiling up (the
              2026-09-18 fix: pre-fix a PT triggered at ~51% profit could fill at ~22% because
              mid+band rose with the market). Never crosses to natural. A CLEAN no-fill with
              defer_on_unfilled -> DEFER (rung stays OPEN, retries next tick; the trigger
              re-evaluates fresh next cycle and re-anchors to the NEW trigger_mid);
              error/unconfirmed still -> CLOSING + URGENT.
        Never books on error/partial."""
        spec, contracts, rung_id = rung.spec, rung.contracts, rung.rung_id

        # 1) resting PT must be provably dead before we place any closing order.
        if rung.pt_order_id:
            try:
                await self.port.cancel(rung.pt_order_id)
            except Exception as exc:  # noqa: BLE001
                self._audit("mace_pt_cancel_error", rung_id=rung_id,
                            pt_order_id=rung.pt_order_id, error=str(exc))
            confirmed = await self._poll_until_terminal(rung.pt_order_id)
            if confirmed is not None and confirmed.is_filled:
                # PT filled during the race — book the PT exit and STOP (do NOT
                # place a second closing order that would double-fill).
                return self._book_pt_exit(rung)
            if confirmed is None or not confirmed.is_terminal:
                # Cannot prove the PT is dead -> a live PT + a new close would
                # double-fill. Abort this tick, retry next manage tick. URGENT.
                self.notifier.breaker(
                    condition=f"{spec.symbol} EXIT ABORTED — PT not confirmed cancelled",
                    lines=[f"rung {rung_id}", f"pt {rung.pt_order_id}", f"reason {reason}"],
                    suggested_action="verify/cancel the resting PT before close; will retry")
                self._audit("mace_exit_abort_pt_unconfirmed", rung_id=rung_id,
                            pt_order_id=rung.pt_order_id, reason=reason)
                return ExitOutcome(rung_id, False, reason=reason, aborted=True)
            # PT confirmed dead -> proceed.
            self.store.clear_pt(rung_id)

        # 1b) CRASH-RECOVERY (2026-10-09): a persisted in-flight CLOSE order from a prior tick
        # that crashed between place and cancel-confirm. Poll it BEFORE laddering a fresh order
        # (mirrors the resting-PT preamble above): filled -> book + stop; not-provably-dead ->
        # ABORT this tick (a live order must never be doubled); dead -> clear + fresh ladder.
        prior_oid = (rung.extra or {}).get("exit_order_id")
        if prior_oid:
            try:
                await self.port.cancel(prior_oid)
            except Exception as exc:  # noqa: BLE001
                self._audit("mace_exit_cancel_error", rung_id=rung_id, order_id=prior_oid, error=str(exc))
            pconf = await self._poll_until_terminal(prior_oid)
            if pconf is not None and pconf.is_filled:
                lim = (rung.extra or {}).get("exit_order_limit")
                preason = (rung.extra or {}).get("exit_order_reason") or reason
                self.store.clear_exit_order(rung_id)
                return self._book_exit_fill(rung, preason, lim if lim is not None else 0.0)
            if pconf is None or not pconf.is_terminal:
                self.notifier.breaker(
                    condition=f"{spec.symbol} EXIT ABORTED — prior close order not confirmed",
                    lines=[f"rung {rung_id}", f"order {prior_oid}", f"reason {reason}"],
                    suggested_action="verify/cancel the in-flight close before re-driving; will retry")
                self._audit("mace_exit_abort_prior_unconfirmed", rung_id=rung_id,
                            order_id=prior_oid, reason=reason)
                return ExitOutcome(rung_id, False, reason=reason, aborted=True)
            self.store.clear_exit_order(rung_id)  # prior order confirmed dead -> fresh ladder

        # 2) Pricing mode (GDX P1 fix 2026-09-11). WINNER (time-exit>floor / PT) prices at
        # MID and caps the debit at mid + exit_winner_band -- never cross the whole spread
        # on a profitable close. A resting PT (pt_order_id set) is a committed close ->
        # force marketable (a winner-defer must not leave a resting order live).
        x = self.cfg.execution
        m = self.cfg.management
        winner = (pricing == "winner") and not rung.pt_order_id
        band = m.exit_winner_band
        winner_step = band / max(1, x.exit_max_attempts - 1)
        # WINNER cap anchor = the TRIGGER mid (mid at the moment the exit fired), held FIXED
        # for the whole ladder (2026-09-18). None -> captured on the first priceable attempt.
        winner_anchor = trigger_mid if winner else None
        ceiling = spec.width_dollars * x.exit_hard_ceiling_mult_of_width
        # mark CLOSING (crash-recoverable) ONLY on the committed marketable path; a
        # winner-defer stays OPEN so the next manage tick re-evaluates it. 2026-10-09:
        # persist exit_reason + the closing bookkeeping block (reason-amnesia fix + capped re-drive).
        if not winner:
            self.store.mark_closing(rung_id, exit_reason=reason, ts=self._utc_iso())
        saw_reject = False   # a DEFINITIVE broker reject (MaceOrderRejected) happened on some attempt
        self._audit("mace_exit_start", rung_id=rung_id, reason=reason, symbol=spec.symbol,
                    pricing=("winner" if winner else "marketable"),
                    trigger_mid=(round(winner_anchor, 4) if winner_anchor is not None else None),
                    line=exit_disposition_line(spec, reason, phase="start"))

        for k in range(1, x.exit_max_attempts + 1):
            quotes = await self._fresh_quotes(spec)
            if winner:
                # WINNER: price at the fresh MID, walk toward the FIXED trigger-anchored cap
                # across the attempts, HARD-CAP at winner_anchor+band -- NEVER re-anchor the
                # cap to the current mid (2026-09-18), NEVER cross to natural. mid None -> skip.
                mid = self._credit_mid(quotes)
                if mid is None:
                    self._audit("mace_exit_unpriceable", rung_id=rung_id, attempt=k, pricing="winner")
                    continue
                if winner_anchor is None:
                    winner_anchor = mid          # fallback: first priceable mid this call
                raw = min(mid + (k - 1) * winner_step, winner_anchor + band)
                limit = round_to_tick(raw, x.entry_tick_usd, mode="up")
            else:
                # MARKETABLE (committed: stop/exdiv/gap, or a gated time-floor close): natural
                # (cross-the-spread), wings FLOORED to bid-or-0 so a dead wing is given away rather
                # than blocking the close (stop-liveness, 2026-10-09). Walk UP by tick. None (a short
                # has no ask) -> skip.
                natural = self._natural_debit_floored(quotes)
                if natural is None:
                    self._audit("mace_exit_unpriceable", rung_id=rung_id, attempt=k)
                    continue
                raw = natural + (k - 1) * x.entry_tick_usd
                limit = round_to_tick(raw, x.entry_tick_usd, mode="up")
            if limit > ceiling:
                limit = ceiling  # never pay more than max structural value (width)
            combo_id = f"{rung_id}-x{k}"

            try:
                res = await self._place(
                    spec, contracts, limit, combo_id, direction=bp.DIR_DEBIT,
                    time_in_force="gfd", fill_timeout_s=x.exit_fill_wait_sec)
            except MaceRiskRejected as rej:
                # Risk gate blocked the close (unexpected for a risk-reducing close);
                # fail-safe -> stay CLOSING + URGENT, never place.
                self._audit("mace_exit_risk_reject", rung_id=rung_id, attempt=k, detail=str(rej))
                return self._exit_exhausted(spec, rung_id, reason, k)
            except bp.MaceOrderRejected as rej:
                # DEFINITIVE broker reject on THIS attempt -- no order id came back, so NOTHING is
                # resting at the broker (e.g. RH "empty response" on a dead-wing/no-market combo).
                # This is the 2026-10-05 latch mechanism's ROOT: previously it fell to the generic
                # `except` below and immediately _exit_exhausted -> mark_closing, latching EVEN a
                # winner-defer. Now -- mirroring the entry ladder's MaceOrderRejected arm -- the
                # attempt is spent and the ladder CONTINUES; on exhaustion the winner path DEFERS
                # (rung stays OPEN) and the committed path stays CLOSING + capped re-drive. No latch.
                saw_reject = True
                self._audit("mace_exit_rejected", rung_id=rung_id, attempt=k, detail=str(rej))
                continue
            except Exception as exc:  # noqa: BLE001
                # FAKE-FILL GUARD: an AMBIGUOUS error (network/timeout/lost response) -- the order
                # MIGHT be live -> never book, never place another; stay CLOSING + URGENT backstop.
                self._audit("mace_exit_error", rung_id=rung_id, attempt=k, error=str(exc))
                self.notifier.error(loop="exit", exc=exc)
                return self._exit_exhausted(spec, rung_id, reason, k)

            if res.is_filled:
                self.store.clear_exit_order(rung_id)
                return self._book_exit_fill(rung, reason, limit)
            if self._is_partial(res):
                return self._exit_partial(spec, rung_id, reason, k, res)

            oid = res.order_id
            if oid is not None:
                # Persist the in-flight exit order BEFORE cancelling (crash-recovery: a crash here
                # must leave a durable pointer so the next tick's preamble cancels/books it rather
                # than orphaning a live close order the DB never knew about -- the entry ladder has
                # always done this; the exit ladder did not).
                self.store.set_exit_order(rung_id, oid, limit, reason)
                try:
                    await self.port.cancel(oid)
                except Exception as exc:  # noqa: BLE001
                    self._audit("mace_exit_cancel_error", rung_id=rung_id, order_id=oid, error=str(exc))
                confirmed = await self._poll_until_terminal(oid)
                if confirmed is not None and confirmed.is_filled:
                    self.store.clear_exit_order(rung_id)
                    return self._book_exit_fill(rung, reason, limit)
                if confirmed is not None and self._is_partial(confirmed):
                    self.store.clear_exit_order(rung_id)
                    return self._exit_partial(spec, rung_id, reason, k, confirmed)
                if confirmed is None or not confirmed.is_terminal:
                    # unconfirmed -> may still be live; do NOT place another. Leave the persisted
                    # exit_order_id so the next tick's preamble reconciles it (crash-recovery).
                    self._audit("mace_exit_unconfirmed", rung_id=rung_id, attempt=k, order_id=oid)
                    return self._exit_exhausted(spec, rung_id, reason, k)
                # confirmed dead -> clear the persisted pointer, next attempt.
                self.store.clear_exit_order(rung_id)
            # no order id -> next attempt.

        # Ladder exhausted. WINNER-defer: leave the rung OPEN + retry next tick. But if the ladder
        # only ever REJECTED (reject arm, no live order left by design) AND we are deferring, guard
        # the rare "empty response that was actually placed" (robinhood's no-id branch skips the
        # 401/429 reconcile sweep): if a working {rung_id}-x* order is in fact resting, do NOT leave
        # the rung OPEN (PT could re-fire and double-close) -> persist it + exhaust->CLOSING so the
        # preamble/reconcile owns it. Clean sweep -> safe to DEFER. MARKETABLE: stays CLOSING.
        if saw_reject and defer_on_unfilled:
            working = await self._working_exit_order(rung_id)
            if working is not None:
                if working is not _SWEEP_UNKNOWN:
                    self.store.set_exit_order(rung_id, working.order_id, limit, reason)
                return self._exit_exhausted(spec, rung_id, reason, x.exit_max_attempts)
        if defer_on_unfilled:
            return self._exit_deferred(spec, rung_id, reason)
        return self._exit_exhausted(spec, rung_id, reason, x.exit_max_attempts)

    async def _working_exit_order(self, rung_id: str):
        """A working (non-terminal) close order resting on the account for this rung
        (ref_id prefix '{rung_id}-x'), else None. A broker error -> _SWEEP_UNKNOWN sentinel
        (caller treats unknown as 'assume one might exist' -> conservative fail-closed)."""
        try:
            ords = await self.port.open_orders()
        except Exception as exc:  # noqa: BLE001
            self._audit("mace_exit_sweep_error", rung_id=rung_id, error=str(exc))
            return _SWEEP_UNKNOWN
        pref = f"{rung_id}-x"
        for o in ords or []:
            if o.ref_id and o.ref_id.startswith(pref) and str(o.state).lower() not in bp.TERMINAL_STATES:
                return o
        return None

    def _exit_deferred(self, spec: CondorSpec, rung_id: str, reason: str) -> ExitOutcome:
        # WINNER (TIME>floor / PT) could not fill within mid+band -- DEFER rather than force a
        # profit-giving-back cross-the-spread fill (the GDX 2026-09-11 P1). The rung was NOT
        # marked closing, so it stays OPEN; the next manage tick re-evaluates (TIME re-fires at
        # DTE<=time_exit_dte, walking DTE to time_exit_defer_floor_dte where it forces natural;
        # PT re-fires while mark<=pt_target, no floor). The ladder cancelled-and-confirmed each
        # attempt dead before exhausting, so no live order remains.
        self._audit("mace_exit_deferred", rung_id=rung_id, reason=reason, symbol=spec.symbol,
                    detail="winner close unfilled within mid+band -- deferred, retry next tick")
        return ExitOutcome(rung_id, False, reason=reason, deferred=True)

    def _exit_exhausted(self, spec: CondorSpec, rung_id: str, reason: str,
                        attempts: int) -> ExitOutcome:
        # Committed close (marketable, or a winner that hit an error/unconfirmed placement):
        # ensure CLOSING (idempotent -- marketable already marked it; a winner error path did
        # not) so it is crash-recoverable + re-driven. Operator manual action is the backstop.
        # 2026-10-09: persist exit_reason + the closing block (reason-amnesia fix + capped re-drive;
        # idempotent -- COALESCE keeps an already-set reason, the block is only stamped once).
        self.store.mark_closing(rung_id, exit_reason=reason, ts=self._utc_iso())
        self.notifier.close_exhausted(symbol=spec.symbol, expiry=spec.expiry.isoformat(),
                                      contracts=self._contracts_of(rung_id), attempts=attempts)
        self._audit("mace_exit_exhausted", rung_id=rung_id, reason=reason, attempts=attempts)
        # Broker-connect fail-safe (Option B, 2026-09-11): a MACE close that exhausts its
        # ladder is a MISSED EXIT needing manual action -- most acutely when the RH
        # session is down (place raises -> exhaust). Distinct audit kind so it is
        # queryable/alertable alongside the platform-wide broker_missed_exit signal (the
        # operator alert itself is notifier.close_exhausted above). MACE confirms the exit
        # was due (it fired a stop/time/pt/exdiv/gap decision), so this is a CONFIRMED
        # missed exit, not the coarse "risk" alert pmcc/pead raise.
        self._audit("mace_missed_exit", rung_id=rung_id, reason=reason, symbol=spec.symbol,
                    attempts=attempts, detail="exit could not complete -- manual close needed")
        return ExitOutcome(rung_id, False, reason=reason, attempts=attempts, exhausted=True)

    def _exit_partial(self, spec: CondorSpec, rung_id: str, reason: str, k: int,
                      res: OrderResult) -> ExitOutcome:
        self.notifier.breaker(
            condition=f"{spec.symbol} EXIT PARTIAL FILL — broken structure",
            lines=[f"rung {rung_id}", f"attempt {k}", f"order {res.order_id}",
                   f"filled {res.processed_quantity}"],
            suggested_action="inspect/flatten the remaining legs manually")
        self._audit("mace_exit_partial", rung_id=rung_id, attempt=k,
                    order_id=res.order_id, processed=res.processed_quantity)
        return ExitOutcome(rung_id, False, reason=reason, attempts=k, exhausted=True)

    def _contracts_of(self, rung_id: str) -> int:
        r = self.store.get(rung_id)
        return r.contracts if r else 0

    def _book_exit_fill(self, rung: RungState, reason: str, exit_debit: float) -> ExitOutcome:
        credit = rung.credit_actual or 0.0
        realized = (credit - exit_debit) * 100.0 * rung.contracts
        exit_ts = self._utc_iso()
        self.store.mark_closed(rung.rung_id, exit_reason=reason, exit_debit=exit_debit,
                               realized_pnl=realized, exit_ts=exit_ts)
        pct = (realized / (credit * 100.0 * rung.contracts) * 100.0) if credit > 0 and rung.contracts else None
        self.notifier.exit(symbol=rung.symbol, expiry=rung.expiry.isoformat(),
                           contracts=rung.contracts, reason=reason, debit=exit_debit,
                           pnl=realized, pct_of_credit=pct)
        self._audit("mace_exit_fill", rung_id=rung.rung_id, reason=reason,
                    exit_debit=exit_debit, realized=realized, symbol=rung.symbol,
                    line=exit_disposition_line(rung.spec, reason, debit=exit_debit,
                                               realized=realized, pct_of_credit=pct))
        return ExitOutcome(rung.rung_id, True, reason=reason, exit_debit=exit_debit,
                           realized_pnl=realized)

    def _book_pt_exit(self, rung: RungState) -> ExitOutcome:
        credit = rung.credit_actual or 0.0
        pt_debit = rung.pt_debit if rung.pt_debit is not None else self._pt_debit_for(credit)
        realized = (credit - pt_debit) * 100.0 * rung.contracts
        exit_ts = self._utc_iso()
        self.store.mark_closed(rung.rung_id, exit_reason=EXIT_PT, exit_debit=pt_debit,
                               realized_pnl=realized, exit_ts=exit_ts)
        pct = (realized / (credit * 100.0 * rung.contracts) * 100.0) if credit > 0 and rung.contracts else None
        self.notifier.exit(symbol=rung.symbol, expiry=rung.expiry.isoformat(),
                           contracts=rung.contracts, reason=EXIT_PT, debit=pt_debit,
                           pnl=realized, pct_of_credit=pct)
        self._audit("mace_pt_fill", rung_id=rung.rung_id, pt_debit=pt_debit,
                    realized=realized, symbol=rung.symbol,
                    line=exit_disposition_line(rung.spec, EXIT_PT, debit=pt_debit,
                                               realized=realized, pct_of_credit=pct))
        return ExitOutcome(rung.rung_id, True, reason=EXIT_PT, exit_debit=pt_debit,
                           realized_pnl=realized, pt_race=True)

    @staticmethod
    def _is_partial(res: Optional[OrderResult]) -> bool:
        if res is None:
            return False
        if res.state == bp.STATE_PARTIAL:
            return True
        # terminal, not a clean fill, yet some quantity processed = broken structure.
        return res.is_terminal and not res.is_filled and res.processed_quantity > 0

    # -- RECONCILE STATE MACHINE ---------------------------------------------
    async def reconcile(self, session_date: date) -> None:
        """(A) Poll each open rung's resting PT — a confirmed `filled` books the PT
        exit; an unexpected dead PT re-places; a missing PT is re-placed. (B) Drain
        `submitting` anchors (boot/crash): match by deterministic combo_id, promote
        confirmed fills, abandon+alert past the 2-session horizon. Fake-fill guard
        everywhere — an error/exception books nothing."""
        # (0) EXPIRY SWEEP (2026-10-09): ride-to-expiry needs a settlement path, else a riding (or
        # any) rung held past expiry becomes an immortal `open` row poisoning capacity / weekly
        # budget / PnL (the pre-redesign gap). Book an expired-worthless OTM rung at debit 0 (keep
        # the full credit); if same-expiry legs still show on the account, warn ONCE (assignment).
        await self._sweep_expired(session_date)
        # (A) resting-PT lifecycle for open rungs.
        for rung in self.store.load_by_status(RUNG_OPEN):
            try:
                await self._reconcile_open_pt(rung)
            except Exception as exc:  # noqa: BLE001 — one rung must not sink the loop
                self._audit("mace_reconcile_pt_error", rung_id=rung.rung_id, error=str(exc))
                self.notifier.error(loop="reconcile", exc=exc)

        # (B) drain submitting anchors.
        try:
            open_ords = await self.port.open_orders()
        except Exception as exc:  # noqa: BLE001 — no working-order list this tick
            self._audit("mace_reconcile_open_orders_error", error=str(exc))
            open_ords = None
        for rung in self.store.load_by_status(RUNG_SUBMITTING):
            try:
                await self._drain_submitting(rung, open_ords, session_date)
            except Exception as exc:  # noqa: BLE001
                self._audit("mace_reconcile_drain_error", rung_id=rung.rung_id, error=str(exc))
                self.notifier.error(loop="reconcile", exc=exc)

    async def _sweep_expired(self, session_date: date) -> None:
        """Settle OPEN rungs whose expiry has passed (2026-10-09). One open_positions fetch for the
        batch (skip the sweep on a broker error -> retry next tick). Per rung: same-expiry legs still
        on the account -> possible assignment, warn ONCE; otherwise expired worthless OTM -> book."""
        expired = [r for r in self.store.load_by_status(RUNG_OPEN) if r.expiry < session_date]
        if not expired:
            return
        try:
            positions = await self.port.open_positions()
        except Exception as exc:  # noqa: BLE001 — no positions list this tick -> retry next
            self._audit("mace_expiry_sweep_error", error=str(exc))
            return
        for rung in expired:
            try:
                self._settle_expired(rung, positions or [])
            except Exception as exc:  # noqa: BLE001 — one rung must not sink the sweep
                self._audit("mace_expiry_settle_error", rung_id=rung.rung_id, error=str(exc))

    def _settle_expired(self, rung: RungState, positions: "Sequence") -> None:
        exp_iso = rung.expiry.isoformat()
        same_exp = [p for p in positions
                    if (getattr(p, "symbol", "") or "").upper() == rung.symbol.upper()
                    and str((getattr(p, "raw", None) or {}).get("expiration_date") or "") == exp_iso]
        if same_exp:
            # Legs still open at/after expiry -> possible assignment/settlement in flight. A no-HITL
            # engine must NOT guess here: warn ONCE and leave the rung open for manual resolution.
            if rung.rung_id not in self._expiry_alerted:
                self._expiry_alerted.add(rung.rung_id)
                self.notifier.breaker(
                    condition=f"{rung.symbol} rung PAST EXPIRY with {len(same_exp)} open leg(s) — possible assignment",
                    lines=[f"rung {rung.rung_id}", f"expiry {exp_iso}"],
                    suggested_action="verify assignment/settlement + close/book manually")
                self._audit("mace_expiry_legs_remain", rung_id=rung.rung_id, symbol=rung.symbol,
                            expiry=exp_iso, legs=len(same_exp))
            return
        # No same-expiry legs remain -> the condor expired worthless OTM (Jack's ride-to-expiry
        # outcome): book at exit_debit 0, realized = the full credit kept. (A rung that expired ITM
        # would have shown same-expiry legs / been assigned -> the warn branch above, never here.)
        credit = rung.credit_actual or 0.0
        realized = credit * 100.0 * rung.contracts
        self.store.mark_closed(rung.rung_id, exit_reason=EXIT_EXPIRED, exit_debit=0.0,
                               realized_pnl=realized, exit_ts=self._utc_iso())
        self.notifier.exit(symbol=rung.symbol, expiry=exp_iso, contracts=rung.contracts,
                           reason=EXIT_EXPIRED, debit=0.0, pnl=realized, pct_of_credit=100.0)
        self._audit("mace_expired_booked", rung_id=rung.rung_id, symbol=rung.symbol,
                    realized=realized, line=exit_disposition_line(rung.spec, EXIT_EXPIRED))

    async def _reconcile_open_pt(self, rung: RungState) -> None:
        if not self._resting_pt:
            # T9 SYNTHETIC PT: there is NO resting order to poll or re-place — the
            # manage loop owns the PT (mark <= pt_debit). Nothing to reconcile here.
            return
        if not rung.pt_order_id:
            # open with no resting PT (e.g. a prior placement failed) -> place one.
            if rung.credit_actual:
                await self._ensure_pt(rung.rung_id, rung.spec, rung.contracts, rung.credit_actual)
            return
        try:
            r = await self.port.order_status(rung.pt_order_id)
        except Exception as exc:  # noqa: BLE001 — retry next tick, never book on error
            self._audit("mace_reconcile_pt_status_error", rung_id=rung.rung_id, error=str(exc))
            return
        if r.is_filled:
            self._book_pt_exit(rung)
            return
        if r.is_dead:
            # unexpectedly cancelled/rejected -> alert + re-place next.
            self.notifier.reject(symbol=rung.symbol,
                                 detail=f"resting PT {rung.pt_order_id} {r.state}; re-placing")
            self._audit("mace_reconcile_pt_dead", rung_id=rung.rung_id, state=r.state)
            self.store.clear_pt(rung.rung_id)
            if rung.credit_actual:
                await self._ensure_pt(rung.rung_id, rung.spec, rung.contracts, rung.credit_actual)
        # else still working -> leave.

    async def _drain_submitting(self, rung: RungState, open_ords: Optional[Sequence[OpenOrder]],
                                session_date: date) -> None:
        rid = rung.rung_id
        matched_working = []
        if open_ords is not None:
            matched_working = [o for o in open_ords
                               if o.ref_id and o.ref_id.startswith(rid)]

        # Candidate ids to status-check: the stored latest ref + any matched working.
        candidate_ids: list[str] = []
        if rung.entry_order_id:
            candidate_ids.append(rung.entry_order_id)
        for o in matched_working:
            if o.order_id not in candidate_ids:
                candidate_ids.append(o.order_id)

        filled: Optional[OrderResult] = None
        any_working = False
        for oid in candidate_ids:
            try:
                r = await self.port.order_status(oid)
            except Exception as exc:  # noqa: BLE001 — unknown -> treat as in-flight (safe)
                self._audit("mace_drain_status_error", rung_id=rid, order_id=oid, error=str(exc))
                any_working = True
                continue
            if r.is_filled:
                filled = r
                break
            if not r.is_terminal:
                any_working = True

        if filled is not None:
            credit = rung.credit_actual  # prospective limit stored per attempt
            if credit is None:
                # Filled but no credit basis recorded -> can't book safely. URGENT.
                self.notifier.breaker(
                    condition=f"{rung.symbol} FILLED on reconcile but credit basis unknown",
                    lines=[f"rung {rid}", f"order {filled.order_id}"],
                    suggested_action="set credit_actual / book manually")
                self._audit("mace_drain_no_credit", rung_id=rid, order_id=filled.order_id)
                return
            entry_ts = rung.entry_ts or self._utc_iso()
            self.store.promote_open(rid, credit_actual=credit,
                                    entry_order_id=filled.order_id or rung.entry_order_id,
                                    entry_ts=entry_ts)
            max_risk = (rung.spec.width_dollars - credit) * 100.0 * rung.contracts
            self.notifier.entry(
                symbol=rung.symbol, expiry=rung.expiry.isoformat(),
                sp=rung.spec.short_put, lp=rung.spec.long_put,
                sc=rung.spec.short_call, lc=rung.spec.long_call,
                contracts=rung.contracts, credit=credit, floor=self._floor_for(rung.spec),
                pt=self._pt_debit_for(credit), max_risk=max_risk)
            self._audit("mace_drain_promote", rung_id=rid, credit=credit, order_id=filled.order_id)
            await self._register_pt(rid, rung.spec, rung.contracts, credit)
            return

        if any_working or matched_working:
            return  # still in flight -> leave the anchor.

        # Nothing filled, nothing working -> abandon past the horizon (+ alert).
        entry_dt = to_et(rung.entry_ts)
        entry_date = entry_dt.date() if entry_dt else session_date
        if business_sessions_between(entry_date, session_date) > _ABANDON_HORIZON_SESSIONS:
            self.store.mark_abandoned(rid, "submitting past 2-session horizon; no fill")
            self.notifier.reject(symbol=rung.symbol,
                                 detail=f"rung {rid} abandoned — no fill past {_ABANDON_HORIZON_SESSIONS}-session horizon")
            self._audit("mace_drain_abandon", rung_id=rid, entry_date=entry_date.isoformat())
        # else within horizon -> leave for a later tick.
