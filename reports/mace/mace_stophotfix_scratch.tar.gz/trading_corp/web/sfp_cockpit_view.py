"""Bitunix SFP Cockpit — FastAPI routes + queries (data-readiness disciplined).

Wire-up (one line in trading_corp/web/routes.py `register(app)`):

    from trading_corp.web import sfp_cockpit_view
    sfp_cockpit_view.register(app)

Routes (all HTMX fragment-polled ~5s by the shell):

    GET /sfp                          full cockpit page (shell)
    GET /sfp/partials/header          TIER C badge + TIER A summary
    GET /sfp/partials/recon           TIER A win/avg-R  + TIER B bos-confirm
    GET /sfp/partials/state-board     TIER A bar-strips + TIER C position + TIER B armed-watch
    GET /sfp/partials/mode-split      TIER A (REAL vs CONSIDERABLE)
    GET /sfp/partials/near-miss       TIER B mock
    GET /sfp/partials/equity          TIER A equity / cum-R

★ DATA-READINESS DISCIPLINE — the whole point of this module:
  - TIER A  : reads real sources NOW. Renders an HONEST EMPTY state until rows
              exist (SFP just went live with ZERO closed trades → "—", never a
              fabricated number). Templates get `has_data: bool`.
  - TIER B  : NO real source yet (needs an observer watch-state emit). Served by
              `_mock_*()` functions, clearly named, and the template paints a
              dashed MOCK ribbon. A placeholder can NEVER read as live truth.
  - TIER C  : DANGEROUS. Every query is scoped STRICTLY to division='bitunix_sfp'
              — NEVER the shared bitunix account snapshot or corp-wide events
              (that cross-division bleed caused a false alarm). No position → an
              honest 'no SFP position' state, never borrowed from another division.
              The LIVE/PAPER badge reads ACTUAL runtime (broker.paper + auto_execute).

Every panel's context dict carries `tier` ("A"|"B"|"C") and (for B) `mock=True`
so the template renders the correct ribbon/badge.
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse

from trading_corp.persistence import db

log = logging.getLogger(__name__)

DIVISION = "bitunix_sfp"
TP_R = 3.0                                   # construct target (retargeted from 2.0, 2026-07-10)
# ── forward scoreboard epoch (net-basis boundary, 2026-07-13 00:00 UTC) ──
# Moved forward from the 2026-07-11 RD-gate epoch to the 2026-07-13 net-basis boundary: at the
# 2026-07-12->13 seam actual_pnl_dollars / actual_r_multiple switched GROSS->NET (net-post-fee booking),
# so a pre-boundary close books on gross and a post-boundary close on net — non-comparable. The forward
# scoreboard — W-L record, realized-R / equity curve, the n/30 verdict gate, and the quality-gate funnel
# counts — is scoped to closes/events AT OR AFTER this epoch so every counted trade shares ONE (net)
# accounting basis. Pre-epoch trades (incl. the two 2026-07-12 gross closes + the -1.07R BTC construct
# close) REMAIN in paper_trade_record / research_log — EXCLUDED from the forward count, NOT deleted (a
# "count from T" filter, never fabricated data). Defined ONCE here; sfp_construct_cockpit_view IMPORTS
# it so BOTH cockpits scope to the SAME epoch and can never drift out of agreement. (No SFP close exists
# between 2026-07-12 14:47 and 2026-07-14 12:25, so the exact 07-13 time is invariant for the counts.)
COCKPIT_STATS_SINCE = "2026-07-13T00:00:00+00:00"
COCKPIT_STATS_SINCE_LABEL = "2026-07-13 · net-basis epoch (PnL/R switched gross→net; ROI% now on margin)"
CONSTRUCT_SINCE = COCKPIT_STATS_SINCE         # back-compat alias (was construct go-live 2026-07-10)
BASELINE_AVG_R = 0.182                        # in-sample pooled backtest benchmark (GROSS)
BASELINE_WIN_PCT = 30                         # backtest win-rate @3R (pooled flat-3R)
SIG_N = 30                                    # verdict (tracking/diverging) only meaningful at n>=30
# Display symbol -> bitunix_bar_history.symbol (wire) key. Keep in one place.
SYMBOLS: dict[str, str] = {
    "BTC": "BTCUSDT", "ETH": "ETHUSDT", "SOL": "SOLUSDT", "XRP": "XRPUSDT",
}
LIVE_SYMBOL = "BTC"                          # the only live-trading coin today
TF = "15m"
_STRAT_YAML = Path(__file__).resolve().parents[2] / "config" / "strategies.yaml"


# ──────────────────────────────────────────────────────────────────────────
# small helpers
# ──────────────────────────────────────────────────────────────────────────
def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _day_start_iso() -> str:
    n = _utc_now()
    return n.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()


def _week_start_iso() -> str:
    n = _utc_now()
    monday = (n - timedelta(days=n.weekday())).replace(
        hour=0, minute=0, second=0, microsecond=0)
    return monday.isoformat()


def _loads(s: Any) -> dict:
    if not s:
        return {}
    try:
        return json.loads(s)
    except (TypeError, ValueError):
        return {}


# ──────────────────────────────────────────────────────────────────────────
# TIER C — runtime LIVE/PAPER truth (NOT a static label; NOT record bookkeeping)
# ──────────────────────────────────────────────────────────────────────────
def _yaml_auto_execute() -> bool | None:
    """Fresh-read bitunix_sfp.auto_execute (the hot kill switch). None if unreadable."""
    try:
        import yaml
        with open(_STRAT_YAML, encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}
        return bool((raw.get(DIVISION) or {}).get("auto_execute", False))
    except Exception as e:                                    # noqa: BLE001
        log.warning("sfp_cockpit: auto_execute read failed: %s", e)
        return None


def runtime_badge(deps: Any) -> dict:
    """TIER C — the ACTUAL per-division runtime state, venue/runtime truth.

    Reads the live broker registered for division='bitunix_sfp' (its `paper`
    flag) AND the hot `auto_execute` switch. Renders LIVE only when the broker
    is real AND armed; otherwise a precise non-live reason. Never a static label.
    """
    broker = None
    dx = getattr(deps, "data_exec", None)
    brokers = getattr(dx, "brokers", None) if dx is not None else None
    if isinstance(brokers, dict):
        broker = brokers.get(DIVISION)
    paper = bool(getattr(broker, "paper", True)) if broker is not None else True
    broker_present = broker is not None
    auto = _yaml_auto_execute()
    armed = bool(auto)
    live = broker_present and (not paper) and armed
    if live:
        state, label, sub = "live", "LIVE", "REAL CAPITAL"
    elif not broker_present:
        state, label, sub = "unwired", "NO BROKER", "division not registered"
    elif paper:
        state, label, sub = "paper", "PAPER", "broker paper=True"
    elif not armed:
        state, label, sub = "disarmed", "DISARMED", "auto_execute=false"
    else:
        state, label, sub = "unknown", "UNKNOWN", "indeterminate"
    return {
        "tier": "C", "state": state, "label": label, "sub": sub,
        "paper": paper, "auto_execute": auto, "broker_present": broker_present,
    }


def _symbol_arm_map() -> dict[str, str]:
    """Display symbol -> arm ('trading'|'watch') from bitunix_sfp.symbol_modes
    (Mode B, 2026-06-28). Maps the YAML display key ('BTC/USDT.P') back to the
    short display ('BTC'). Absent/unreadable -> {} (every coin renders MONITOR
    until the config says otherwise). This is the SINGLE source of which coins
    are armed live vs watch-only — no hardcoded coin list."""
    try:
        import yaml
        with open(_STRAT_YAML, encoding="utf-8") as f:
            raw = (yaml.safe_load(f) or {}).get(DIVISION) or {}
        out: dict[str, str] = {}
        for key, spec in (raw.get("symbol_modes") or {}).items():
            short = str(key).split("/")[0].upper()
            if short in SYMBOLS and isinstance(spec, dict):
                arm = str(spec.get("arm", "watch")).lower()
                out[short] = arm if arm in ("trading", "watch") else "watch"
        return out
    except Exception as e:                                    # noqa: BLE001
        log.warning("sfp_cockpit: symbol_modes read failed: %s", e)
        return {}


def _live_count(deps: Any) -> int:
    """How many coins are ACTUALLY live: arm:trading AND the division runtime is
    live (broker real + auto_execute). 0 if the division isn't live."""
    if runtime_badge(deps).get("state") != "live":
        return 0
    return sum(1 for a in _symbol_arm_map().values() if a == "trading")


# ──────────────────────────────────────────────────────────────────────────
# TIER A — closed-trade metrics (HONEST EMPTY until rows exist)
# ──────────────────────────────────────────────────────────────────────────
def _closed_metrics(db_url: str) -> dict:
    """TIER A. Win@2R / avg-R / today / week / cum-R from CLOSED SFP trades.

    SQL (scoped to division='bitunix_sfp', resolved trades only):

        SELECT COUNT(*) n,
               SUM(result='win') wins,
               AVG(actual_r_multiple) avg_r,
               SUM(actual_r_multiple) cum_r
        FROM paper_trade_record
        WHERE division='bitunix_sfp' AND result IN ('win','loss');

    Reads EMPTY today (SFP has no closed trades) → has_data=False → honest "—".
    """
    with db.connect(db_url) as conn:
        agg = conn.execute(
            "SELECT COUNT(*) AS n, "
            "SUM(CASE WHEN result='win' THEN 1 ELSE 0 END) AS wins, "
            "AVG(actual_r_multiple) AS avg_r, "
            "SUM(actual_r_multiple) AS cum_r "
            "FROM paper_trade_record "
            "WHERE division=? AND result IN ('win','loss') AND result_ts >= ?",
            (DIVISION, CONSTRUCT_SINCE),
        ).fetchone()
        # today/week rolling-R are ALSO floored at the epoch (max with the day/week start) so a
        # pre-epoch close in the current day/week (e.g. the -1.07R) never leaks into the reset scoreboard.
        today_r = conn.execute(
            "SELECT SUM(actual_r_multiple) AS r FROM paper_trade_record "
            "WHERE division=? AND result IN ('win','loss') AND result_ts >= ?",
            (DIVISION, max(_day_start_iso(), COCKPIT_STATS_SINCE)),
        ).fetchone()
        week_r = conn.execute(
            "SELECT SUM(actual_r_multiple) AS r FROM paper_trade_record "
            "WHERE division=? AND result IN ('win','loss') AND result_ts >= ?",
            (DIVISION, max(_week_start_iso(), COCKPIT_STATS_SINCE)),
        ).fetchone()
    n = int(agg["n"] or 0)
    return {
        "tier": "A", "has_data": n > 0, "n": n,
        "significant": n >= SIG_N, "need": SIG_N,            # verdict gate — no cry-wolf below n=30
        "win_pct": (round(100 * (agg["wins"] or 0) / n) if n else None),
        "avg_r": (round(agg["avg_r"], 2) if agg["avg_r"] is not None else None),
        "cum_r": (round(agg["cum_r"], 1) if agg["cum_r"] is not None else None),
        "today_r": (round(today_r["r"], 1) if today_r["r"] is not None else None),
        "week_r": (round(week_r["r"], 1) if week_r["r"] is not None else None),
        "baseline_avg_r": BASELINE_AVG_R, "baseline_win_pct": BASELINE_WIN_PCT, "tp_r": TP_R,
        "stats_since_label": COCKPIT_STATS_SINCE_LABEL,
    }


def _mode_split(db_url: str) -> dict:
    """TIER A. REAL vs CONSIDERABLE, tracked separately. Mode from
    extra_json.$.sfp_mode (the observer writes 'REAL'/'CONSIDERABLE').

        SELECT json_extract(extra_json,'$.sfp_mode') mode,
               COUNT(*) n, SUM(result='win') wins, AVG(actual_r_multiple) avg_r
        FROM paper_trade_record
        WHERE division='bitunix_sfp' AND result IN ('win','loss')
        GROUP BY mode;
    """
    out = {"REAL": {"n": 0, "win_pct": None, "avg_r": None},
           "CONSIDERABLE": {"n": 0, "win_pct": None, "avg_r": None}}
    with db.connect(db_url) as conn:
        rows = conn.execute(
            "SELECT json_extract(extra_json,'$.sfp_mode') AS mode, "
            "COUNT(*) AS n, "
            "SUM(CASE WHEN result='win' THEN 1 ELSE 0 END) AS wins, "
            "AVG(actual_r_multiple) AS avg_r "
            "FROM paper_trade_record "
            "WHERE division=? AND result IN ('win','loss') AND result_ts >= ? GROUP BY mode",
            (DIVISION, CONSTRUCT_SINCE),
        ).fetchall()
    for r in rows:
        mode = (r["mode"] or "").upper()
        if mode in out and r["n"]:
            out[mode] = {
                "n": int(r["n"]),
                "win_pct": round(100 * (r["wins"] or 0) / r["n"]),
                "avg_r": round(r["avg_r"], 2) if r["avg_r"] is not None else None,
            }
    has = out["REAL"]["n"] + out["CONSIDERABLE"]["n"] > 0
    return {"tier": "A", "has_data": has, "modes": out}


def _equity_curve(db_url: str) -> dict:
    """TIER A. Cumulative-R equity curve from closed SFP trades, time-ordered.

        SELECT result_ts, actual_r_multiple FROM paper_trade_record
        WHERE division='bitunix_sfp' AND result IN ('win','loss')
              AND actual_r_multiple IS NOT NULL
        ORDER BY result_ts ASC;
    """
    with db.connect(db_url) as conn:
        rows = conn.execute(
            "SELECT result_ts, actual_r_multiple AS r FROM paper_trade_record "
            "WHERE division=? AND result IN ('win','loss') AND result_ts >= ? "
            "AND actual_r_multiple IS NOT NULL ORDER BY result_ts ASC",
            (DIVISION, CONSTRUCT_SINCE),
        ).fetchall()
    cum, pts = 0.0, []
    for r in rows:
        cum += float(r["r"])
        pts.append(round(cum, 3))
    line_d, area_d = _spark_paths(pts)
    return {"tier": "A", "has_data": bool(pts), "n_closed": len(pts),
            "cum_r": round(cum, 1) if pts else None, "points": pts,
            "line_d": line_d, "area_d": area_d,
            "stats_since_label": COCKPIT_STATS_SINCE_LABEL}


def _spark_paths(pts: list[float], w: float = 340.0, h: float = 90.0) -> tuple[str, str]:
    """Build (line, area) SVG path strings for the equity sparkline. Empty -> ('','')."""
    if len(pts) < 2:
        return "", ""
    lo, hi = min(pts), max(pts)
    rng = (hi - lo) or 1.0
    pad = 6.0
    step = w / (len(pts) - 1)
    xy = [(round(i * step, 1), round(pad + (hi - p) / rng * (h - 2 * pad), 1))
          for i, p in enumerate(pts)]
    line = "M" + " L".join(f"{x},{y}" for x, y in xy)
    area = line + f" L{xy[-1][0]},{h} L{xy[0][0]},{h} Z"
    return line, area


def _bar_strip(db_url: str, wire: str, n: int = 40) -> list[dict]:
    """TIER A. Latest N 15m bars for ONE symbol (symbol-keyed — filter symbol).

        SELECT ts_ms, open, high, low, close FROM bitunix_bar_history
        WHERE symbol=? AND timeframe='15m' ORDER BY ts_ms DESC LIMIT ?;
    """
    with db.connect(db_url) as conn:
        rows = conn.execute(
            "SELECT ts_ms, open, high, low, close FROM bitunix_bar_history "
            "WHERE symbol=? AND timeframe=? ORDER BY ts_ms DESC LIMIT ?",
            (wire, TF, n),
        ).fetchall()
    return [{"ts_ms": r["ts_ms"], "o": r["open"], "h": r["high"],
             "l": r["low"], "c": r["close"]} for r in reversed(rows)]


def _latest_close(db_url: str, wire: str) -> float | None:
    with db.connect(db_url) as conn:
        r = conn.execute(
            "SELECT close FROM bitunix_bar_history WHERE symbol=? AND timeframe=? "
            "ORDER BY ts_ms DESC LIMIT 1", (wire, TF),
        ).fetchone()
    return float(r["close"]) if r else None


def _loop_heartbeat(db_url: str, wire: str) -> dict:
    """Loop heartbeat — best-effort PROXY (latest bar inserted_at age).

    NOTE: this is the bar-archiver's freshness, NOT a true SFP-loop tick. A real
    'loop last evaluated' needs an observer heartbeat emit (agent_state write per
    process_once). Marked proxy=True so the UI labels it honestly.
    """
    with db.connect(db_url) as conn:
        r = conn.execute(
            "SELECT inserted_at FROM bitunix_bar_history WHERE symbol=? AND timeframe=? "
            "ORDER BY ts_ms DESC LIMIT 1", (wire, TF),
        ).fetchone()
    if not r or not r["inserted_at"]:
        return {"proxy": True, "age_min": None, "stale": True}
    try:
        ts = datetime.fromisoformat(str(r["inserted_at"]).replace("Z", "+00:00"))
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        age_min = int((_utc_now() - ts).total_seconds() // 60)
    except Exception:                                        # noqa: BLE001
        return {"proxy": True, "age_min": None, "stale": True}
    return {"proxy": True, "age_min": age_min, "stale": age_min is None or age_min > 20}


# ──────────────────────────────────────────────────────────────────────────
# TIER C — open SFP position (STRICTLY division='bitunix_sfp'; no shared fallback)
# ──────────────────────────────────────────────────────────────────────────
def _open_sfp_positions(db_url: str) -> dict[str, dict]:
    """TIER C. ALL open SFP positions, keyed by DISPLAY symbol (BTC/ETH/SOL/XRP)
    — scoped HARD to division='bitunix_sfp'. The platform invariant is 1 open
    trade PER COIN (max 4/division), so concurrent opens (e.g. XRP + ETH) are
    VALID and must EACH render on their own coin card. The prior single-row
    lookup (ORDER BY ts DESC LIMIT 1) collapsed the board to the newest open
    position division-wide, so a second concurrent position dropped off; this
    resolves ONE slot PER COIN instead (keyed by (division, symbol)).

        SELECT order_id, symbol, side, qty, entry_reference_price, stop_price,
               tp_price, tp_r_multiple, extra_json, ts, execution_mode
        FROM paper_trade_record
        WHERE division='bitunix_sfp' AND result IS NULL
        ORDER BY ts DESC;                 -- newest-first; first row per coin wins

    NO fallback to the shared bitunix account snapshot or corp-wide events. A coin
    absent from the returned map → the caller renders 'no SFP position' for it.
    """
    with db.connect(db_url) as conn:
        rows = conn.execute(
            "SELECT order_id, symbol, side, qty, entry_reference_price, stop_price, "
            "tp_price, tp_r_multiple, extra_json, ts, execution_mode "
            "FROM paper_trade_record "
            "WHERE division=? AND result IS NULL ORDER BY ts DESC",
            (DIVISION,),
        ).fetchall()
    out: dict[str, dict] = {}
    for r in rows:
        # normalize wire ('ETHUSDT') or display ('ETH/USDT.P') symbol -> short 'ETH'
        key = str(r["symbol"]).upper().split("/")[0].replace("USDT", "")
        if key not in SYMBOLS or key in out:     # one-per-coin: keep first (newest ts)
            continue
        # ref-vs-fill (2026-07-07): prefer the ACTUAL entry fill VWAP (persisted by
        # the observer as extra['actual_entry_fill_price']) so the entry line + R
        # reflect the real fill, not the 3m-BOS signal reference. Fall back to the
        # reference for pre-fix / paper rows (matches the reconciler's
        # _resolve_entry_price). Stop + TP stay the real venue bracket levels.
        _extra = _loads(r["extra_json"])
        _fill = _extra.get("actual_entry_fill_price")
        try:
            _entry = float(_fill) if (_fill is not None and float(_fill) > 0) \
                else r["entry_reference_price"]
        except (TypeError, ValueError):
            _entry = r["entry_reference_price"]
        out[key] = {
            "order_id": r["order_id"], "symbol": r["symbol"], "side": r["side"],
            "qty": r["qty"], "entry": _entry, "entry_ref": r["entry_reference_price"],
            "stop": r["stop_price"],
            "tp": r["tp_price"], "tp_r": r["tp_r_multiple"], "ts": r["ts"],
            "execution_mode": r["execution_mode"], "extra": _extra,
        }
    return out


def _r_journey(db_url: str, pos: dict) -> dict:
    """TIER A. R-journey for the open SFP position. entry/stop from the row,
    target = entry + 2R, current = latest 15m close (symbol-keyed), MFE = running
    max((high-entry)/R) since entry. CSS handles the ~5s easing — no JS loop."""
    wire = pos["symbol"]
    # accept either wire ('BTCUSDT') or display ('BTC/USDT.P' -> map) symbols
    if wire not in SYMBOLS.values():
        wire = SYMBOLS.get(str(pos["symbol"]).split("/")[0].upper(), wire)
    entry = float(pos["entry"] or 0.0)
    stop = float(pos["stop"] or 0.0)
    r_unit = entry - stop                       # long: positive
    target = float(pos["tp"] or (entry + TP_R * r_unit))
    current = _latest_close(db_url, wire)
    out = {"tier": "A", "symbol": pos["symbol"], "entry": entry, "stop": stop,
           "target": target, "current": current, "r_unit": r_unit,
           "unreal_r": None, "mfe_r": None, "to_target_pct": None,
           "to_stop_pct": None, "marker_pos": None, "crossed_breakeven": None}
    if current is None or r_unit <= 0:
        return out
    out["unreal_r"] = round((current - entry) / r_unit, 2)
    out["crossed_breakeven"] = current >= entry
    out["to_target_pct"] = (round(100 * (current - entry) / (target - entry))
                            if target > entry else None)
    out["to_stop_pct"] = round(100 * (entry - current) / r_unit)
    # marker position 0..100 along stop->target axis (for spatial placement)
    span = target - stop
    out["marker_pos"] = max(0, min(100, round(100 * (current - stop) / span))) if span > 0 else None
    # MFE high-water mark since entry
    try:
        entry_ts_ms = int(_entry_ts_ms(pos))
        with db.connect(db_url) as conn:
            hi = conn.execute(
                "SELECT MAX(high) AS h FROM bitunix_bar_history "
                "WHERE symbol=? AND timeframe=? AND ts_ms >= ?",
                (wire, TF, entry_ts_ms),
            ).fetchone()
        if hi and hi["h"] is not None:
            out["mfe_r"] = round((float(hi["h"]) - entry) / r_unit, 2)
    except Exception as e:                                   # noqa: BLE001
        log.warning("sfp_cockpit: MFE compute failed: %s", e)
    return out


def _entry_ts_ms(pos: dict) -> int:
    """Entry bar ts in ms — from the row ts (ISO) for the MFE window."""
    ts = datetime.fromisoformat(str(pos["ts"]).replace("Z", "+00:00"))
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return int(ts.timestamp() * 1000)


def _tp_venue_chip(pos: dict) -> dict:
    """NEW. TP-@-venue chip from the position's extra_json.bracket_tp_order_id.
    Present → '✓ id <n>'. Empty on an OPEN position → '✗ TP MISSING' (loud red) —
    surfaces the exact blocker SFP just had (TP never placed at the venue)."""
    tp_id = (pos.get("extra") or {}).get("bracket_tp_order_id")
    if tp_id:
        return {"state": "ok", "text": f"✓ TP @ venue · id {tp_id}", "tp_order_id": tp_id}
    return {"state": "bad", "text": "✗ TP MISSING", "tp_order_id": None}


def _oco_health_chip(pos: dict) -> dict:
    """NEW. OCO/orphan health from record truth: an OPEN position should carry a
    venue stop (B1, always attached) AND a resting TP leg (bracket_tp_order_id).
      both present  → 'venue: 1 stop + 1 tp ✓'
      tp missing    → 'ORPHAN STOP' (red) — stop-only, the edge-inverting state.
    Authoritative orphan detection (a TP with no position, etc.) is the
    reconciler's signed-venue job; this is the record-side early-warning."""
    extra = pos.get("extra") or {}
    has_tp = bool(extra.get("bracket_tp_order_id"))
    has_stop = pos.get("stop") is not None        # B1 stop attached at entry
    if has_stop and has_tp:
        return {"state": "ok", "text": "OCO ✓ · 1 stop + 1 tp"}
    if has_stop and not has_tp:
        return {"state": "bad", "text": "ORPHAN STOP · no TP leg"}
    return {"state": "warn", "text": "OCO unknown"}


# ──────────────────────────────────────────────────────────────────────────
# TIER B — MOCK (no real source yet; needs observer watch-state emit)
# ──────────────────────────────────────────────────────────────────────────
# BLOCKED on observer watch-state emit: fired_bar_ts, mode, swept_level,
# swept_wick, bos_watch_level, status. Wire these to real reads when it ships.
def _mock_armed_watch(symbol: str) -> dict:
    """MOCK — per-coin SFP-armed watch overlay + countdown. Demo only."""
    return {
        "tier": "B", "mock": True, "symbol": symbol,
        "mode": "CONSIDERABLE", "swept_wick": 2409.2, "bos_watch_level": 2441.0,
        "expires_in": "06:49:01", "status": "ARMED",
    }


def _ago(ts_iso) -> str:
    """'14m ago' / '2h ago' / '3d ago' from an ISO ts. '' if unparseable."""
    if not ts_iso:
        return ""
    try:
        t = datetime.fromisoformat(str(ts_iso).replace("Z", "+00:00"))
        if t.tzinfo is None:
            t = t.replace(tzinfo=timezone.utc)
        m = int((_utc_now() - t).total_seconds() // 60)
    except Exception:                                        # noqa: BLE001
        return ""
    if m < 60:
        return f"{m}m ago"
    h = m // 60
    return f"{h}h ago" if h < 24 else f"{h // 24}d ago"


def _bos_confirm_rate(db_url: str) -> dict:
    """TIER A (REAL now, was MOCK) — armed→confirmed conversion from sfp_watch_state (the fraction of
    raw two-candle fires that reach a 3m BOS). Honest-empty until watches exist; the tracking verdict is
    GATED behind n>=SIG_N so a handful of watches never fires a divergence alarm."""
    with db.connect(db_url) as conn:
        rows = conn.execute(
            "SELECT status, COUNT(*) n FROM sfp_watch_state WHERE armed_ts >= ? GROUP BY status",
            (CONSTRUCT_SINCE,),
        ).fetchall()
    by = {(r["status"] or "").upper(): int(r["n"]) for r in rows}
    total = sum(by.values())
    confirmed = by.get("CONFIRMED", 0)
    return {"tier": "A", "has_data": total > 0, "n": total, "confirmed": confirmed,
            "rate_pct": (round(100 * confirmed / total) if total else None),
            "significant": total >= SIG_N, "need": SIG_N, "band": "27–65th (bt)"}


def _near_miss(db_url: str, limit: int = 6) -> dict:
    """TIER A (REAL now, was MOCK) — armed watches that INVALIDATED or TIMED_OUT (never converted to a
    trade), from sfp_watch_state. Reconstructed, not demo data."""
    with db.connect(db_url) as conn:
        rows = conn.execute(
            "SELECT symbol, mode, status, swept_wick, bos_watch_level, status_ts "
            "FROM sfp_watch_state WHERE status IN ('INVALIDATED','TIMED_OUT') AND armed_ts >= ? "
            "ORDER BY COALESCE(status_ts, armed_ts) DESC LIMIT ?",
            (CONSTRUCT_SINCE, limit),
        ).fetchall()
        tot = conn.execute("SELECT COUNT(*) n FROM sfp_watch_state WHERE armed_ts >= ?",
                           (CONSTRUCT_SINCE,)).fetchone()
        nc = conn.execute("SELECT COUNT(*) n FROM sfp_watch_state WHERE status IN "
                          "('INVALIDATED','TIMED_OUT') AND armed_ts >= ?", (CONSTRUCT_SINCE,)).fetchone()
    total = int(tot["n"] or 0)
    out = []
    for r in rows:
        short = str(r["symbol"] or "").replace("USDT", "")[:3].upper()
        lvl = r["swept_wick"] if r["swept_wick"] is not None else r["bos_watch_level"]
        out.append({"mode": (str(r["mode"] or "")[:4]).upper() or "REAL", "symbol": short,
                    "status": str(r["status"] or "").replace("_", " "),
                    "level": ("%g" % lvl) if lvl is not None else "—",
                    "ago": _ago(r["status_ts"]), "exec": "LIVE"})
    return {"tier": "A", "has_data": bool(out), "rows": out,
            "convert_fail_pct": (round(100 * int(nc["n"] or 0) / total) if total else 0)}


# ──────────────────────────────────────────────────────────────────────────
# context builders (compose per fragment)
# ──────────────────────────────────────────────────────────────────────────
_CH_W, _CH_H, _PAD = 460.0, 120.0, 10.0


def _chart_geom(bars: list[dict], levels: list | None = None,
                marker_price: float | None = None, marker_color: str = "#5b9dff") -> dict:
    """Scale OHLC bars + overlay levels into SVG coords (so Jinja stays dumb).
    levels = [(price, color, dash), ...]. Returns candles/lines/marker + viewbox."""
    levels = levels or []
    prices: list[float] = []
    for b in bars:
        prices += [b["h"], b["l"]]
    for (p, _c, _d) in levels:
        if p:
            prices.append(float(p))
    if marker_price:
        prices.append(float(marker_price))
    if not prices:
        return {"candles": [], "lines": [], "marker": None, "w": _CH_W, "h": _CH_H}
    lo, hi = min(prices), max(prices)
    rng = (hi - lo) or 1.0

    def y(p: float) -> float:
        return round(_PAD + (hi - float(p)) / rng * (_CH_H - 2 * _PAD), 1)

    n = len(bars) or 1
    step = (_CH_W - 2 * _PAD) / max(1, n)
    candles = []
    for i, b in enumerate(bars):
        x = round(_PAD + step * (i + 0.5), 1)
        candles.append({"x": x, "yh": y(b["h"]), "yl": y(b["l"]),
                        "yo": y(b["o"]), "yc": y(b["c"]), "up": b["c"] >= b["o"]})
    lines = [{"y": y(p), "color": c, "dash": d} for (p, c, d) in levels if p]
    marker = ({"x": round(_CH_W - _PAD, 1), "y": y(marker_price), "color": marker_color}
              if marker_price else None)
    return {"candles": candles, "lines": lines, "marker": marker, "w": _CH_W, "h": _CH_H}


def _regime_state(db_url: str, wire: str) -> dict:
    """Flip-watch chip (READ-ONLY): CURRENT 15m regime from the single-source
    bitunix_sfp_regime_state mirror (the observer's _compute_regime value — never
    recomputed here) + last-flip ts from bitunix_sfp_regime_flip. Always-current from
    day one; fail-soft; '-' only during the pre-convergence warmup."""
    try:
        with db.connect(db_url) as conn:
            s = conn.execute("SELECT regime, updated_ts FROM bitunix_sfp_regime_state "
                             "WHERE coin=?", (wire,)).fetchone()
            f = conn.execute("SELECT ts FROM bitunix_sfp_regime_flip WHERE coin=? "
                             "ORDER BY id DESC LIMIT 1", (wire,)).fetchone()
        label = (s[0] if s and s[0] else "-")
        return {"label": label, "last_flip_ts": (f[0] if f else None),
                "updated_ts": (s[1] if s else None), "to_up": label == "up"}
    except Exception:
        return {"label": "-", "last_flip_ts": None, "updated_ts": None, "to_up": False}


def _coin_state(db_url: str, display: str, pos: dict | None,
                arm: str = "watch", div_live: bool = False) -> dict:
    """Per-coin card context. A coin is LIVE iff it's armed for live orders
    (symbol_modes arm:trading) AND the division runtime is actually live; watch
    coins are MONITOR (paper forward-track); an armed coin on a non-live division
    shows PAPER. A live coin with an open position gets the TIER-A R-journey +
    TIER-C chips; the rest get monitor-only bar strips."""
    wire = SYMBOLS[display]
    is_live_coin = (arm == "trading") and div_live
    has_pos = bool(pos) and (
        str(pos["symbol"]).upper().startswith(display) or pos["symbol"] == wire)
    card = {
        "symbol": display, "wire": wire, "is_live_coin": is_live_coin,
        "bars": _bar_strip(db_url, wire),
        "heartbeat": _loop_heartbeat(db_url, wire),
        "state": "in_trade" if has_pos else ("monitoring"),
        "exec_tag": ("LIVE" if is_live_coin
                     else ("MONITOR" if arm == "watch" else "PAPER")),
    }
    card["regime"] = _regime_state(db_url, wire)            # flip-watch chip (read-only)
    if has_pos:
        rj = _r_journey(db_url, pos)                         # TIER A
        card["rj"] = rj
        card["tp_chip"] = _tp_venue_chip(pos)               # NEW
        card["oco_chip"] = _oco_health_chip(pos)            # NEW
        card["mode"] = (pos.get("extra") or {}).get("sfp_mode", "REAL")
        mk_color = "#34d399" if rj.get("crossed_breakeven") else "#5b9dff"
        card["chart"] = _chart_geom(
            card["bars"],
            [(rj["target"], "#34d399", "3 4"), (rj["entry"], "#f5b53d", "5 4"),
             (rj["stop"], "#fb5e6b", "3 4")],
            rj["current"], mk_color)
    else:
        # Real armed-watch per coin: read the live sfp_watch_state emit (now
        # deployed). No coin is hardcoded-armed — ETH was a demo mock whose
        # static levels (2409/2441) distorted the chart y-scale and falsely lit
        # ARM. None until the real sfp_watch_state read is wired (backlog).
        armed = None
        card["armed"] = armed
        levels = ([(armed["bos_watch_level"], "#5b9dff", "2 4"),
                   (armed["swept_wick"], "#f5b53d", "5 4")] if armed else [])
        card["chart"] = _chart_geom(card["bars"], levels)
    return card


# ──────────────────────────────────────────────────────────────────────────
# routes
# ──────────────────────────────────────────────────────────────────────────
def register(app: FastAPI) -> None:
    templates = app.state.templates
    deps = app.state.deps
    db_url = deps.db_url

    async def _q(fn, *a):
        return await asyncio.to_thread(fn, *a)

    @app.get("/sfp", response_class=HTMLResponse)
    async def sfp_cockpit(request: Request):
        # Initial full paint — fragments then HTMX-poll themselves every ~5s.
        ctx = {
            "badge": runtime_badge(deps),
            "live_count": _live_count(deps),
            "metrics": await _q(_closed_metrics, db_url),
            # _recon.html (and its partial route) read top-level `bos` + `metrics`;
            # the full-page paint must provide `bos` top-level too (was nested in
            # an unused `recon` dict -> UndefinedError 'bos' on the full page).
            "bos": await _q(_bos_confirm_rate, db_url),
            "modes": await _q(_mode_split, db_url),
            "equity": await _q(_equity_curve, db_url),
            "near_miss": await _q(_near_miss, db_url),
            "coins": await _build_board(),
        }
        return templates.TemplateResponse(request, "sfp_cockpit.html", ctx)

    async def _build_board() -> list[dict]:
        positions = await _q(_open_sfp_positions, db_url)     # TIER C, scoped, per-coin
        arm_map = _symbol_arm_map()
        div_live = runtime_badge(deps).get("state") == "live"
        return [await _q(_coin_state, db_url, d, positions.get(d), arm_map.get(d, "watch"), div_live)
                for d in SYMBOLS]

    @app.get("/sfp/partials/header", response_class=HTMLResponse)
    async def sfp_header(request: Request):
        return templates.TemplateResponse(
            request, "sfp_cockpit/_header.html",
            {"badge": runtime_badge(deps), "metrics": await _q(_closed_metrics, db_url),
             "live_count": _live_count(deps)},
        )

    @app.get("/sfp/partials/recon", response_class=HTMLResponse)
    async def sfp_recon(request: Request):
        m = await _q(_closed_metrics, db_url)
        return templates.TemplateResponse(
            request, "sfp_cockpit/_recon.html",
            {"metrics": m, "bos": await _q(_bos_confirm_rate, db_url)},     # both TIER A now
        )

    @app.get("/sfp/partials/state-board", response_class=HTMLResponse)
    async def sfp_state_board(request: Request):
        return templates.TemplateResponse(
            request, "sfp_cockpit/_state_board.html", {"coins": await _build_board()},
        )

    @app.get("/sfp/partials/mode-split", response_class=HTMLResponse)
    async def sfp_mode_split(request: Request):
        return templates.TemplateResponse(
            request, "sfp_cockpit/_mode_split.html", {"modes": await _q(_mode_split, db_url)},
        )

    @app.get("/sfp/partials/near-miss", response_class=HTMLResponse)
    async def sfp_near_miss(request: Request):
        return templates.TemplateResponse(
            request, "sfp_cockpit/_near_miss.html", {"near_miss": await _q(_near_miss, db_url)},
        )

    @app.get("/sfp/partials/equity", response_class=HTMLResponse)
    async def sfp_equity(request: Request):
        return templates.TemplateResponse(
            request, "sfp_cockpit/_equity.html", {"equity": await _q(_equity_curve, db_url)},
        )

    log.info("SFP cockpit routes registered at /sfp")
