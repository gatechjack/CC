"""On-demand ANALYZE for a whale in ONE category (CP3b-2). A FORK of the legacy PCT analyzer, NOT a reuse.

Why a fork and not an import (Jack ruling 2026-08-25, Q6): the legacy analyzer lives in the ENGINE
(`trading_corp/agents/polymarket_whale_analyst.py` + `data/polymarket_whale_audit.py` +
`agents/research/polymarket_whale_audit_cache.py`) and serves the LIVE legacy PCT division. pm_web is
standalone (no engine imports) and the whole platform is zero-engine-edits -- so we COPY the narration
guardrails and the gate structure into the PM package. A live-division incident is possible ONLY if we
share/import/edit; forking makes that structurally impossible.

What changed vs the legacy (Q2/Q3 rulings):
  * DATA SOURCE = pm_closed_position ONLY (resolved positions), category-filtered `WHERE wallet=? AND
    category=?`. NO /activity, NO hybrid. The legacy walks /activity to exhaustion for fill-level analytics
    (clustering, sell-footprint, edge-profile, REDEEM-grounded realized PnL) -- pm_closed_position has NO
    fills (one row per resolved market), so ALL of that is DROPPED. CategoryConcentrationReport is NOT
    ported (category is the FILTER here, not a derived concentration metric). The verdict is LEANER:
    P&L / win-rate / cost-ROI over the settled positions, with the caveats the scoreboard already carries.
  * The deterministic numbers are recomputed FRESH from pm_closed_position through the ONE canonical
    scoreable predicate (`db.scoreable_where`) and the SAME formulas as `stats.rollup` -- so Analyze MATCHES
    the scoreboard when the weekly rollup is current, and TRANSPARENTLY shows fresher numbers (with a
    reconciliation note) when pm_closed_position has advanced past the last rollup. It never silently diverges.
  * COST cap = $20/day (`PM_ANALYZE_DAILY_CAP_USD`; Jack ruling -- the legacy code default is $1.00 and the
    P2_PLAN §7.4 doc wrongly said $2), enforced against ONE visible per-day counter in the PM DB
    (pm_analysis_cost). PM must NEVER write agent_state (the legacy's counter) -- isolation.
  * CACHE key = (wallet, category, skill_version) in pm_analysis_cache. `skill_version` REPLACES the legacy
    24h TTL as the ONLY invalidation axis. A cache HIT returns the stored report and spends NOTHING. Only a
    SUCCESSFUL verdict is cached -- reasoned-nulls recompute, so the moment the ANTHROPIC key is wired the
    next analyze narrates fresh instead of serving a stale "llm_unavailable".

Narration is SYNCHRONOUS here (chat.invoke, not ainvoke): pm_web runs every DB read through
`asyncio.to_thread(<sync fn>)`, so a sync narrator drops straight into that model (no nested event loop).

★ THE ANTHROPIC KEY IS WIRED IN PROD (Jack 2026-09-12 -- corrects the earlier 'e3, not wired' note). So
narration RUNS live: is_llm_available() reads ANTHROPIC_API_KEY (now present in the pm_web process) and the
Sonnet verdict fills in. A cache HIT still spends nothing. ★ Because the swap is live on deploy, the post-check
must verify a REAL (non-cached) call returns model=claude-sonnet-4-6 -- a silent Haiku fallback would look
identical from the OUTPUT side, so NarrationResult.model now carries the ACTUAL response model (_extract_model),
NOT the config, and that value persists into the cached report for the post-check to read back. `llm_unavailable`
now fires only on a genuine key/transport failure, not by design.

Spec: reports/prediction_markets/P2_PLAN.md §7.4 (amended in this commit); CP3b-2 rulings 2026-08-25.
"""
from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict, dataclass, replace

from . import scoring, stats
from .db import SCOREABLE_PREDICATE_SQL, scoreable_where

log = logging.getLogger(__name__)

# ── forked constants (pinned in the PM package; NOT read from engine config/agents.yaml) ──────────────
PM_ANALYZE_MODEL = "claude-sonnet-4-6"           # ANALYZE UPGRADE 2026-09-12 (Haiku -> Sonnet): the promotion judge
                                                 # narrates over the DETERMINISTIC scoring.WhaleScore. Pinned so the
                                                 # model can't be swapped from under Analyze. ★ The ANTHROPIC key IS
                                                 # wired in prod (Jack 2026-09-12) -> this runs LIVE on deploy; POST-
                                                 # DEPLOY verify a REAL (non-cached) call returns model=claude-sonnet-4-6
                                                 # (a silent Haiku fallback looks identical from the output side).
PM_ANALYZE_MAX_OUTPUT_TOKENS = 220               # item 7 (2026-09-15): 160 -> 220. INSUFFICIENT_DATA now gets TWO
                                                 # sentences (caveat + shape read); ★ a TRUNCATED second sentence reads
                                                 # as a broken answer, WORSE than none, so give headroom (2 short
                                                 # sentences ~50 tok, well under 220). The prompt still enforces the
                                                 # sentence COUNT; this cap is only a backstop. (One-sentence tiers unaffected.)
PM_ANALYZE_DAILY_CAP_USD = 20.00                 # Jack ruling 2026-08-25 (legacy code=$1.00; §7.4 doc said $2)
PM_ANALYZE_SKILL_VERSION = "5"                   # bump on ANY prompt/model/report-shape change -> cache miss.
#   "4"->"5" (2026-09-15, Group 3 items 5+7): item 7 = INSUFFICIENT_DATA narration keeps the caveat AND adds a second
#     "shape read" sentence (a watchlist is built by pinning low-N traders that LOOK worth watching); item 5 = the
#     stats.py ranking metrics are fed to the narrator (clean set) + shown flagged (inverting set). Bumped so the first
#     click on an already-analyzed whale recomputes to the new-form verdict.
#   "3"->"4" (2026-09-12, ANALYZE UPGRADE): Haiku->Sonnet + the deterministic scoring.WhaleScore (tier + trust-flagged
#     dimensions) drives a ONE-sentence verdict template. Bumped so the first click on an already-analyzed whale
#     recomputes instead of serving the old Haiku verdict (the standing skill-version-invalidation ruling).
# Below this /activity-window coverage a grounded omission is a FLOOR, not a measurement (older losers lie beyond the
# window) -> the UI marks it "(floor)". 0.90 matches the 'well-covered' bar the price-bucket re-grounding used. The
# floor is EITHER truncation (hit the page ceiling) OR low coverage -- the two are NOT the same signal (a whale can be
# under-covered without hitting the ceiling), so both must gate the marker.
LOSS_COVERAGE_FLOOR = 0.90
#   "1"->"2" (2026-08-31, Stage 5 R2b): PMAnalysisReport gained the loss-completeness fields (re-grounded loss set).
#   "2"->"3" (2026-08-31, Stage 5 R2c + prompt rung): the re-grounded loss set now FLOWS into the narrator prompt
#     (a top caveat tier + the honest win/loss lines), so the promotion-judge verdict itself reasons about the F-1
#     omission -- not just the printed table. Settle this at "3" BEFORE the Anthropic key is wired, so the first
#     PAID narration a wallet gets is the final-form one (key-last ordering, Jack 2026-08-31).
# Sonnet-4-6 price per 1M tokens -- forked from agents/research/cost.py ('claude-sonnet-4-6' = $3 in / $15 out). At
# ~1.4k in / ~120 out a narration costs ~$0.006 (Haiku was ~$0.0016) -> ~3000/day under the $20 cap; ad-hoc usage is
# a handful of clicks, so the Sonnet swap is negligible against the cap.
_MODEL_PRICE = {"input": 3.0, "output": 15.0}

# null-reason taxonomy. The FOUR LLM gates are preserved verbatim from the legacy narrator; `no_resolved_positions`
# is the additional DATA-level refusal (Jack: "refuses honestly at zero rows") -- distinct from the LLM being off.
NULL_DISABLED = "disabled_by_flag"
NULL_NO_DATA = "no_resolved_positions"
NULL_CAP = "daily_cap_hit"
NULL_UNAVAILABLE = "llm_unavailable"
NULL_ERROR = "llm_error"

# human-readable reasons (module-owned so the page and the CLI read the SAME words)
NULL_REASON_LABELS = {
    NULL_DISABLED: "narration disabled for this run",
    NULL_NO_DATA: "no resolved positions in this category to narrate",
    NULL_CAP: "daily analysis cost cap reached",
    NULL_UNAVAILABLE: "LLM narrator unavailable (no Anthropic key reachable from pm_web)",
    NULL_ERROR: "the narration call failed",
}


# ── report shape ─────────────────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class SampleRow:
    """One illustrative resolved position (largest by |realized_pnl|). Drill/colour only, never a rank."""
    title: str
    condition_id_short: str
    outcome: str | None
    outcome_index: int | None
    avg_price: float | None
    cost_basis: float | None
    realized_pnl: float | None
    won: int | None
    resolved_ts: int | None
    pnl_suspect: int


@dataclass(frozen=True)
class PMAnalysisReport:
    """The deterministic Analyze report for ONE (wallet, category). Numbers are fresh from
    pm_closed_position through the §3A scoreable predicate; caveats mirror the scoreboard. The verdict fields
    are filled by narrate() (or left as a reasoned-null)."""
    wallet: str
    category: str
    user_name: str | None
    backfill_complete: bool
    # counts (per-pair -- Q2: n-counts become per-pair with the category filter)
    n_total_rows: int          # every pm_closed_position row in the (wallet, category) slice
    n_resolved: int            # scoreable (pnl_suspect=0)
    n_excluded: int            # §3A quarantined
    n_anomaly: int             # §3A clause-(a) flag count (recorded, not excluded)
    wins: int
    losses: int
    # scoreable aggregates (same formulas as stats.rollup)
    win_rate: float | None
    net_realized_pnl: float
    total_bought: float        # NOTIONAL sum (NOT cost)
    cost_basis: float          # the ROI denominator
    roi: float | None          # cost-based (THE metric); None if cost_basis<=0
    roi_notional: float | None # net/total_bought -- NOT ranked, legacy comparison only
    avg_win_price: float | None
    chalk: bool                # avg_win_price >= 0.85
    contested: bool            # avg_win_price < 0.70
    # structure + data-quality caveats (fresh, mirroring the rollup)
    n_condition_ids: int | None
    two_sided_pct: float | None
    onesided_roi: float | None # UPPER BOUND (excludes hedged markets, survivorship-caveated)
    onesided_n: int | None
    data_quality: str | None   # 'contaminated' | None
    dq_count_pct: float
    dq_dollar_pct: float
    # thinness / data state
    data_state: str            # 'ok' (n>=min) | 'thin' (0<n<min) | 'empty' (n==0)
    all_quarantined: bool      # n_resolved==0 AND n_excluded>0 (the 4751346/nfl case)
    min_resolved: int          # the thin threshold, so 'thin' cites its cutoff
    # reconciliation vs the weekly rollup (never silent -- shipped reconcile() philosophy)
    rollup_n_resolved: int | None
    reconciled: bool
    recon_note: str | None
    # provenance
    generated_ts: int
    skill_version: str
    samples: tuple[SampleRow, ...] = ()
    # verdict (filled by narrate; a reasoned-null leaves verdict None + null_reason set)
    verdict: str | None = None
    null_reason: str | None = None
    model: str | None = None
    cost_usd: float = 0.0
    tokens_in: int = 0
    tokens_out: int = 0
    served_from_cache: bool = False
    # ── Stage 5 LOSS-COMPLETENESS (re-grounded from /activity; None when not grounded) ──
    # The core wins/losses/win_rate above stay /closed-positions-based (rollup + scoreboard consistency -- Stage 5
    # does NOT re-plumb the platform rollup, F-1). These SEPARATE fields carry the HONEST re-grounded loss set +
    # the MEASURED bias, so Analyze tells the operator how honest its own input is per whale. Defaults keep the
    # dataclass backward-compatible (an ungrounded/offline analysis leaves them None/False).
    loss_grounded: bool = False           # True iff the loss set was re-grounded from /activity (the promotion judge)
    honest_wins: int | None = None        # /closed-positions UNION A_only
    honest_losses: int | None = None
    a_only_losses: int | None = None      # losses /closed-positions DROPPED (the F-1 omission, recovered)
    loss_omission_pct: float | None = None  # a_only_losses / honest_losses -- the MEASURED bias for THIS whale
    loss_completeness: str | None = None  # the measured bound ('complete...' | 'windowed(...lower bound)')
    # DISPLAY-ONLY (not fed to the narrator -> narration byte-identical -> NO skill_version bump): the coverage BEHIND
    # the omission % so the page cannot flatten '94% @ 96% cov' and '94% @ 31% cov (a floor)' into one number.
    loss_coverage_pct: float | None = None  # |closed re-found in /activity window| / |closed|; None when ungrounded/no-closed
    # ── ANALYZE UPGRADE 2026-09-12: the DETERMINISTIC scoring.WhaleScore as a plain dict (json-trivial, no nested
    # dataclass to reconstruct). tier + sort_roi + trust-flagged dimensions. Written to pm_whale_score separately for
    # the sortable Prospects list; carried here so the verdict + the UI render off ONE object. None on a pre-upgrade cache row.
    score: dict | None = None

    @property
    def is_thin(self) -> bool:
        return self.data_state == "thin"

    @property
    def is_empty(self) -> bool:
        return self.data_state == "empty"

    @property
    def null_reason_label(self) -> str | None:
        return NULL_REASON_LABELS.get(self.null_reason) if self.null_reason else None

    @property
    def loss_is_floor(self) -> bool:
        """A grounded omission is a FLOOR (lower bound) when /activity truncated OR coverage is below the well-covered
        bar -- either way older held-to-worthless losers may lie beyond the window. Recomputed from stored fields, so
        it survives the cache round-trip. False when not grounded (nothing to bound)."""
        if not self.loss_grounded:
            return False
        if "lower bound" in (self.loss_completeness or ""):
            return True
        return self.loss_coverage_pct is not None and self.loss_coverage_pct < LOSS_COVERAGE_FLOOR


@dataclass(frozen=True)
class NarrationResult:
    narration: str | None
    null_reason: str | None
    cost_usd: float
    tokens_in: int
    tokens_out: int
    model: str | None        # the ACTUAL response model (via _extract_model), NOT the config -- the deploy proof reads this


# ── deterministic report (pm_closed_position ONLY; reuses the ONE predicate + stats formulas) ─────────
def _copy_fills(conn, wallet: str, category: str) -> tuple[int, float | None]:
    """(n filled real copies, realized copy P&L or None) for THIS whale from OUR journal -- DISPLAY ONLY (Ruling 2:
    never a gate). realized = settled/exit proceeds - entry cost - fee over round-trips; None when the sample is too
    thin or nothing has settled (a handful of fills is noise). Read-only."""
    try:
        r = conn.execute(
            "SELECT SUM(CASE WHEN outcome_status='filled' THEN 1 ELSE 0 END) AS filled "
            "FROM pm_subdivision_order WHERE wallet=? AND category=? AND dry_run=0",
            (wallet, category)).fetchone()
        return (int((r["filled"] if r else 0) or 0), None)   # realized copy P&L deferred (thin sample; display fills only)
    except Exception:  # noqa: BLE001 -- the score must never fail on a journal read
        return (0, None)


def build_pm_analysis(conn, wallet: str, category: str, *, now_ts: int,
                      min_resolved: int | None = None,
                      skill_version: str = PM_ANALYZE_SKILL_VERSION,
                      loss_grounding=None, honest=None) -> PMAnalysisReport:
    """Aggregate the (wallet, category) slice of pm_closed_position into the deterministic report. NO LLM,
    NO write. Every scoreable metric filters through `db.scoreable_where()` (the ONE §3A predicate) and uses
    the SAME formulas as `stats.rollup` -- see that function for the parity contract (roi cost-based, roi
    guarded on cost_basis>0, data_quality on EITHER count OR $-weighted fraction, etc.)."""
    wallet = (wallet or "").lower()
    if min_resolved is None:
        min_resolved = stats.DEFAULT_MIN_RESOLVED
    pred = SCOREABLE_PREDICATE_SQL

    core = conn.execute(
        "SELECT "
        f" SUM(CASE WHEN {pred} THEN 1 ELSE 0 END) AS n_resolved, "
        f" SUM(CASE WHEN {pred} AND won=1 THEN 1 ELSE 0 END) AS wins, "
        f" SUM(CASE WHEN {pred} AND won=0 THEN 1 ELSE 0 END) AS losses, "
        f" SUM(CASE WHEN {pred} THEN realized_pnl ELSE 0 END) AS net, "
        f" SUM(CASE WHEN {pred} THEN total_bought ELSE 0 END) AS tb, "
        f" SUM(CASE WHEN {pred} THEN cost_basis ELSE 0 END) AS cb, "
        f" AVG(CASE WHEN {pred} AND won=1 THEN avg_price END) AS avg_win_price, "
        " SUM(CASE WHEN pnl_suspect=1 THEN 1 ELSE 0 END) AS n_excluded, "
        " SUM(CASE WHEN pnl_anomaly=1 THEN 1 ELSE 0 END) AS n_anomaly, "
        " SUM(ABS(COALESCE(realized_pnl,0))) AS abs_all, "
        " SUM(CASE WHEN pnl_suspect=1 THEN ABS(COALESCE(realized_pnl,0)) ELSE 0 END) AS abs_excl, "
        " COUNT(*) AS n_total "
        "FROM pm_closed_position WHERE wallet=? AND category=?",
        (wallet, category)).fetchone()

    n_resolved = int(core["n_resolved"] or 0)
    wins = int(core["wins"] or 0)
    losses = int(core["losses"] or 0)
    n_excluded = int(core["n_excluded"] or 0)
    n_anomaly = int(core["n_anomaly"] or 0)
    n_total = int(core["n_total"] or 0)
    net = float(core["net"] or 0.0)
    tb = float(core["tb"] or 0.0)
    cb = float(core["cb"] or 0.0)
    avg_win_price = core["avg_win_price"]
    decided = wins + losses
    win_rate = (wins / decided) if decided > 0 else None
    roi = (net / cb) if cb > 0 else None                 # §13 dec 11: cost-based, guarded
    roi_notional = (net / tb) if tb > 0 else None
    abs_all = float(core["abs_all"] or 0.0)
    dq_count_pct = (n_excluded / n_total) if n_total > 0 else 0.0
    dq_dollar_pct = (float(core["abs_excl"] or 0.0) / abs_all) if abs_all > 0 else 0.0
    data_quality = ("contaminated"
                    if (dq_count_pct > stats.DATA_QUALITY_THRESHOLD or dq_dollar_pct > stats.DATA_QUALITY_THRESHOLD)
                    else None)
    chalk = avg_win_price is not None and avg_win_price >= stats.CHALK_HI
    contested = avg_win_price is not None and avg_win_price < stats.CONTESTED_LO

    # two-sided structure over ALL rows (mirrors stats.rollup's DISTINCT-outcome_index pass)
    tsr = conn.execute(
        "SELECT COUNT(*) AS n_cond, SUM(CASE WHEN n_out > 1 THEN 1 ELSE 0 END) AS n_two FROM "
        "(SELECT condition_id, COUNT(DISTINCT outcome_index) AS n_out FROM pm_closed_position "
        " WHERE wallet=? AND category=? GROUP BY condition_id)",
        (wallet, category)).fetchone()
    n_cond = int(tsr["n_cond"] or 0)
    two_sided_pct = (int(tsr["n_two"] or 0) / n_cond) if n_cond > 0 else None

    # one-sided directional slice (mirrors stats._rollup_onesided): scoreable rows on condition_ids the whale
    # held on a SINGLE outcome_index. UPPER BOUND -- excludes hedged markets, so it is optimistic (§13A(f)).
    osr = conn.execute(
        "SELECT SUM(1) AS n, SUM(CASE WHEN p.won=1 THEN 1 ELSE 0 END) AS wins, "
        " SUM(p.realized_pnl) AS net, SUM(p.cost_basis) AS cb "
        "FROM pm_closed_position p "
        "JOIN (SELECT condition_id FROM pm_closed_position WHERE wallet=? AND category=? "
        "      GROUP BY condition_id HAVING COUNT(DISTINCT outcome_index)=1) oc ON p.condition_id=oc.condition_id "
        "WHERE p.wallet=? AND p.category=? AND " + scoreable_where("p"),
        (wallet, category, wallet, category)).fetchone()
    onesided_n = int(osr["n"] or 0)
    os_cb = float(osr["cb"] or 0.0)
    onesided_roi = (float(osr["net"] or 0.0) / os_cb) if os_cb > 0 else None

    # illustrative rows -- largest by |realized_pnl| across the WHOLE slice (suspect rows marked, not hidden)
    samples = tuple(
        SampleRow(
            title=(s["title"] or "")[:70], condition_id_short=(s["condition_id"] or "")[:18],
            outcome=s["outcome"], outcome_index=s["outcome_index"], avg_price=s["avg_price"],
            cost_basis=s["cost_basis"], realized_pnl=s["realized_pnl"], won=s["won"],
            resolved_ts=s["resolved_ts"], pnl_suspect=int(s["pnl_suspect"] or 0))
        for s in conn.execute(
            "SELECT title, condition_id, outcome, outcome_index, avg_price, cost_basis, realized_pnl, won, "
            " resolved_ts, pnl_suspect FROM pm_closed_position WHERE wallet=? AND category=? "
            "ORDER BY ABS(COALESCE(realized_pnl,0)) DESC LIMIT 5",
            (wallet, category)).fetchall())

    # data-state (thinness travels with the verdict): empty (refuse honestly) / thin / ok
    if n_resolved == 0:
        data_state = "empty"
    elif n_resolved < min_resolved:
        data_state = "thin"
    else:
        data_state = "ok"
    all_quarantined = (n_resolved == 0 and n_excluded > 0)

    # whale identity + backfill gate
    w = conn.execute("SELECT user_name, backfill_complete FROM pm_whale WHERE wallet=?", (wallet,)).fetchone()
    user_name = (w["user_name"] if w else None) or None
    backfill_complete = bool(w["backfill_complete"]) if w else False

    # reconcile the FRESH scoreable count against the weekly rollup -- surface staleness, never silence it
    cs = conn.execute("SELECT n_resolved FROM pm_category_stats WHERE wallet=? AND category=?",
                      (wallet, category)).fetchone()
    rollup_n = int(cs["n_resolved"]) if (cs and cs["n_resolved"] is not None) else None
    if rollup_n is None or rollup_n == n_resolved:
        reconciled, recon_note = True, None
    else:
        reconciled = False
        recon_note = ("the weekly rollup (scoreboard) shows %d scoreable here; the live rows show %d -- the "
                      "rollup is stale (a refresh is pending). These numbers are fresh from the rows."
                      % (rollup_n, n_resolved))

    # ── ANALYZE UPGRADE: the DETERMINISTIC WhaleScore (tier + trust-flagged dimensions), from the per-position rows
    # (resolved_ts-ordered) for dominance + the drawdown-tell, plus the grounding + honest windowed return + copy fills.
    _srows = conn.execute(
        "SELECT realized_pnl, won, title FROM pm_closed_position "
        "WHERE wallet=? AND category=? AND pnl_suspect=0 AND resolved_ts IS NOT NULL ORDER BY resolved_ts",
        (wallet, category)).fetchall()
    _score = scoring.build_score(
        wallet=wallet, category=category,
        pnls=[float(r["realized_pnl"] or 0.0) for r in _srows], wons=[r["won"] for r in _srows],
        titles=[r["title"] or "" for r in _srows], sort_roi=roi, n_resolved=n_resolved,
        two_sided_pct=two_sided_pct, avg_win_price=avg_win_price, one_sided_roi=onesided_roi,
        grounding=loss_grounding, honest=honest, copy_fills=_copy_fills(conn, wallet, category)[0])

    return PMAnalysisReport(
        wallet=wallet, category=category, user_name=user_name, backfill_complete=backfill_complete,
        n_total_rows=n_total, n_resolved=n_resolved, n_excluded=n_excluded, n_anomaly=n_anomaly,
        wins=wins, losses=losses, win_rate=win_rate, net_realized_pnl=net, total_bought=tb, cost_basis=cb,
        roi=roi, roi_notional=roi_notional, avg_win_price=avg_win_price, chalk=chalk, contested=contested,
        n_condition_ids=(n_cond or None), two_sided_pct=two_sided_pct, onesided_roi=onesided_roi,
        onesided_n=(onesided_n or None), data_quality=data_quality, dq_count_pct=dq_count_pct,
        dq_dollar_pct=dq_dollar_pct, data_state=data_state, all_quarantined=all_quarantined,
        min_resolved=min_resolved, rollup_n_resolved=rollup_n, reconciled=reconciled, recon_note=recon_note,
        generated_ts=int(now_ts), skill_version=skill_version, samples=samples,
        # Stage 5: carry the re-grounded loss set (the promotion judge) + the measured bias, WITHOUT touching the
        # /closed-positions-based wins/losses above (rollup + scoreboard consistency, F-1). None when not grounded.
        loss_grounded=(loss_grounding is not None),
        honest_wins=(loss_grounding.honest_wins if loss_grounding is not None else None),
        honest_losses=(loss_grounding.honest_losses if loss_grounding is not None else None),
        a_only_losses=(loss_grounding.a_only_losses if loss_grounding is not None else None),
        loss_omission_pct=(loss_grounding.loss_omission_pct if loss_grounding is not None else None),
        loss_completeness=(loss_grounding.completeness if loss_grounding is not None else None),
        loss_coverage_pct=(loss_grounding.coverage_pct if loss_grounding is not None else None),
        score=asdict(_score))


def analysis_flags(rep: PMAnalysisReport) -> list[str]:
    """Reuse the ONE scoreboard flag deriver so Analyze carries IDENTICAL tokens to the scoreboard/farm/CLI."""
    return stats.scoreboard_flags({
        "backfill_complete": rep.backfill_complete, "chalk": rep.chalk, "contested": rep.contested,
        "data_quality": rep.data_quality, "dq_count_pct": rep.dq_count_pct,
        "dq_dollar_pct": rep.dq_dollar_pct, "n_anomaly": rep.n_anomaly})


# ── (de)serialization for the cache ──────────────────────────────────────────────────────────────────
def report_to_json(rep: PMAnalysisReport) -> str:
    return json.dumps(asdict(rep))


def report_from_json(s: str) -> PMAnalysisReport:
    d = json.loads(s)
    d["samples"] = tuple(SampleRow(**sr) for sr in d.get("samples") or [])
    return PMAnalysisReport(**d)


# ── forked LLM helpers (langchain is a third-party lib, NOT an engine module -- forking the wrapper) ───
def is_llm_available() -> bool:
    """True iff langchain-anthropic is importable AND ANTHROPIC_API_KEY is set. Forked verbatim from
    agents/llm.is_llm_available. ★ THE KEY IS WIRED IN PROD (Jack 2026-09-12), so this returns True in production
    today and the Sonnet narrator RUNS live -- an importable library alone is only CAPABILITY, but the token is set."""
    import os
    if not os.getenv("ANTHROPIC_API_KEY"):
        return False
    try:
        import langchain_anthropic  # type: ignore  # noqa: F401
        return True
    except ImportError:
        return False


def _build_chat_model(max_tokens: int = PM_ANALYZE_MAX_OUTPUT_TOKENS):
    """Forked from agents/llm.build_chat_model, pinned to Sonnet (PM_ANALYZE_MODEL, Analyze's only model). SYNC caller."""
    from langchain_anthropic import ChatAnthropic  # type: ignore
    return ChatAnthropic(model=PM_ANALYZE_MODEL, max_tokens=max_tokens, temperature=0.1)


def _extract_usage(resp: object) -> dict:
    """Anthropic-native usage off a langchain response, native block preferred (forked from the analyst)."""
    rm = getattr(resp, "response_metadata", None) or {}
    if isinstance(rm, dict):
        u = rm.get("usage")
        if isinstance(u, dict) and u:
            return u
    um = getattr(resp, "usage_metadata", None) or {}
    return um if isinstance(um, dict) else {}


def _extract_model(resp: object) -> str | None:
    """The ACTUAL model string off the Anthropic response (NOT the requested config). ★ This is what lets the deploy
    post-check PROVE a real call ran Sonnet and did not silently fall back to Haiku -- returning PM_ANALYZE_MODEL here
    would only echo the config Jack told us NOT to trust. langchain surfaces it as response_metadata.model /
    model_name; some versions hang it on the message. None when the response omits it (caller falls back to config)."""
    rm = getattr(resp, "response_metadata", None) or {}
    if isinstance(rm, dict):
        for k in ("model", "model_name"):
            v = rm.get(k)
            if isinstance(v, str) and v:
                return v
    v = getattr(resp, "model", None)
    return v if isinstance(v, str) and v else None


def _cost_for_usage(usage: dict) -> float:
    """Cost from a usage dict at the pinned _MODEL_PRICE (Sonnet $3/$15). Forked from
    agents/research/cost.cost_for_anthropic_usage (cache-read billed 10% of input, cache-creation 125%)."""
    if not usage:
        return 0.0
    in_tok = int(usage.get("input_tokens") or 0) + int(usage.get("prompt_tokens") or 0)
    out_tok = int(usage.get("output_tokens") or 0) + int(usage.get("completion_tokens") or 0)
    cc = int(usage.get("cache_creation_input_tokens") or 0)
    cr = int(usage.get("cache_read_input_tokens") or 0)
    p = _MODEL_PRICE
    return ((in_tok / 1_000_000.0) * p["input"] + (out_tok / 1_000_000.0) * p["output"]
            + (cc / 1_000_000.0) * p["input"] * 1.25 + (cr / 1_000_000.0) * p["input"] * 0.10)


_SYSTEM_PROMPT = """You are a promotion judge for a Polymarket-copy desk. You are handed a whale's DETERMINISTIC \
score for ONE category: a TIER that is ALREADY DECIDED, plus the numbers that decided it -- each carrying its own \
TRUST-FLAG. Write a verdict for a busy operator.

You do NOT recompute, re-rank, or override the tier or any number -- they are final. You only choose which factor(s) \
to lead with and state them plainly.

LENGTH -- TIER-DEPENDENT (this is the brevity mechanism -- do not break it):
- PROMOTE / WATCH / PASS: EXACTLY ONE sentence -- name the SINGLE decisive factor for the tier. No second sentence.
- INSUFFICIENT_DATA: EXACTLY TWO sentences. Sentence 1 = what is MISSING (too few honest positions / a one-position \
record / low grounding coverage) -- the caveat, KEPT. Sentence 2 = the READ on the short record the operator is \
deciding whether to WATCH: on the evidence there IS, does this look like a decent trader worth following or a poor \
one -- cite the honest ROI, diversification, chalk, or hedger flag as the shape warrants. NO third sentence; do NOT \
restate the caveat in other words; do NOT hedge into a paragraph. "Thin, but the shape is good" is the target -- one \
extra sentence, not a paragraph.

HARD RULES:
- DO NOT perform arithmetic. Every number you cite must appear VERBATIM in the input.
- Cite a decisive number ONCE. Each number already carries its flag; do NOT restate the others.
- Never soften a flag. If a cited number is flagged MIRAGE / UNKNOWN / concentrated / chalk / hedger, say it in those terms.

What decides each tier -- lead with it:
- PROMOTE: the honest edge that survived grounding (honest ROI + diversification).
- WATCH: the ONE thing holding it back -- ungrounded (say "run grounding"), concentration, hedger upper-bound, or chalk.
- PASS: why there is no honest edge -- a mirage win-rate, chalk with no return, or the edge vanishing under grounding.
- INSUFFICIENT_DATA: sentence 1 = what is missing; sentence 2 = whether the short record's shape looks good or poor.

Output: plain text, no markdown, no preamble, no restated caveats. ONE sentence for PROMOTE/WATCH/PASS; TWO for INSUFFICIENT_DATA."""


def _fmt_pct_signed(x) -> str:
    return "n/a" if x is None else "%+.1f%%" % (x * 100)


def _fmt_pct(x) -> str:
    return "n/a" if x is None else "%.0f%%" % (x * 100)


def _fmt_px(x) -> str:
    return "n/a" if x is None else "%.2f" % x


def _fmt_usd(x) -> str:
    return "n/a" if x is None else "%+.2f" % x


def ranking_metrics(rep: PMAnalysisReport) -> dict:
    """Item 5 (2026-09-15): the stats.py FARM-RANKING metrics for this (wallet, category), each tagged CLEAN vs
    INVERTING-by-loss-omission. Pure derivation from the report (roi + wins/losses + samples + counts) using the
    SAME stats primitives the scoreboard ranks with -- no new query. ★ RULED disposition (Jack): the CLEAN set
    (cost-basis / sample-size -- honest) is SHOWN normally AND fed to the Sonnet narrator; the INVERTING set is
    SHOWN on the panel behind a 'inverted by loss-omission: a whale hiding losses scores HIGHER' flag and goes
    NOWHERE near the narrator or the deterministic tier. wilson_lcb is a 95%% LCB on a win-rate from the
    loss-OMITTING /closed-positions feed -> a hider gets a HIGHER bound (the drawdown-family inversion); the
    composite score inherits it; roi_notional misranks longshots ~50x. edge_factor + net_roi are cost-basis (safe).
    ★ RECENCY-WEIGHTED n_eff / score are NOT surfaced here: rep.samples is only the top-5 rows by |pnl| (illustrative,
    'never a rank'), so a recency computation over them would be a wrong ~5 next to the true n_resolved and would be
    FED to the narrator as clean (adversarial-review 2026-09-15). n_resolved already conveys sample size honestly;
    the scoreboard's recency-weighted routine ranks over the FULL history elsewhere (stats.compute_scores)."""
    roi = rep.roi
    n_dec = (rep.wins or 0) + (rep.losses or 0)
    score, wilson, edge = stats.score_net_roi(rep.wins or 0, n_dec, roi)   # over the FULL wins/losses (not samples)
    clean = [
        ("net ROI (cost-basis)", _fmt_pct_signed(roi)),
        ("edge factor (1 + clipped cost-ROI)", "n/a" if roi is None else "%.2f" % edge),
        ("n resolved (scoreable)", str(rep.n_resolved)),
        ("n excluded (quarantined)", str(rep.n_excluded)),
        ("min resolved (rank floor)", str(rep.min_resolved)),
    ]
    inverting = [
        ("composite score (wilson_lcb x edge)", "%.3f" % score),
        ("wilson_lcb (95% win-rate lower bound)", "%.3f" % wilson),
        ("ROI (notional, net / total_bought)", _fmt_pct_signed(rep.roi_notional)),
    ]
    return {"clean": clean, "inverting": inverting,
            "invert_flag": "inverted by loss-omission -- a whale hiding losses scores HIGHER, so a GOOD number here is a suspicion"}


def _build_user_content(rep: PMAnalysisReport) -> str:
    """The flagged-number block the narrator reasons over. ★ THE BREVITY MECHANISM: every number carries its
    TRUST-FLAG right here (MIRAGE / UNKNOWN / ONE-POSITION / hedger / chalk / LABELLED FICTION), so a caveat is
    attached to the number and citable ONCE -- there is no free-prose field for the model to restate it in. The
    tier + the decisive factor are ALREADY decided (deterministic); the model only writes the one sentence."""
    s = rep.score or {}

    def pct(x):   # signed, for returns
        return "n/a" if x is None else "%+.0f%%" % (x * 100)

    def pctu(x):  # unsigned, for shares
        return "n/a" if x is None else "%.0f%%" % (x * 100)

    grounded = bool(s.get("grounded"))
    om = s.get("omission_pct")
    if not grounded:
        om_str = "UNKNOWN (ungrounded -- run grounding; the win-rate and ROI may be omission-inflated)"
    elif om is not None and om >= 0.5:
        om_str = "%s [MIRAGE: most of this whale's losses were dropped -- the headline is not the honest record]" % pctu(om)
    elif om is not None and om > 0:
        floor = " (a FLOOR -- more may lie beyond the /activity window)" if s.get("omission_floor") else ""
        om_str = "%s of losses were dropped by /closed-positions%s" % (pctu(om), floor)
    else:
        om_str = "clean (grounding found no dropped losses)"
    dom = s.get("dominance_net")
    if dom is None:
        dom_str = "n/a (net loser)"
    else:
        tag = "ONE-POSITION RECORD" if dom > scoring.DOM_EXTREME_NET else (
            "concentrated" if dom >= scoring.DOM_HIGH_NET else "diversified")
        dom_str = "%s [%s]" % (pctu(dom), tag)
    two = s.get("two_sided_pct")
    two_str = "n/a" if two is None else ("%s%s" % (pctu(two),
              " [hedger/market-maker -- the ROI is an UPPER BOUND]" if two >= scoring.TWO_SIDED_HIGH else ""))
    px = s.get("avg_win_price")
    px_str = "n/a" if px is None else ("%.2f%s" % (px, " [chalk -- favorite-farming, little edge]" if s.get("chalk") else ""))
    lines = [
        "Whale: %s (%s...)   Category: %s" % (rep.user_name or "<no name>", rep.wallet[:10], rep.category),
        "TIER (already decided, final): %s" % s.get("tier"),
        "Deterministic deciding factor: %s" % s.get("reason"),
        "",
        "The numbers that decided it -- each with its trust-flag; cite the DECISIVE one, ONCE:",
        "  cost-ROI (sort number) = %s   over n_honest=%s%s"
        % (pct(s.get("sort_roi")), s.get("n_honest"), "" if grounded else " [n from /closed-positions -- ungrounded]"),
        "  honest windowed ROI (did winning PAY) = %s%s"
        % (pct(s.get("honest_roi")), "" if grounded else " [not computed -- ungrounded]"),
        "  loss omission = %s" % om_str,
        "  grounding coverage = %s" % pctu(s.get("coverage_pct")),
        "  single-trade dominance (net-profit share) = %s   largest = %s [%s]"
        % (dom_str, _fmt_usd(s.get("largest_pnl")), (s.get("largest_title") or "")[:44]),
        "  two-sided share = %s" % two_str,
        "  avg winning price = %s" % px_str,
        "  drawdown-tell = %s over %sW/%sL  [LABELLED FICTION -- NOT a risk figure; near-$0 over many wins = losses hidden]"
        % (_fmt_usd(s.get("dd_tell")), s.get("dd_wins"), s.get("dd_losses")),
        "  our real copy fills = %s  [display only, never a gate]" % s.get("copy_fills"),
    ]
    # item 5 (2026-09-15): the CLEAN farm-ranking metrics (cost-basis + sample-size) go to the narrator too; the
    # loss-omission-INVERTING ones (wilson_lcb / composite score / recency-weighted score / roi_notional) are
    # WITHHELD -- they invert (a hider scores HIGHER), so they never touch the verdict or the tier.
    lines += ["", "Farm-ranking metrics -- CLEAN set only (the loss-omission-inverting ones are withheld from you on purpose):"]
    lines += ["  %s = %s" % (label, val) for (label, val) in ranking_metrics(rep)["clean"]]
    # item 7 (2026-09-15): INSUFFICIENT_DATA keeps the caveat AND adds the shape-read (a watchlist is built by
    # pinning low-N traders that LOOK worth watching -- a bare refusal gives nothing to decide on). Other tiers = ONE.
    lines += ["",
              (("Write EXACTLY TWO sentences: (1) what is MISSING (the caveat, kept); (2) the READ -- is this short "
                "record's shape good or poor (cite honest ROI / diversification / chalk as it warrants). No third "
                "sentence, no restated caveat.")
               if s.get("tier") == "INSUFFICIENT_DATA"
               else "Write EXACTLY ONE sentence naming the single decisive factor for the %s tier." % s.get("tier"))]
    return "\n".join(lines)


def narrate(rep: PMAnalysisReport, *, narrator_enabled: bool = True, chat: object | None = None,
            cap_hit: bool = False) -> NarrationResult:
    """The 4 legacy LLM gates + the data-refusal, in priority order. DB-free (cap_hit is passed in; the cost
    ledger is the orchestrator's job) so it is trivially testable with a fake `chat`.

    Gate order matters: an 'empty' slice refuses on DATA (no_resolved_positions) before the LLM gates, because
    narrating zero numbers is meaningless whether or not the key is wired -- so the zero-rows pair shows the honest
    data-refusal, not a misleading 'the LLM would have narrated'."""
    if not narrator_enabled:
        return NarrationResult(None, NULL_DISABLED, 0.0, 0, 0, None)
    if rep.data_state == "empty":                        # data refusal -- nothing to narrate
        return NarrationResult(None, NULL_NO_DATA, 0.0, 0, 0, None)
    if cap_hit:
        return NarrationResult(None, NULL_CAP, 0.0, 0, 0, None)
    if chat is None:
        if not is_llm_available():                       # key IS wired in prod -> this does NOT fire today (Sonnet runs)
            return NarrationResult(None, NULL_UNAVAILABLE, 0.0, 0, 0, None)
        try:
            chat = _build_chat_model()
        except Exception as e:                            # langchain import / construction failure
            log.warning("pm analyze: build chat model failed: %s", e)
            return NarrationResult(None, NULL_UNAVAILABLE, 0.0, 0, 0, None)
    try:
        # LangChain (role, content) tuple shorthand -- ChatAnthropic accepts it, so we need NO
        # langchain_core.messages import here (keeps the fork's narrate decoupled; the injected-chat tests
        # never import langchain).
        resp = chat.invoke([("system", _SYSTEM_PROMPT),
                            ("human", _build_user_content(rep))])  # type: ignore[attr-defined]
        text = str(getattr(resp, "content", "") or "").strip()
        usage = _extract_usage(resp)
        ti = int(usage.get("input_tokens", 0) or usage.get("prompt_tokens", 0) or 0)
        to = int(usage.get("output_tokens", 0) or usage.get("completion_tokens", 0) or 0)
        cost = _cost_for_usage(usage)
        model = _extract_model(resp) or PM_ANALYZE_MODEL  # the REAL response model (falls back to config only if absent)
        if not text:                                      # empty content -> treat as error (no blank verdict)
            return NarrationResult(None, NULL_ERROR, cost, ti, to, model)
        return NarrationResult(text, None, cost, ti, to, model)
    except Exception as e:
        log.warning("pm analyze narration failed: %s", e)
        return NarrationResult(None, NULL_ERROR, 0.0, 0, 0, None)


# ── cost ledger (ONE visible per-UTC-day counter in the PM DB; NEVER agent_state) ─────────────────────
def _utc_day(now_ts: int) -> str:
    return time.strftime("%Y-%m-%d", time.gmtime(int(now_ts)))


def daily_cost(conn, day: str) -> tuple[float, int]:
    """(usd, n_calls) accumulated for a UTC day; (0.0, 0) if the day has no row yet. Read-only."""
    row = conn.execute("SELECT usd, n_calls FROM pm_analysis_cost WHERE day_utc=?", (day,)).fetchone()
    return (float(row["usd"] or 0.0), int(row["n_calls"] or 0)) if row else (0.0, 0)


def _cap_hit(conn, day: str, cap_usd: float) -> bool:
    return daily_cost(conn, day)[0] >= cap_usd


def _book_cost(conn, day: str, delta_usd: float, now_ts: int) -> None:
    conn.execute(
        "INSERT INTO pm_analysis_cost(day_utc, usd, n_calls, updated_ts) VALUES (?,?,1,?) "
        "ON CONFLICT(day_utc) DO UPDATE SET usd = usd + excluded.usd, n_calls = n_calls + 1, "
        "updated_ts = excluded.updated_ts",
        (day, float(delta_usd), int(now_ts)))


# ── cache (only successful verdicts are stored) ───────────────────────────────────────────────────────
def _cache_get(conn, wallet: str, category: str, skill_version: str) -> str | None:
    row = conn.execute(
        "SELECT report_json FROM pm_analysis_cache WHERE wallet=? AND category=? AND skill_version=?",
        (wallet, category, skill_version)).fetchone()
    return row["report_json"] if row else None


def _cache_put(conn, rep: PMAnalysisReport) -> None:
    conn.execute(
        "INSERT OR REPLACE INTO pm_analysis_cache(wallet, category, skill_version, verdict, null_reason, "
        "report_json, model, cost_usd, tokens_in, tokens_out, n_resolved, created_ts) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (rep.wallet, rep.category, rep.skill_version, rep.verdict, rep.null_reason, report_to_json(rep),
         rep.model, rep.cost_usd, rep.tokens_in, rep.tokens_out, rep.n_resolved, rep.generated_ts))


def _cache_evict(conn, wallet: str, category: str, skill_version: str) -> None:
    conn.execute("DELETE FROM pm_analysis_cache WHERE wallet=? AND category=? AND skill_version=?",
                 (wallet, category, skill_version))


def _store_whale_score(conn, score: dict, now_ts: int) -> None:
    """Upsert the deterministic WhaleScore into pm_whale_score (migration 023) so the Prospects list is SORTABLE. An
    un-analyzed whale has NO ROW -> the list reads NULL (not-analyzed), distinct from a PASS row. PM DB only."""
    if not score:
        return
    conn.execute(
        "INSERT OR REPLACE INTO pm_whale_score(wallet, category, tier, reason, sort_roi, n_resolved, n_honest, "
        "grounded, omission_pct, coverage_pct, omission_floor, honest_roi, dominance_net, dominance_gross, "
        "largest_pnl, largest_title, two_sided_pct, avg_win_price, chalk, dd_tell, dd_wins, dd_losses, copy_fills, "
        "copy_pnl, skill_version, computed_ts) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (score.get("wallet"), score.get("category"), score.get("tier"), score.get("reason"), score.get("sort_roi"),
         score.get("n_resolved"), score.get("n_honest"), 1 if score.get("grounded") else 0, score.get("omission_pct"),
         score.get("coverage_pct"), 1 if score.get("omission_floor") else 0, score.get("honest_roi"),
         score.get("dominance_net"), score.get("dominance_gross"), score.get("largest_pnl"),
         score.get("largest_title"), score.get("two_sided_pct"), score.get("avg_win_price"),
         1 if score.get("chalk") else 0, score.get("dd_tell"), score.get("dd_wins"), score.get("dd_losses"),
         score.get("copy_fills"), score.get("copy_pnl"), score.get("skill_version"), int(now_ts)))


def is_cached(conn, wallet: str, category: str, skill_version: str = PM_ANALYZE_SKILL_VERSION) -> bool:
    """True iff a stored verdict exists for this (wallet, category, skill_version). Read-only; the analyze route
    peeks this to decide whether to pay for the /activity loss-grounding fetch -- a cache HIT skips it entirely."""
    return _cache_get(conn, (wallet or "").lower(), category, skill_version) is not None


# ── orchestration ─────────────────────────────────────────────────────────────────────────────────────
def analyze_whale(conn, wallet: str, category: str, *, now_ts: int, force: bool = False,
                  narrator_enabled: bool = True, chat: object | None = None,
                  skill_version: str = PM_ANALYZE_SKILL_VERSION,
                  min_resolved: int | None = None,
                  daily_cap_usd: float = PM_ANALYZE_DAILY_CAP_USD,
                  loss_grounding=None, honest=None) -> PMAnalysisReport:
    """The button/CLI entrypoint. Cache-hit -> return stored, spend NOTHING. Miss/force -> build the
    deterministic report, narrate under the cap, book any spend, and cache ONLY a successful verdict.
    Writes pm_analysis_cache + pm_analysis_cost (both PM DB); NEVER agent_state, NEVER the legacy DB."""
    wallet = (wallet or "").lower()

    if not force:
        cached = _cache_get(conn, wallet, category, skill_version)
        if cached is not None:
            return replace(report_from_json(cached), served_from_cache=True)   # HIT: no narrate, no spend
    else:
        _cache_evict(conn, wallet, category, skill_version)                     # re-analyze: clear stale verdict

    rep = build_pm_analysis(conn, wallet, category, now_ts=now_ts, min_resolved=min_resolved,
                            skill_version=skill_version, loss_grounding=loss_grounding, honest=honest)
    _store_whale_score(conn, rep.score, now_ts)     # the deterministic score is stored REGARDLESS of the narration

    day = _utc_day(now_ts)
    cap_hit = _cap_hit(conn, day, daily_cap_usd)
    nr = narrate(rep, narrator_enabled=narrator_enabled, chat=chat, cap_hit=cap_hit)
    if nr.cost_usd and nr.cost_usd > 0:                                         # an API call that cost money
        _book_cost(conn, day, nr.cost_usd, now_ts)

    rep = replace(rep, verdict=nr.narration, null_reason=nr.null_reason, model=nr.model,
                  cost_usd=nr.cost_usd, tokens_in=nr.tokens_in, tokens_out=nr.tokens_out,
                  served_from_cache=False)
    if nr.narration is not None:                                               # cache SUCCESS only
        _cache_put(conn, rep)
    if hasattr(conn, "commit"):
        conn.commit()
    return rep


__all__ = [
    "PMAnalysisReport", "SampleRow", "NarrationResult",
    "PM_ANALYZE_MODEL", "PM_ANALYZE_DAILY_CAP_USD", "PM_ANALYZE_SKILL_VERSION",
    "NULL_DISABLED", "NULL_NO_DATA", "NULL_CAP", "NULL_UNAVAILABLE", "NULL_ERROR", "NULL_REASON_LABELS",
    "build_pm_analysis", "analysis_flags", "narrate", "analyze_whale",
    "is_llm_available", "is_cached", "daily_cost", "report_to_json", "report_from_json",
]
