"""pm_web ASGI app (FastAPI) -- standalone Prediction Markets web. Launched by scripts/pm_web.py (uvicorn).

STANDALONE by construction: imports ONLY fastapi + the PM package (db / stats / category). NO engine imports
(trading_corp.web / main / agents), NO WebDeps, NO agent handles -- proven by test_pm_web_imports_no_engine.
(stats pulls trading_corp.data.kalshi_whale_stats for the ranking primitives -- data layer, NOT web/main/agents.)
Reads/writes ONLY data/prediction_markets.db (prediction_markets.db._assert_not_legacy hard-guards the path).
Reuses the engine web IDIOM (FastAPI + the off-loop `asyncio.to_thread` read pattern, mace_view) but not the process.

ROUTES (M2 2026-09-01: multi-account -- / is the ACCOUNTS OVERVIEW, the new top of the hierarchy, R1):
  GET  /                              -> accounts overview (pm_accounts.html): per-account PM P&L, DISPLAY-ONLY
  GET  /account/{account_id}         -> one account's per-sub-division P&L (pm_account.html); display-only note if untraded
  GET  /farm                          -> the Farm-League category tiles (pm_farm_league.html)
  GET  /farm/{category}               -> the per-category page: Watchlist (paper) + Prospects (completed)
  GET  /whale/{wallet}[/{category}]   -> a PROSPECT / completed drill-through (reuses pm_position_rows.html)
  GET  /watchlist/{wallet}/{category} -> a WATCHLIST / paper detail (all paper trades + paper stats)
  POST /farm/analyze/{wallet}/{category} -> on-demand Analyze (the ONE write surface besides sync-names)
  GET  /healthz                       -> liveness + PM-DB readiness
Vendored assets ONLY (/static/htmx.min.js, /static/pm.css) -- NO CDN on a network-exposed host, no build step.
Spec: reports/prediction_markets/PM_REBUILD_PLAN_2026-08-26.md (Stage 2, the phase-3 repoint deliverable).
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import subprocess
import sys
import time
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from ..db import connect, pm_db_path
from .. import stats, positions, names, farm, farm_actions, analyze, subdivision, search, loss_grounding, arm, shard_snapshot, heartbeat, scoring
from .. import tradable_categories   # item 3 (2026-09-15): dependency-free matcher-backed set; hides matcherless SUB-DIVISION tiles (orphans). No broker/pykalshi import (pm_web is credential-free).


def _tile_visible(category: str, has_footprint: bool) -> bool:
    """A SUB-DIVISION tile shows iff its category CAN trade (has a matcher) OR it has a real FOOTPRINT
    (attached whales / placed orders / open positions). item 3 (2026-09-15): hiding is for INERT matcherless
    orphans ONLY (the kalshi_jack/soccer+tennis mis-attaches: 0 whales, 0 orders) -- ★ money-aware after the
    adversarial review, so a matcherless sub that somehow holds money at risk is NEVER hidden (it stays visible
    AND its P&L keeps reconciling the account total, since a HIDDEN sub is footprint-free -> contributes 0)."""
    return tradable_categories.is_tradable_category(category) or bool(has_footprint)
from .. import sizing   # per-sub-division flat-contracts sizing from the UI (2026-09-12): reader + owner/admin-gated write + audit
from . import authz   # M4: fail-closed identity/admin resolution + account-visibility scoping (reads headers+env only)
from . import live_view, poller, ui_cache   # UI rewrite: game-card assembly + the 60s feed/marks poller + its cache
from ..market_describe import describe_market
from ..category import NON_SINGLE_GAME_CATEGORIES, derive_category_from_slug

log = logging.getLogger(__name__)

_PKG_DIR = Path(__file__).resolve().parent
_TEMPLATE_DIR = _PKG_DIR / "templates"
_STATIC_DIR = _PKG_DIR / "static"

# loopback-only + behind Authelia => no OpenAPI/docs surface exposed.
app = FastAPI(title="pm_web", docs_url=None, redoc_url=None, openapi_url=None)
app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")

templates = Jinja2Templates(directory=str(_TEMPLATE_DIR))
# Expose the non-single-game category set so the template can render single_game_pct as "n/a" (NOT 0%) for
# fed/unknown -- the whole reason OQ-2 was ruled NULL. Truth stays in category.py; the template only reads it.
templates.env.globals["non_single_game_categories"] = sorted(NON_SINGLE_GAME_CATEGORIES)
# R4: the F-1 loss-omission caveat has ONE definition (search.LOSS_OMISSION_CAVEAT) so the prospects screen
# and any report word the bias identically. The thin-sample FLOOR (candidates below it came via the <10-qualifier
# fallback) is likewise the ruled constant -- a candidate with n_resolved < floor is thin-sample by construction.
templates.env.globals["loss_omission_caveat"] = search.LOSS_OMISSION_CAVEAT
templates.env.globals["thin_sample_floor"] = search.DEFAULT_MIN_RESOLVED_FLOOR
# Plain-language market descriptions (interim item a): translate a Kalshi ticker (+ held leg) to a human sentence
# in the /live table. Pure/standalone -- market_describe imports only the data-layer team map + ticker parsers.
# The RAW ticker stays shown beneath it (translated + raw -- honest, and the raw is still there for precision).
templates.env.globals["describe_market"] = describe_market


def _utcdate(ts) -> str:
    """unix ts -> 'YYYY-MM-DD' (UTC); em-dash for missing/zero. Registered as the `utcdate` Jinja filter
    for the position-row renderer (honest-empty date, never a fake 1970)."""
    if isinstance(ts, (int, float)) and ts:
        return time.strftime("%Y-%m-%d", time.gmtime(int(ts)))
    return "—"


templates.env.filters["utcdate"] = _utcdate


def _utcdatetime(ts) -> str:
    """unix ts -> 'YYYY-MM-DD HH:MM:SSZ' (UTC); em-dash for missing/zero. Registered as the `utcdt` Jinja filter
    for the live-trade rows, where an intraday order needs the TIME, not just the date (an order and its exit can
    share a date)."""
    if isinstance(ts, (int, float)) and ts:
        return time.strftime("%Y-%m-%d %H:%M:%SZ", time.gmtime(int(ts)))
    return "—"


templates.env.filters["utcdt"] = _utcdatetime


# ── UI-rewrite display filters (money / signed / p&l class / relative age). Cost basis and current value are
# ALWAYS distinct strings, and a None value renders an em-dash, never $0.00 (unknown is not zero). ──────────────
def _money(v) -> str:
    if v is None:
        return "—"
    return ("-$%.2f" % abs(v)) if v < 0 else ("$%.2f" % v)


def _signed(v) -> str:
    if v is None:
        return "—"
    return ("+$%.2f" % v) if v >= 0 else ("-$%.2f" % abs(v))


def _pnlcls(v) -> str:
    if v is None or v == 0:
        return ""
    return "pos" if v > 0 else "neg"


def _agefmt(sec) -> str:
    """Relative age for a feed value. None -> 'unknown' (a value with no age is not a current value)."""
    if sec is None:
        return "unknown"
    sec = max(0, int(sec))
    if sec < 60:
        return "%ds ago" % sec
    if sec < 3600:
        return "%dm ago" % (sec // 60)
    return "%dh %dm ago" % (sec // 3600, (sec % 3600) // 60)


def _et(ts):
    from datetime import datetime, timezone
    if not ts:
        return None
    return live_view.feed_mlb.utc_to_eastern(datetime.fromtimestamp(int(ts), tz=timezone.utc))


def _ettime(ts) -> str:
    """unix ts -> 'HH:MM:SS' Eastern (the timezone MLB games + Kalshi tickers use); em-dash for missing."""
    et = _et(ts)
    return et.strftime("%H:%M:%S") if et else "—"


def _etdate(ts) -> str:
    et = _et(ts)
    return et.strftime("%Y-%m-%d") if et else "—"


def _etdt(ts) -> str:
    et = _et(ts)
    return et.strftime("%m-%d %H:%M ET") if et else "—"


templates.env.filters["money"] = _money
templates.env.filters["signed"] = _signed
templates.env.filters["pnlcls"] = _pnlcls
templates.env.filters["agefmt"] = _agefmt
templates.env.filters["ettime"] = _ettime
templates.env.filters["etdate"] = _etdate
templates.env.filters["etdt"] = _etdt


# ── the 60s feed/marks poller: ONE background task, started with the app, writing ui_cache (single-worker
# uvicorn). It does no DB access and reaches no order path -- purely network-into-cache. Guarded so a double
# startup (e.g. a test harness) never spawns two loops. ────────────────────────────────────────────────────────
_poller_task = None


def _held_series_provider():
    """The Kalshi series the mark poller should fetch, derived from every ticker we CURRENTLY HOLD across all
    sub-divisions (item 3) -- so ATP/UFC/WTA get priced the same as MLB, never a hardcoded MLB list. A short-lived
    read connection; returns () on any DB blip so the poller falls back to its MLB default. Runs inside the
    poller's synchronous refresh pass (already off the event loop), so a blocking DB read is fine here."""
    try:
        with connect() as conn:
            return subdivision.traded_series(conn)
    except Exception:   # noqa: BLE001 -- a series-read blip must not sink the refresh; MLB default takes over
        return ()


@app.on_event("startup")
async def _start_poller() -> None:
    global _poller_task
    if _poller_task is None or _poller_task.done():
        _poller_task = asyncio.create_task(
            poller.poll_loop(ui_cache.cache(), series_provider=_held_series_provider))
        log.info("pm_web: feed/marks poller started")


@app.on_event("shutdown")
async def _stop_poller() -> None:
    global _poller_task
    if _poller_task is not None and not _poller_task.done():
        _poller_task.cancel()
        try:
            await _poller_task
        except (asyncio.CancelledError, Exception):   # noqa: BLE001 -- shutdown must not raise
            pass
        _poller_task = None


def _pm_db_schema_version() -> int | None:
    """Short-lived read connection; reads ONLY prediction_markets.db (db._assert_not_legacy guards the path)."""
    with connect() as conn:
        row = conn.execute("SELECT MAX(version) AS v FROM schema_version").fetchone()
        return int(row["v"]) if row is not None and row["v"] is not None else None


@app.get("/healthz")
async def healthz():
    """Liveness + PM-DB readiness. The DB read runs OFF the event loop (`asyncio.to_thread`) so a slow/locked DB
    can never block pm_web. 200 when the PM DB is reachable + migrated; 503 'degraded' otherwise -- honest,
    never a faked 200."""
    try:
        version = await asyncio.to_thread(_pm_db_schema_version)
    except Exception as exc:  # noqa: BLE001 -- healthz must never raise; report degraded honestly
        return JSONResponse(
            status_code=503,
            content={"status": "degraded", "service": "pm_web", "error": type(exc).__name__},
        )
    return {"status": "ok", "service": "pm_web", "pm_db_schema_version": version}


# ── whale detail + drill-through (COMPLETED basis -- the PROSPECT drill, Ruling R5) ───────────────

def _applicable_drills(category: str | None) -> list[str]:
    """Drill tabs valid for this category. single_game is dropped for fed/unknown (no single-game
    notion, OQ-2) so the toolbar never offers a drill that would render honest-empty by definition."""
    ds = ["scoreable", "won", "two_sided"]
    if category not in NON_SINGLE_GAME_CATEGORIES:
        ds.append("single_game")
    ds += ["quarantined", "all"]
    return ds


def _clamp_drill(drill: str | None, category: str | None) -> str:
    """Coerce a hand-editable ?drill= to a safe value (never 422). Unknown -> scoreable; single_game on
    fed/unknown -> scoreable (that category has no single-game notion)."""
    d = drill if drill in positions.DRILLS else "scoreable"
    if d == "single_game" and category in NON_SINGLE_GAME_CATEGORIES:
        d = "scoreable"
    return d


def _load_whale_overview(wallet: str, now_ts: int) -> dict:
    """Whale + its (wallet, category) slices + freshness, on ONE short-lived read connection, OFF the loop."""
    with connect() as conn:
        whale = positions.whale_row(conn, wallet)
        cats = positions.whale_categories(conn, wallet)
        refresh = stats.refresh_band_state(stats.max_refresh_ts(conn), now_ts)
    return {"whale": whale, "cats": cats, "refresh": refresh}


def _load_whale_detail(wallet: str, category: str, drill: str, now_ts: int) -> dict:
    """The whale-detail read: header + score decomposition + caveat profile + the selected drill's rows
    with its reconciliation, on ONE short-lived read connection, OFF the loop."""
    with connect() as conn:
        whale = positions.whale_row(conn, wallet)
        cstats = positions.category_stats_row(conn, wallet, category)
        onesided = positions.onesided_row(conn, wallet, category)
        decomp = positions.score_decomposition(conn, wallet, category)
        rows = positions.drill_rows(conn, wallet, category, drill)
        recon = positions.reconcile(conn, wallet, category, drill, rows)
        refresh = stats.refresh_band_state(stats.max_refresh_ts(conn), now_ts)
        name_sync = names.last_sync(conn)
    return {"whale": whale, "cstats": cstats, "onesided": onesided, "decomp": decomp, "rows": rows,
            "recon": recon, "refresh": refresh, "name_sync": name_sync,
            "drill_label": positions.DRILL_LABELS.get(drill)}


def _load_drill(wallet: str, category: str, drill: str) -> dict:
    """Just the selected drill's rows + reconciliation (the HTMX partial), OFF the loop."""
    with connect() as conn:
        rows = positions.drill_rows(conn, wallet, category, drill)
        recon = positions.reconcile(conn, wallet, category, drill, rows)
    return {"rows": rows, "recon": recon, "drill_label": positions.DRILL_LABELS.get(drill)}


@app.get("/whale/{wallet}", response_class=HTMLResponse)
async def whale_overview(request: Request, wallet: str):
    """Overview for a bare wallet: the categories this whale has, each linking to the drill-through detail.
    Honest-empty (200) for an unknown wallet -- never a 404-shaped fabrication."""
    wallet = (wallet or "").lower()
    data = await asyncio.to_thread(_load_whale_overview, wallet, int(time.time()))
    return templates.TemplateResponse(request, "pm_whale_overview.html", {"request": request, "wallet": wallet, **data})


@app.get("/whale/{wallet}/{category}", response_class=HTMLResponse)
async def whale_detail(request: Request, wallet: str, category: str, drill: str | None = None):
    """The 'why is this ranked here' destination + the drill panel. ?drill= pre-selects a drill so a direct
    link (and JS-off navigation from a prospect caveat cell) lands on the right rows."""
    wallet = (wallet or "").lower()
    d = _clamp_drill(drill, category)
    data = await asyncio.to_thread(_load_whale_detail, wallet, category, d, int(time.time()))
    ctx = {"request": request, "wallet": wallet, "category": category, "drill": d,
           "drills": _applicable_drills(category), **data}
    return templates.TemplateResponse(request, "pm_whale.html", ctx)


@app.get("/whale/{wallet}/{category}/positions", response_class=HTMLResponse)
async def whale_positions(request: Request, wallet: str, category: str, drill: str | None = None):
    """The ONE shared row renderer as an HTMX partial -- the drill-panel swap target. Same renderer the
    whale detail includes server-side, so the two consumers can never diverge (parity)."""
    wallet = (wallet or "").lower()
    d = _clamp_drill(drill, category)
    data = await asyncio.to_thread(_load_drill, wallet, category, d)
    return templates.TemplateResponse(request, "partials/pm_position_rows.html", {"request": request, **data})


# ── on-demand ANALYZE (CP3b-2) -- the [Analyze] button on the Watchlist rows ─────────────────────
# This is the ONE pm_web write surface besides sync-names: it writes pm_analysis_cache + pm_analysis_cost in
# the PM DB (both inside the unit's ReadWritePaths=data). A cache hit spends nothing; the $20/day cap and the
# "only successful verdicts are cached" rule live in analyze.analyze_whale. The key is NOT wired (e3) so today
# every call returns the llm_unavailable reasoned-null and the deterministic report renders without a verdict.

def _row_category(row) -> str:
    """Category of an Activity/Closed row via the platform's TIER-1 slug-prefix deriver (sync, NO network) -- the
    SAME axis pm_closed_position.category is built on, so the re-grounded loss set filters on the same category as
    the deterministic core. Rows tier-1 cannot place (unknown) fall OUT of the category filter -> for them a_only is
    a conservative LOWER bound, never an over-count. (No tier-2 gamma-tag join here: grounding is a caveat, and one
    network round per analyze click is already the /activity + /closed-positions paging.)"""
    return derive_category_from_slug(getattr(row, "event_slug", None), getattr(row, "slug", None))[0]


# ── Stage 5 loss-omission SURFACING (2026-09-01): the omission % + its coverage travel BESIDE win% on both the ──────
# Analyze result and the Prospects LIST. The figure is COMPUTED ON ANALYZE (which already pays the /activity + gamma
# fetch) and CACHED per whale in pm_loss_grounding_cache with its own age; the LIST reads that cache -- grounding 131
# rows on render is not viable, and a background job would hammer the shared prod IP. A whale never Analyzed has NO
# cache row -> UNKNOWN, never 0% (a 0 that means 'nobody checked' is the safety-check-that-stops-checking shape).
def _upsert_loss_grounding(conn, wallet: str, category: str, g, now_ts: int) -> None:
    """Cache this whale's re-grounded loss omission so the Prospects LIST can show it without re-fetching. Written on
    every Analyze (re)grounding; PK (wallet, category) -> one row per slice, grounded_ts = the figure's OWN age."""
    conn.execute(
        "INSERT OR REPLACE INTO pm_loss_grounding_cache(wallet, category, honest_wins, honest_losses, a_only_losses, "
        "loss_omission_pct, coverage_pct, activity_truncated, n_activity_held_resolved, completeness, grounded_ts) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (wallet, category, g.honest_wins, g.honest_losses, g.a_only_losses, g.loss_omission_pct, g.coverage_pct,
         1 if g.activity_truncated else 0, g.n_activity_held_resolved, g.completeness, int(now_ts)))
    conn.commit()


def _loss_omission_cell(entry: dict | None, now_ts: int) -> dict:
    """Render-ready omission cell for a prospect row. entry=None (this whale was NEVER Analyzed) -> known=False =
    UNKNOWN (the template shows 'omission unknown -- Analyze'), NEVER 0%. A 0 that means 'nobody looked' is exactly the
    display Jack flagged as the worst possible: it reads as 'no omission' when it means 'unchecked'."""
    if not entry:
        return {"known": False}
    ts = entry.get("grounded_ts") or 0
    cov = entry.get("coverage_pct")
    truncated = bool(entry.get("activity_truncated"))
    return {"known": True, "omission_pct": entry.get("loss_omission_pct"), "coverage_pct": cov,
            "a_only_losses": entry.get("a_only_losses"), "honest_wins": entry.get("honest_wins"),
            "honest_losses": entry.get("honest_losses"), "truncated": truncated,
            # FLOOR = truncated OR under-covered (older losers beyond the window) -- NOT truncation alone, so a
            # low-coverage-but-untruncated omission is not shown as a full measurement.
            "floor": bool(truncated or (cov is not None and cov < analyze.LOSS_COVERAGE_FLOOR)),
            "age_days": ((now_ts - ts) / 86400.0) if ts else None}


def _load_loss_grounding_map(conn, category: str) -> dict:
    """{wallet: <cache row dict>} for every Analyzed whale in this category. Absent wallets stay absent ->
    _loss_omission_cell(None) = UNKNOWN. One scan of the per-category-indexed cache; ~O(candidates)."""
    return {r["wallet"]: dict(r) for r in conn.execute(
        "SELECT wallet, honest_wins, honest_losses, a_only_losses, loss_omission_pct, coverage_pct, "
        "activity_truncated, grounded_ts FROM pm_loss_grounding_cache WHERE category=?", (category,)).fetchall()}


# ── the stored promotion-judge SCORE on the list (migration 023 pm_whale_score) ───────────────────────────
_SCORE_UNANALYZED_SORT = -1e12   # composite convention is higher=better, so un-analyzed is the LOWEST rank. The
                                 # Prospects <td> NEGATES sort_value for the ascending-first client sorter, so this
                                 # lands un-analyzed at the BOTTOM. The cell still reads "not analyzed", never a 0 score.


def _score_cell(row: dict | None, now_ts: int) -> dict:
    """Render-ready pm_whale_score cell for a whale row. row=None (this whale was NEVER Analyzed) -> analyzed=False
    -> the template shows 'not analyzed' + an [Analyze] control, NEVER a 0/low score (NULL is not zero -- the exact
    display Jack flagged). `sort_value` carries the TIER-then-number composite (scoring.score_sort_key) so the tier
    CAPS the number in a single-column client sort; un-analyzed gets a bottom sentinel. `flagged` marks a number that
    is NOT a clean read (ungrounded, or grounded with dropped losses / sub-floor coverage) so the figure travels with
    its caveat onto the row, not just into the Analyze narration."""
    if not row:
        return {"analyzed": False, "sort_value": _SCORE_UNANALYZED_SORT}
    try:
        tier = row.get("tier")
        sort_roi = row.get("sort_roi")
        grounded = bool(row.get("grounded"))
        cov = row.get("coverage_pct")
        omis = row.get("omission_pct")
        floor = bool(row.get("omission_floor")) or (grounded and cov is not None and cov < analyze.LOSS_COVERAGE_FLOOR)
        ts = row.get("computed_ts") or 0
        key = scoring.score_sort_key(tier, sort_roi)
        return {
            "analyzed": True, "tier": tier, "tier_rank": scoring.tier_rank(tier), "reason": row.get("reason"),
            "sort_roi": sort_roi, "honest_roi": row.get("honest_roi"), "grounded": grounded,
            "omission_pct": omis, "coverage_pct": cov, "floor": floor,
            "dominance_net": row.get("dominance_net"), "two_sided_pct": row.get("two_sided_pct"),
            "chalk": bool(row.get("chalk")), "copy_fills": row.get("copy_fills"),
            "flagged": (not grounded) or (omis is not None and omis > 0) or floor,
            "sort_value": key if key is not None else _SCORE_UNANALYZED_SORT,
            "age_days": ((now_ts - ts) / 86400.0) if ts else None,
        }
    except Exception:  # noqa: BLE001 -- a malformed score row must degrade to 'not analyzed', NEVER 500 the list page
        return {"analyzed": False, "sort_value": _SCORE_UNANALYZED_SORT}


def _load_whale_score_map(conn, category: str) -> dict:
    """{wallet: <pm_whale_score row dict>} for every Analyzed whale in this category (migration 023). Absent wallets
    stay absent -> _score_cell(None) = 'not analyzed'. One category-indexed scan; honest-empty if the table is absent
    (pre-023) so the list never 500s."""
    try:
        return {r["wallet"]: dict(r) for r in conn.execute(
            "SELECT wallet, tier, reason, sort_roi, honest_roi, grounded, omission_pct, coverage_pct, "
            "omission_floor, dominance_net, two_sided_pct, chalk, copy_fills, computed_ts "
            "FROM pm_whale_score WHERE category=?", (category,)).fetchall()}
    except Exception:  # noqa: BLE001 -- absent table (pre-migration-023) -> honest-empty, never a 500
        return {}


def _run_analyze(wallet: str, category: str, force: bool, now_ts: int, loss_grounding=None, honest=None) -> dict:
    """Run Analyze on ONE short-lived connection, OFF the event loop. WRITES the PM DB (cache + cost ledger);
    reads/writes ONLY prediction_markets.db (db._assert_not_legacy guards the path). Sync (analyze narrates
    synchronously) so it drops straight into asyncio.to_thread with no nested event loop. `loss_grounding` (Stage 5)
    is the re-grounded loss set the async route fetched on a miss; None -> the report renders ungrounded."""
    with connect() as conn:
        rep = analyze.analyze_whale(conn, wallet, category, now_ts=now_ts, force=force,
                                    loss_grounding=loss_grounding, honest=honest)
        if loss_grounding is not None:                        # (re)grounded THIS click -> cache the omission so the
            _upsert_loss_grounding(conn, wallet, category, loss_grounding, now_ts)   # Prospects LIST can show it beside win%
        day = analyze._utc_day(now_ts)
        spent, n_calls = analyze.daily_cost(conn, day)
    # OOB row-update for the JUDGE column (the loop closing on the LIST): built from THIS run's stored score so the
    # Prospects/Watchlist/roster cell for this whale flips 'not analyzed' -> the graded verdict in place. rep.score is
    # the WhaleScore asdict (same keys _score_cell reads); None (nothing scoreable) -> stays 'not analyzed'.
    return {"report": rep, "flags": analyze.analysis_flags(rep),
            "cost_today": spent, "cost_cap": analyze.PM_ANALYZE_DAILY_CAP_USD, "cost_day": day,
            "score_oob": _score_cell(getattr(rep, "score", None), now_ts),
            # item 5 (2026-09-15): the stats.py farm-ranking metrics for the panel (clean shown + fed; inverting shown flagged).
            "ranking_metrics": analyze.ranking_metrics(rep)}


def _analysis_is_cached(wallet: str, category: str) -> bool:
    """Off-loop cache PEEK: is there a stored verdict for this (wallet, category, current skill_version)? Governs
    whether the route pays for the /activity loss-grounding fetch AT ALL -- a cache HIT skips the network entirely,
    so the 'a hit spends nothing' contract holds for the /activity fetch too, not just the LLM call."""
    with connect() as conn:
        return analyze.is_cached(conn, wallet, category)


async def _ground_losses(wallet: str, category: str):
    """Re-ground the whale's LOSS set for (wallet, category) from /activity (Stage 5, the F-1 held-to-worthless
    bias). Returns a LossGrounding or None. FAIL-SOFT: any network/parse failure -> None and Analyze proceeds
    UNGROUNDED (the honest-loss block simply does not render) -- the grounding is a caveat enrichment, NEVER
    load-bearing for the deterministic report. Network runs ON the loop (its awaits yield); the lazy import keeps
    the data-layer client off the module import surface (the standalone-imports guard, test_pm_web_imports_no_engine)."""
    try:
        from ...data.polymarket_data_api_client import PolymarketDataAPIClient
        async with PolymarketDataAPIClient() as client:
            g, honest = await loss_grounding.fetch_and_ground_losses(client, wallet, category, category_of=_row_category)
        # Only surface a grounded block when /activity actually yielded in-category held-to-resolution decisions to
        # compare against. A zero-decision fetch has NOTHING to affirm -- rendering "0W/0L honest" would imply we
        # checked and found nothing when we may simply have no activity feed for this slice -- so treat it as
        # UNGROUNDED (no block), the honest degrade. `honest` (Phase A) travels with the grounding.
        return (g, honest) if (g is not None and g.n_activity_held_resolved > 0) else (None, None)
    except Exception as exc:   # noqa: BLE001 -- caveat enrichment must never break Analyze; degrade to ungrounded
        log.warning("pm analyze: loss-grounding failed for %s/%s (%s) -- rendering ungrounded",
                    wallet[:10], category, type(exc).__name__)
        return (None, None)


@app.post("/farm/analyze/{wallet}/{category}", response_class=HTMLResponse)
async def farm_analyze(request: Request, wallet: str, category: str, force: str | None = None):
    """Analyze a (wallet, category) and swap in the result partial. POST because it may WRITE (narrate ->
    cache + cost). `?force=1` re-analyzes (evicts the cached verdict first). Identity is the (wallet, category),
    not which list the button sat in. Stage 5: re-ground the loss set from /activity ONLY when we will actually
    (re)build -- a cache HIT skips the /activity fetch, so a hit still spends nothing."""
    wallet = (wallet or "").lower()
    category = (category or "").strip().lower()
    do_force = str(force or "").strip().lower() in ("1", "true", "yes", "on")
    now_ts = int(time.time())
    grounding, honest = None, None
    if do_force or not await asyncio.to_thread(_analysis_is_cached, wallet, category):
        grounding, honest = await _ground_losses(wallet, category)       # async network ON the loop; (None,None) on failure
    data = await asyncio.to_thread(_run_analyze, wallet, category, do_force, now_ts, grounding, honest)
    return templates.TemplateResponse(request, "partials/pm_analyze_result.html", {"request": request, **data})


# ── THE FARM-LEAGUE HIERARCHY (Stage 2) -- these ARE the app's screens ────────────────────────────
# Phase 3 repointed these onto the good URLs (/ , /farm, /farm/{category}) and RETIRED the flat scoreboard/farm
# pages they replace. READ-ONLY: no write, no rollup, no migration. The two per-category regions read SEPARATE
# bases by construction: Watchlist(pinned) -> pm_paper_category_stats (paper); Prospects(candidate) ->
# query_scoreboard over pm_category_stats (completed). The three-lists / three-bases invariant holds on one page.

def _load_farm_league() -> dict:
    """Farm-League tile read. Tiles = `farm.league_categories()` = the RULED 15-category allowlist (Jack
    2026-08-30, the tile-vanish fix). A category EXISTS iff it is in the allowlist and not deactivated (deactivated
    = not in the allowlist). NOT driven by pinned rows: an empty watchlist is legitimate, so a category with
    prospects-but-no-pinned (or with neither) STILL renders its tile -- data stranded behind a missing tile is the
    class of defect this closes. The pair-grain active flag governs list membership, not tile existence. The
    allowlist is a constant. Also reads the latest SEARCH run state (the single-flight status the discovery
    panel shows: idle / running / done / error / stale) -- one small DB read. OFF the loop."""
    from ..search_run import latest_search_status
    with connect() as conn:
        search_status = latest_search_status(conn, now_ts=int(time.time()))
    return {"categories": farm.league_categories(), "search_status": search_status}


# ★ PROSPECTS FLOOR (2026-09-15): the Prospects section must show the SELECTOR's thin-sample candidates. A
# candidate below the N>=50 selector floor was written via search.select_candidates' <10-qualifier top-10
# fallback -- it is THIN BY CONSTRUCTION, not disqualified (Jack: "a category ALWAYS shows its top 10, flagged
# thin; thin n is EXPECTED"). query_scoreboard's DEFAULT min_resolved (=10, tuned for the general ranker) would
# SILENTLY DROP every such candidate before the thin_sample tagging + THIN badge below ever run -- the display
# gate that hid boxing/f1 (and ~565 thin candidates across 24 cats). This section OVERRIDES the floor to 1 so
# every active candidate renders; the THIN badge + the SCREEN-ONLY win%-caveat carry the under-evidence. The
# override is SCOPED to this call site -- every other query_scoreboard caller (report CLI, etc.) keeps the default.
PROSPECTS_MIN_RESOLVED = 1


def _load_farm_category(category: str, now_ts: int) -> dict | None:
    """Per-category read. Returns None when `category` is NOT a league category (not in the allowlist: deactivated
    / unknown / nonexistent) so the route can 404 -- a deactivated category must not be reachable by URL. Existence
    is `farm.is_league_category` = allowlist membership (Jack 2026-08-30), NOT pinned rows: an allowlist category
    with an EMPTY WATCHLIST renders normally (Watchlist honest-empty, Prospects populated -- the two sections read
    different bases, and Prospects does not depend on the watchlist at all), so its prospects are never stranded.

    THE BASIS SEPARATION IS THE POINT (three lists / three bases):
    - WATCHLIST (pinned) -> `farm.farm_rows(status=PINNED)` -> pm_paper_category_stats (PAPER basis).
    - PROSPECTS (candidate) -> the F-4 repurposed `stats.query_scoreboard` RANKER -> pm_category_stats
      (COMPLETED basis), SCOPED to this category's candidate set. query_scoreboard already active-gates,
      category-scopes and ranks; we filter its board to the candidate wallets so the section shows candidates
      ONLY (never pinned). The two sections never share a query or a table."""
    if not farm.is_league_category(category):   # existence = allowlist membership, NOT pinned rows (Jack 2026-08-30)
        return None
    with connect() as conn:
        watchlist = farm.farm_rows(conn, status=farm.PINNED, category=category)        # PAPER basis (pinned) -- [] when empty
        cand_wallets = {r["wallet"] for r in
                        farm.farm_rows(conn, status=farm.CANDIDATE, category=category)}   # candidate SET (active-gated)
        board = stats.query_scoreboard(conn, category=category,                         # completed-basis ranker (F-4)
                                       min_resolved=PROSPECTS_MIN_RESOLVED)             # thin-inclusive (2026-09-15 floor override)
        prospects = [r for r in board if r["wallet"] in cand_wallets]                   # ranked, candidates only (incl. thin)
        # R4 DEFAULT ORDER = cost-ROI DESCENDING (Jack ruled): the first view is what gets looked at most. The
        # ranker's own ORDER BY leads with score; here the SCREEN's default axis is cost-ROI (roi-None sorts last).
        # The client-side column sort re-orders on demand; this only sets the LOAD order.
        prospects.sort(key=lambda r: (r.get("roi") is None, -(r.get("roi") or 0.0)))
        lg_map = _load_loss_grounding_map(conn, category)                               # per-whale omission cache (Analyze-fed)
        score_map = _load_whale_score_map(conn, category)                               # per-whale stored score (Analyze-fed, mig 023)
        for r in prospects:
            r["flags"] = stats.scoreboard_flags(r)                                      # same tokens as CLI/scoreboard
            # THIN-SAMPLE (visible, not inferable): a candidate BELOW the N floor came in via the <10-qualifier
            # top-10 fallback (the normal path needs n>=floor), so n_resolved<floor IS thin-sample -- no new column.
            r["thin_sample"] = (r.get("n_resolved") or 0) < search.DEFAULT_MIN_RESOLVED_FLOOR
            # LAST-UPDATED per whale (on-demand ruling): staleness VISIBLE per-whale, never silent.
            r["last_refresh"] = stats.refresh_band_state(r.get("last_refresh_ts"), now_ts)
            # ★ LOSS-OMISSION BESIDE win% (Stage 5): the caveat travels with the number it corrupts. UNKNOWN (not 0%)
            # for a whale never Analyzed -- the omission is COMPUTED ON ANALYZE and cached, not grounded on list render.
            r["loss_omission"] = _loss_omission_cell(lg_map.get(r["wallet"]), now_ts)
            # ★ THE STORED PROMOTION-JUDGE SCORE (mig 023): tier + sort number + trust-flags on the row; the tier caps
            # the sort. UN-analyzed -> 'not analyzed' (never a 0), distinct from an analyzed-and-PASS row.
            r["score"] = _score_cell(score_map.get(r["wallet"]), now_ts)
        for wr in watchlist:                                                            # keep the verdict visible after Promote-to-Watchlist
            wr["score"] = _score_cell(score_map.get(wr["wallet"]), now_ts)
        refresh = stats.refresh_band_state(stats.max_refresh_ts(conn), now_ts)
        # R6: the ACTIVE accounts = the promote-to-LIVE targets. Auto-create (ruling 1) makes the (account,
        # category) sub-division on demand, so a Watchlist row offers "promote to <account>", not a pre-existing
        # sub-division. Empty until an account is provisioned (credentialed) -> the honest inert note.
        live_accounts = subdivision.active_accounts(conn)
        # ★ LIVE-WHALE STATE (2026-09-11): which accounts ALREADY copy each pinned whale in THIS category, from the
        # SAME pm_subdivision_attachment the /live "Copies these whales" panel + the tile whale-count read (active=1
        # only -- a detached row, active=0, is NOT live). The Watchlist row shows a "<account> Live Whale" status
        # badge (not a Promote button) for each account it is already attached to, with the attachment age; Promote
        # remains only for the account(s) it is NOT live on. {wallet: {account_id: age_seconds}}. Read-only;
        # honest-empty (-> every row keeps its Promote buttons, i.e. today's behaviour) if the table is absent.
        live_attach: dict = {}
        try:
            for a in conn.execute("SELECT wallet, account_id, added_ts FROM pm_subdivision_attachment "
                                  "WHERE category = ? AND active = 1", (category,)):
                live_attach.setdefault(a["wallet"], {})[a["account_id"]] = (
                    (now_ts - int(a["added_ts"])) if a["added_ts"] is not None else None)
        except Exception:   # noqa: BLE001 -- absent table (pre-migration-010) -> honest-empty, never a 500
            live_attach = {}
    return {"category": category, "watchlist": watchlist, "prospects": prospects, "refresh": refresh,
            "live_accounts": live_accounts, "live_attach": live_attach}


# ── Multi-account (M2, 2026-09-01): the accounts overview (the new top of the hierarchy, R1) + per-account page. ──
# DISPLAY-ONLY (ruled): these render PM's journal-derived P&L per account; they carry NO arm/attach control (R4:
# the global arm STATE is visible read-only, the CONTROL is admin-only + M5). An account with 0 PM sub-divisions is
# NOT traded by PM -- the page states that in the copy, never an empty frame implying it will fill (per-account
# TRADING is a filed, gated phase -- NOT_SCOPED_REVIEW_2026-09-01.md). realized/win-loss/SAMPLE/open-at-cost are
# shown SEPARATELY with the thin-sample caveat travelling WITH the number (the R2c display discipline).

def _annotate_pnl(a: dict, floor: int) -> None:
    a["pm_traded"] = a.get("n_subdivisions", 0) > 0
    a["thin_sample"] = a.get("n_closed", 0) < floor


def _iso_age(ts_str, now_ts: int):
    """ISO8601 arm-row write-timestamp -> age in seconds vs now_ts, or None -- the arm badge's age chip."""
    if not ts_str:
        return None
    try:
        from datetime import datetime
        dt = datetime.fromisoformat(str(ts_str).replace("Z", "+00:00"))
        return max(0, now_ts - int(dt.timestamp()))
    except (ValueError, TypeError, OSError):
        return None


def _arm_badge(account_id: str | None = None, category: str | None = None, *, now_ts: int) -> dict:
    """The READ-ONLY arm badge context from the PERSISTED agent_state rows (arm.read_display). State is one of
    armed/disarmed/absent/unavailable; 'unavailable' (an INDETERMINATE mode=ro read) is shown as such, NEVER as
    a disarm -- a status read near a restart is a false disarm, and the persisted row + its ts are the truth.
    The row's own ts becomes the badge age. pm_web only DISPLAYS; the CLI stays the authoritative kill path."""
    d = arm.read_display(account_id, category)
    d["global_age"] = _iso_age(d.get("global_ts"), now_ts)
    if account_id and category:
        d["effective_age"] = _iso_age(d.get("effective_ts"), now_ts)
    return d


def _cache_marks():
    """The cached Kalshi marks (dict) + the cache's refresh age, or ({}, None). pm_web NEVER reads the venue --
    this is the background poller's cache."""
    snap = ui_cache.cache().snapshot()
    marks = snap.marks.marks if (snap.marks is not None and getattr(snap.marks, "marks", None)) else {}
    return marks, snap.refreshed_ts


def _account_open_value(conn, account_row: dict, marks: dict) -> dict:
    """Current value of an account's OPEN positions at contracts x held-leg BID (across its sub-divisions), from
    the cached marks. Honest coverage flags travel with it (see live_view.value_positions)."""
    positions = []
    for sub in account_row.get("subdivisions", []) or []:
        positions.extend(subdivision.live_positions(conn, sub["account_id"], sub["category"]))
    return live_view.value_positions(positions, marks)


# M4 account SCOPING: the overview + the account page are filtered by web.authz.visible_account_ids (fail-closed --
# admin sees all; a non-admin sees ONLY accounts whose owner_identity == their Authelia identity; a NULL owner is
# admin-only; no identity -> nothing). identity + admin are resolved ON the loop from the request (headers+env, cheap)
# and passed into the OFF-loop loader, so the thread never touches the request object. _FORBIDDEN distinguishes an
# account that EXISTS but this identity may not see (403) from one that does not exist (None -> 404).
_FORBIDDEN = object()


def _load_accounts_overview(identity: str | None = None, is_admin_flag: bool = False) -> dict:
    """Every VISIBLE active account with its PM realized P&L / win-loss / sample size / open-at-cost + whether PM
    trades it, a COMPACT balance (latest snapshot total + age band), plus the GLOBAL arm state (read-only, R4). The
    account set is SCOPED to `identity`/`is_admin_flag` (fail-closed) BEFORE any balance read -- a non-admin never
    sees, nor loads a balance for, an account that is not theirs. OFF the loop; PM DB + a read-only legacy
    agent_state read. NEVER a venue read (pm_web is credential-free)."""
    floor = search.DEFAULT_MIN_RESOLVED_FLOOR
    marks, value_as_of = _cache_marks()
    with connect() as conn:
        accounts = subdivision.accounts_overview(conn)                    # each row carries owner_identity (M4)
        visible = authz.visible_account_ids(identity, is_admin_flag, accounts)
        accounts = [a for a in accounts if a["account_id"] in visible]    # SCOPE first -> then read balances
        # L3 DRIVER LIVENESS (read-only): the EXPECTED (attachment-gated) set + heartbeats, banded by age -- the
        # signal arm state cannot give. table_present distinguishes 'migration 020 not applied' from 'not written yet';
        # alarm bool is GATED on it so a not-deployed monitor reads NEUTRAL, never red (don't cry wolf about the monitor).
        liveness_present = heartbeat.table_present(conn)
        all_liveness = heartbeat.read_liveness(conn, now_ts=int(time.time()))
        for a in accounts:
            a["shard_snap"] = shard_snapshot.read_latest(conn, a["account_id"])   # None -> tile omits balance (honest)
            a["open_value"] = _account_open_value(conn, a, marks)         # contracts x bid (cached marks), coverage-honest
            a["liveness"] = [r for r in all_liveness if r.account_id == a["account_id"]]
            a["liveness_alarm"] = liveness_present and heartbeat.any_alarm(a["liveness"])
    for a in accounts:
        _annotate_pnl(a, floor)
    now_ts = int(time.time())
    visible_liveness = [r for r in all_liveness if r.account_id in visible]
    return {"accounts": accounts, "arm_badge": _arm_badge(now_ts=now_ts), "thin_floor": floor,
            "value_as_of": value_as_of, "now_ts": now_ts,
            "liveness_present": liveness_present, "liveness": visible_liveness,
            "any_liveness_alarm": liveness_present and heartbeat.any_alarm(visible_liveness)}


def _load_account(account_id: str, identity: str | None = None, is_admin_flag: bool = False):
    """One account's per-sub-division P&L breakdown + the global arm state (read-only). None -> 404 (account absent
    or inactive); `_FORBIDDEN` -> 403 (account EXISTS but this identity may not see it -- fail-closed scoping). The
    display-only note is data-driven (0 sub-divisions -> PM does not trade it)."""
    floor = search.DEFAULT_MIN_RESOLVED_FLOOR
    with connect() as conn:
        accts = {a["account_id"]: a for a in subdivision.active_accounts(conn)}   # carries owner_identity (M4)
        if account_id not in accts:
            return None                                                  # does not exist -> 404
        if account_id not in authz.visible_account_ids(identity, is_admin_flag, accts.values()):
            return _FORBIDDEN                                            # exists but not yours -> 403
        agg = subdivision.account_pnl(conn, account_id)
        marks, value_as_of = _cache_marks()
        agg["open_value"] = _account_open_value(conn, agg, marks)         # contracts x bid (cached marks)
        meta_by_cat = {s["category"]: s for s in subdivision.list_subdivisions(conn)
                       if s["account_id"] == account_id}                  # sub_label / market_types / whale+order counts
        # item 3 (2026-09-15): hide INERT MATCHERLESS sub-divisions from the account breakdown too (same rule as
        # /live) -- but ONLY when footprint-free (0 open AND 0 closed), so a hidden sub contributes 0 to the account
        # aggregate above and the visible rows always sum to the shown total (no orphan can hide money at risk).
        agg["subdivisions"] = [b for b in agg["subdivisions"]
                               if _tile_visible(b["category"], int(b.get("n_open") or 0) > 0 or int(b.get("n_closed") or 0) > 0)]
        for b in agg["subdivisions"]:
            b["open_value"] = live_view.value_positions(
                subdivision.live_positions(conn, b["account_id"], b["category"]), marks)
            m = meta_by_cat.get(b["category"], {})
            b["sub_label"] = m.get("sub_label")
            b["market_types"] = m.get("market_types")
            b["n_whales"] = m.get("n_whales")
            b["n_live_trades"] = m.get("n_live_trades")
    meta = accts[account_id]
    agg["account_label"] = meta.get("account_label")
    agg["venue"] = meta.get("venue")
    _annotate_pnl(agg, floor)
    for b in agg["subdivisions"]:
        _annotate_pnl(b, floor)
    # M3 balance: the LATEST per-shard snapshot (+ its age band) + the two distinct honest-empty states (table absent
    # vs present-but-empty) + the shard-0-direction line (return-to-3 vs sweeping). All from the snapshot -- never the venue.
    with connect() as conn:
        snap = shard_snapshot.read_latest(conn, account_id)
        snap_table = shard_snapshot.table_present(conn)
        snap_dir = shard_snapshot.shard_direction(conn, account_id)
        # L3 DRIVER LIVENESS per sub-division (read-only), keyed by category for the per-sub grid + a per-account alarm.
        liveness_present = heartbeat.table_present(conn)
        live_rows = {r.category: r for r in heartbeat.read_liveness(conn, now_ts=int(time.time()))
                     if r.account_id == account_id}
    for b in agg["subdivisions"]:
        b["liveness"] = live_rows.get(b.get("category"))
    now_ts = int(time.time())
    return {"account": agg, "arm_badge": _arm_badge(now_ts=now_ts), "thin_floor": floor,
            "shard_snap": snap, "shard_snap_table": snap_table, "shard_dir": snap_dir,
            "value_as_of": value_as_of, "now_ts": now_ts,
            "liveness_present": liveness_present, "liveness_rows": list(live_rows.values()),
            "liveness_alarm": liveness_present and heartbeat.any_alarm(list(live_rows.values()))}


@app.get("/", response_class=HTMLResponse)
async def accounts_overview_page(request: Request):
    """The ACCOUNTS OVERVIEW -- the top of the hierarchy (R1: replaces the old 2-card dashboard). Per-account PM
    P&L, whether PM trades each account, and the global arm state (read-only). Read-only; no arm/attach control.
    SCOPED (M4): the list shows only the accounts the requester may see (admin -> all)."""
    identity, is_admin_flag = authz.current_identity(request), authz.is_admin(request)
    data = await asyncio.to_thread(_load_accounts_overview, identity, is_admin_flag)
    return templates.TemplateResponse(request, "pm_accounts.html", {"request": request, **data})


@app.get("/account/{account_id}", response_class=HTMLResponse)
async def account_page(request: Request, account_id: str):
    """One account's PM sub-divisions with per-sub-division P&L (realized / win-loss / sample / open-at-cost). A
    display-only account (0 PM sub-divisions) states its limitation in the copy. Unknown/inactive -> 404; an account
    that exists but is not the requester's (and they are not admin) -> 403 (M4 scoping). Read-only."""
    account_id = (account_id or "").strip()
    identity, is_admin_flag = authz.current_identity(request), authz.is_admin(request)
    data = await asyncio.to_thread(_load_account, account_id, identity, is_admin_flag)
    if data is None:
        return templates.TemplateResponse(request, "pm_account_404.html",
                                          {"request": request, "account_id": account_id}, status_code=404)
    if data is _FORBIDDEN:
        return PlainTextResponse("forbidden: not your account", status_code=403)
    return templates.TemplateResponse(request, "pm_account.html", {"request": request, **data})


@app.get("/farm", response_class=HTMLResponse)
async def farm_league_page(request: Request):
    """The Farm-League category tiles (the active Kalshi-copyable categories, data-driven). Each tile links to its
    per-category page. (Phase 3 repointed this from /farm-league onto /farm; the flat farm page it replaces was
    retired.)"""
    is_admin_flag = authz.is_admin(request)   # M4: the Search (discovery) panel is admin-only, like promote/refresh
    data = await asyncio.to_thread(_load_farm_league)
    return templates.TemplateResponse(
        request, "pm_farm_league.html", {"request": request, "is_admin": is_admin_flag, **data})


@app.get("/farm/{category}", response_class=HTMLResponse)
async def farm_league_category(request: Request, category: str):
    """The per-category page: Watchlist (paper) on top, Prospects (completed) below. A category NOT in the active
    tile set (removed / unknown / nonexistent) is NOT reachable -> 404, never a fabricated page. (Phase 3 repointed
    this from /farm-league/{category} onto /farm/{category}.)"""
    category = (category or "").strip().lower()
    data = await asyncio.to_thread(_load_farm_category, category, int(time.time()))
    if data is None:
        return templates.TemplateResponse(
            request, "pm_category_404.html", {"request": request, "category": category}, status_code=404)
    return templates.TemplateResponse(request, "pm_farm_category.html", {"request": request, **data})


# ── THE THREE FARM ACTIONS (Stage 3 R6) -- the FIRST mutating POST routes besides Analyze ────────────────────
# WHAT PROTECTS THESE: Authelia at the reverse proxy (identity) + the M4 ADMIN GATE below (authorization). The app
# has NO pm_user/pm_role/pm_grant table (Authelia owns identity); the gate is a single fail-closed check --
# `_forbid_if_not_admin` -- enforced SERVER-SIDE at the top of each mutating route. This is the boundary, NOT the
# hidden button: a non-admin who POSTs directly (curl, replay, a stale tab) is REFUSED here regardless of what the
# UI rendered. Analyze is deliberately NOT gated (Karen may run it -- the promotion judge, spend-capped). WHAT IS
# STILL NOT COVERED: there is no CSRF token -- but every action is IDEMPOTENT (a double-submit / concurrent click is
# a no-op, never a duplicate); mutation is POST-ONLY (no GET mutates -- a crawler/prefetch/refresh cannot demote a
# whale); and NONE of these reaches the execution chokepoint (promote-to-live writes an ATTACHMENT row, never an
# order; pm_web imports no broker). Pattern = Post/Redirect/Get: the write runs OFF the loop, then a 303 redirect to
# the GET page (a browser refresh re-GETs, never re-POSTs -> double-submit-safe at the transport layer too).

def _forbid_if_not_admin(request: Request):
    """M4 SERVER-SIDE admin gate for the mutating farm/live POST routes. Returns a 403 PlainTextResponse if the
    requester is NOT an admin (fail-closed: no identity, or PM_ADMIN_IDENTITIES unset -> not admin), else None so the
    caller proceeds. Hiding the button is a UI HINT, not the gate -- THIS is the boundary; a direct POST from a
    non-admin (e.g. Karen) is refused here, server-side, whatever the page rendered. Analyze is NOT gated with this."""
    if not authz.is_admin(request):
        return PlainTextResponse("forbidden: admin only", status_code=403)
    return None


def _promote_watchlist(wallet: str, category: str, now_ts: int) -> dict:
    with connect() as conn:
        return farm_actions.promote_to_watchlist(conn, wallet, category, now_ts)


def _demote_prospect(wallet: str, category: str, now_ts: int) -> dict:
    with connect() as conn:
        return farm_actions.demote_to_prospect(conn, wallet, category, now_ts)


def _promote_live(account_id: str, category: str, wallet: str, now_ts: int, actor: str | None = None) -> dict:
    with connect() as conn:
        return farm_actions.promote_to_live(conn, account_id, category, wallet, now_ts, actor=actor)


@app.post("/farm/{category}/promote/{wallet}")
async def promote_watchlist_action(request: Request, category: str, wallet: str):
    """PROMOTE-TO-WATCHLIST (Prospect -> Watchlist): candidate -> pinned. Idempotent; writes ONLY pm_watchlist.
    303 back to the category page (PRG). ADMIN-ONLY (M4, server-side)."""
    forbidden = _forbid_if_not_admin(request)
    if forbidden is not None:
        return forbidden
    category = (category or "").strip().lower()
    await asyncio.to_thread(_promote_watchlist, (wallet or "").lower(), category, int(time.time()))
    return RedirectResponse("/farm/%s" % category, status_code=303)


@app.post("/farm/{category}/demote/{wallet}")
async def demote_action(request: Request, category: str, wallet: str):
    """DEMOTE (Watchlist -> Prospect): pinned -> candidate. Idempotent; writes ONLY pm_watchlist -- pm_paper_trade
    rows are PRESERVED (F-5). 303 back to the category page. ADMIN-ONLY (M4, server-side)."""
    forbidden = _forbid_if_not_admin(request)
    if forbidden is not None:
        return forbidden
    category = (category or "").strip().lower()
    result = await asyncio.to_thread(_demote_prospect, (wallet or "").lower(), category, int(time.time()))
    # R6: demote REFUSES while a live attachment exists (a funnel action must never tear down a real-money
    # attachment). Say WHY instead of failing silently: 409 naming the live attachments; the operator detaches from
    # live first (CLI), then demotes.
    if isinstance(result, dict) and result.get("reason") == "attached_live_detach_first":
        atts = result.get("attachments") or []
        accts = ", ".join("%s/%s" % (a.get("account_id"), a.get("category")) for a in atts)
        # R6 (2026-09-12): point at the sub-division's own roster page (the Detach control lives there now), not "the CLI".
        pages = ", ".join("/live/%s/%s" % (a.get("account_id"), a.get("category")) for a in atts) or "the sub-division's Live page"
        return PlainTextResponse(
            "cannot demote %s in %s: still LIVE-attached (%s). Detach it from each sub-division's roster first "
            "(open %s -> \"Copies these whales\" -> Detach), then demote."
            % ((wallet or "").lower(), category, accts or "live", pages), status_code=409)
    return RedirectResponse("/farm/%s" % category, status_code=303)


# ── DETACH a whale from a LIVE sub-division (2026-09-12) -- owner-OR-admin, the roster's back-out for a wrong promote.
# Mirrors the promote/demote pattern: POST-only, idempotent (farm_actions.detach_from_live is a no-op if not attached),
# Post/Redirect/Get. The ONE difference from promote/attach (admin-only): Detach is OWNER-OR-ADMIN, so Karen may
# detach from her OWN sub-divisions and Jack from all -- the first use of owner_identity to gate a WRITE. A real
# CONFIRM step precedes it (a server-rendered page, JS-off safe): GET shows the consequences, POST performs it. The
# engine's per-cycle roster query is attachment-gated (live_driver.py:1096, SELECT ... WHERE active=1), so copying
# stops within one ~7s cycle with NO restart; open positions are NOT closed -- they ride to settlement.
def _owner_or_admin_gate(request: Request, account_id: str):
    """403/404 owner-or-admin gate for a per-account mutation. Returns a response to RETURN (deny) or None (proceed).
    Reads the account's owner_identity server-side -- hiding the button is a UI hint, THIS is the boundary."""
    with connect() as conn:
        accts = subdivision.active_accounts(conn)
    acct = next((a for a in accts if a["account_id"] == account_id), None)
    if acct is None:
        return PlainTextResponse("no such account", status_code=404)
    if not authz.can_act_on_account(authz.current_identity(request), authz.is_admin(request), acct):
        return PlainTextResponse("forbidden: not your account", status_code=403)   # Karen on Jack's sub -> here
    return None


def _detach_confirm_ctx(account_id: str, category: str, wallet: str, now_ts: int):
    """The CONFIRM page context: the whale's CURRENT roster record (name + open count/at-cost) so the consequences are
    stated on the real numbers. Returns None if the whale is not CURRENTLY attached (active=1) -> nothing to detach."""
    marks, _ = _cache_marks()
    today_start_ts = live_view.et_window_cutoffs(now_ts)["today"]
    with connect() as conn:
        sub = subdivision.get_subdivision(conn, account_id, category)
        if sub is None:
            return None
        recs = subdivision.whale_live_records(conn, account_id, category, marks=marks, now_ts=now_ts,
                                              today_start_ts=today_start_ts, thin_floor=search.DEFAULT_MIN_RESOLVED_FLOOR)
    rec = next((r for r in recs["on_roster"] if r["wallet"] == wallet), None)
    if rec is None:
        return None                              # not currently attached -> nothing to confirm
    return {"account_id": account_id, "category": category, "wallet": wallet, "rec": rec, "now_ts": now_ts}


def _detach_live(account_id: str, category: str, wallet: str, now_ts: int, actor: str | None = None) -> dict:
    with connect() as conn:
        return farm_actions.detach_from_live(conn, account_id, category, wallet, now_ts, actor=actor)


@app.get("/live/{account_id}/{category}/detach/{wallet}", response_class=HTMLResponse)
async def detach_confirm_page(request: Request, account_id: str, category: str, wallet: str):
    """The Detach CONFIRM page (server-rendered -> JS-off safe). GET does NOT mutate: it states plainly that new copies
    stop within one engine cycle, open positions are NOT closed (they ride to settlement), and the whale stays on the
    Farm paper list. OWNER-OR-ADMIN. The Detach button on it POSTs to the same path."""
    account_id = (account_id or "").strip(); category = (category or "").strip().lower(); wallet = (wallet or "").lower()
    denied = _owner_or_admin_gate(request, account_id)
    if denied is not None:
        return denied
    data = await asyncio.to_thread(_detach_confirm_ctx, account_id, category, wallet, int(time.time()))
    if data is None:                              # sub missing, or the whale is not currently attached
        return RedirectResponse("/live/%s/%s" % (account_id, category), status_code=303)
    return templates.TemplateResponse(request, "partials/pm_detach_confirm.html", {"request": request, **data})


@app.post("/live/{account_id}/{category}/detach/{wallet}")
async def detach_action(request: Request, account_id: str, category: str, wallet: str):
    """DETACH (owner-or-admin, server-side gate). Idempotent (a no-op if not attached). Sets active=0 on the
    attachment -> the engine's next cycle drops the whale (no restart). 303 back to the sub-division page (PRG)."""
    account_id = (account_id or "").strip(); category = (category or "").strip().lower(); wallet = (wallet or "").lower()
    denied = _owner_or_admin_gate(request, account_id)
    if denied is not None:
        return denied
    await asyncio.to_thread(_detach_live, account_id, category, wallet, int(time.time()), authz.current_identity(request))
    return RedirectResponse("/live/%s/%s" % (account_id, category), status_code=303)


# ── PER-SUB-DIVISION CONTRACT SIZING FROM THE UI (2026-09-12) -- owner-or-admin LOWERS, admin RAISES (R1). Mirrors
# Detach: a server-rendered CONFIRM (GET, JS-off safe) then a POST that writes pm_subdivision.contracts (READ PER
# CYCLE by the engine at execution.py:544 via live_driver.py:1080 -> effect on the next ~7s cycle, NO restart) plus
# the pm_web-owned audit row (sizing.set_contracts, migration 022). BOUNDS (R2) are sizing.CONTRACTS_MIN/MAX, a UI
# ruling -- NOT the engine's USD caps. The gates here (bounds/mode/authz) ARE the boundary; the header link is a hint.
def _sizing_confirm_ctx(account_id: str, category: str, new_n: int, now_ts: int):
    with connect() as conn:
        cur = sizing.read_sizing(conn, account_id, category, now_ts=now_ts)
        if cur is None:
            return None
        avg_fill, est_cost = sizing.estimate_cost(conn, account_id, category, new_n)
    return {"account_id": account_id, "category": category, "cur": cur, "new_n": new_n,
            "avg_fill": avg_fill, "est_cost": est_cost, "now_ts": now_ts}


def _load_sizing(account_id: str, category: str, now_ts: int):
    with connect() as conn:
        return sizing.read_sizing(conn, account_id, category, now_ts=now_ts)


def _apply_sizing(account_id: str, category: str, new_n: int, changed_by, now_ts: int) -> dict:
    with connect() as conn:
        return sizing.set_contracts(conn, account_id, category, new_n, changed_by, now_ts)


def _sizing_gate(request: Request, account_id: str, category: str, new_n: int, cur: dict | None):
    """The full R1/R2/mode boundary shared by GET-confirm and POST. Returns a Response to RETURN (deny) or None
    (proceed). Order: owner-or-admin (403/404) -> sub exists + is on 'contracts' mode (409) -> RAISE requires admin
    (403). `cur` is the already-read current sizing (None => sub missing)."""
    denied = _owner_or_admin_gate(request, account_id)          # owner-or-admin; no-identity / not-owner -> 403; no account -> 404
    if denied is not None:
        return denied
    if cur is None:
        return RedirectResponse("/live/%s/%s" % (account_id, category), status_code=303)   # sub vanished
    if not cur["editable"]:                                      # sizing_mode != 'contracts' -> the number is UNREAD
        return PlainTextResponse("conflict: %s/%s is on '%s' sizing; the contract count is not read (switch to "
                                 "contracts mode first)" % (account_id, category, cur["sizing_mode"]), status_code=409)
    if new_n > int(cur["contracts"]) and not authz.is_admin(request):   # R1: only admin may RAISE
        return PlainTextResponse("forbidden: raising the contract count requires admin (owner may only lower it)",
                                 status_code=403)
    return None


@app.get("/live/{account_id}/{category}/sizing", response_class=HTMLResponse)
async def sizing_confirm_page(request: Request, account_id: str, category: str, n: str | None = None):
    """The sizing CONFIRM page (server-rendered -> JS-off safe). `?n=<new>` is the target from the header form. GET
    does NOT mutate. Owner-or-admin; bounds (400) named; non-contracts mode (409); RAISE requires admin (403)."""
    account_id = (account_id or "").strip(); category = (category or "").strip().lower()
    if n is None:
        return RedirectResponse("/live/%s/%s" % (account_id, category), status_code=303)
    try:
        new_n = sizing.validate_contracts(n)                    # R2 bounds -> 400 naming the bound
    except sizing.SizingError as e:
        return PlainTextResponse("bad request: %s" % e, status_code=400)
    data = await asyncio.to_thread(_sizing_confirm_ctx, account_id, category, new_n, int(time.time()))
    denied = _sizing_gate(request, account_id, category, new_n, (data or {}).get("cur"))
    if denied is not None:
        return denied
    return templates.TemplateResponse(request, "partials/pm_sizing_confirm.html", {"request": request, **data})


@app.post("/live/{account_id}/{category}/sizing/{n}")
async def sizing_action(request: Request, account_id: str, category: str, n: str):
    """APPLY the sizing change (owner-or-admin lower / admin raise, server-side). The target count is in the PATH
    (no form body -> no python-multipart dependency). Bounds (400); non-contracts (409); writes
    pm_subdivision.contracts + the audit row (sizing.set_contracts). 303 back to the sub-division page (PRG)."""
    account_id = (account_id or "").strip(); category = (category or "").strip().lower()
    try:
        new_n = sizing.validate_contracts(n)                    # R2 bounds -> 400
    except sizing.SizingError as e:
        return PlainTextResponse("bad request: %s" % e, status_code=400)
    now_ts = int(time.time())
    cur = await asyncio.to_thread(_load_sizing, account_id, category, now_ts)
    denied = _sizing_gate(request, account_id, category, new_n, cur)
    if denied is not None:
        return denied
    try:
        await asyncio.to_thread(_apply_sizing, account_id, category, new_n, authz.current_identity(request), now_ts)
    except sizing.SizingError as e:                             # a race (mode flip / bounds) -> honest error, no silent write
        return PlainTextResponse("bad request: %s" % e, status_code=400)
    return RedirectResponse("/live/%s/%s" % (account_id, category), status_code=303)


async def _refresh_whale(wallet: str, now_ts: int) -> str:
    """The REFRESH BUTTON's work (Jack's on-demand ruling): a FULL ad-hoc re-pull of ONE whale's completed history
    (search_run.refresh_one -> ingest.refresh_wallet), then a rollup so the re-pulled data reflects in the
    completed-basis stats the Prospects table shows. NETWORK + SLOW (~30 calls). Returns the OUTCOME
    ('complete' | 'partial' | 'failed') so the caller can tell the operator WHY a whale changed/vanished.
    ★ SAFE ON FAILURE: a RAISED pull leaves the whale's prior complete data + backfill_complete=1 UNTOUCHED (it
    stays shown, unchanged); a CAP-TRUNCATED pull marks it partial (backfill_complete=0) -> the completeness gate
    drops it from the ranker (visibly), never half-populated-and-ranked. The pull runs ON the loop (its network
    yields); the blocking rollup runs OFF the loop (asyncio.to_thread) -- pm_web's loop is never stalled by the
    aggregate (this file's off-loop discipline). Lazy imports keep the client (data layer) + search_run off the
    module import surface (the standalone-imports guard)."""
    from ..search_run import refresh_one
    from ...data.polymarket_data_api_client import PolymarketDataAPIClient
    outcome = "failed"
    with connect() as conn:
        try:
            async with PolymarketDataAPIClient() as client:
                res = await refresh_one(conn, wallet, client=client, now_ts=now_ts)
            outcome = (res or {}).get("verdict") or "complete"   # 'complete' | 'partial'
        except Exception:
            outcome = "failed"   # a raised refresh -> the whale is UNCHANGED (safe); still rollup + re-render honest state
        await asyncio.to_thread(stats.rollup, conn, now_ts=now_ts)   # reflect the re-pull; OFF the loop (blocking aggregate)
    return outcome


# The operator-facing notice for a refresh that did NOT cleanly complete -- so a whale that DROPS off the ranked
# list (partial) or stays unchanged (failed) is EXPLAINED, never a silent vanish (staleness/incompleteness visible).
_REFRESH_NOTICE = {
    "partial": "Refresh came back INCOMPLETE (the pull truncated) -- this whale is now marked partial and DROPPED "
               "from the ranked list until a clean refresh. It is never ranked on partial data.",
    "failed":  "Refresh FAILED (network) -- this whale is UNCHANGED; its prior complete data is intact.",
}


@app.post("/farm/{category}/refresh/{wallet}")
async def refresh_action(request: Request, category: str, wallet: str):
    """REFRESH one prospect whale (POST-only -- no GET mutates, R6 discipline). Re-pulls its full completed history
    on demand + rolls up, then re-renders the Prospects section. SLOW (~30 calls, up to ~1 min): htmx shows the
    button disabled while it runs (hx-disabled-elt) so the operator sees it working and cannot double-fire; JS-off
    blocks on the browser's native load, then a 303 back to the page. A failed/partial refresh is SAFE (see
    _refresh_whale) -- the whale is never left half-populated or ranked on incomplete data, and a NOTICE explains a
    partial/failed outcome so a dropped whale is never a silent vanish. ADMIN-ONLY (M4, Jack ruled 2026-09-01):
    Karen is the promotion JUDGE (Analyze is judgment, ungated), but refresh is a ~30-call API pull against a SHARED
    budget -- a data-operator action, so it joins promote/attach/demote behind the server-side gate."""
    forbidden = _forbid_if_not_admin(request)
    if forbidden is not None:
        return forbidden
    category = (category or "").strip().lower()
    outcome = await _refresh_whale((wallet or "").lower(), int(time.time()))
    if request.headers.get("HX-Request"):
        data = await asyncio.to_thread(_load_farm_category, category, int(time.time()))
        if data is None:
            return templates.TemplateResponse(
                request, "pm_category_404.html", {"request": request, "category": category}, status_code=404)
        return templates.TemplateResponse(request, "partials/pm_prospects_rows.html",
                                          {"request": request, "refresh_notice": _REFRESH_NOTICE.get(outcome), **data})
    return RedirectResponse("/farm/%s" % category, status_code=303)


# ── SEARCH (whale discovery -> Prospects) -- the Farm-League-page button. Structurally ALL-CATEGORIES: the
# Polymarket leaderboard knows only coarse buckets (no "mlb whales" query), backfill is all-categories, and the
# 15-category filter applies only at the candidate WRITE -- so this searches EVERYTHING, on the main page, never
# per-category (per-category would be a 92-min sweep masquerading as a one-category refresh). It is a ~90-min job
# hitting Polymarket from the SAME prod IP the armed engine polls every ~7s, so: admin-only (the Refresh precedent
# at 50x scale), SINGLE-FLIGHTED server-side (a disabled button is a UI hint; two tabs / a refresh / a direct POST
# all bypass it, and two concurrent sweeps double the API load on the live-copy path), and run as a DETACHED
# subprocess (survives a pm_web restart; crash-isolated from the web loop) that ADOPTS the pre-acquired lock.

_SEARCH_BUCKET = "Sports"   # the discovery bucket the button uses (where the sports whales live)


def _spawn_search(run_id: int, *, category: str, db_path: str) -> None:
    """Launch `pm_cli search --run-id <id>` as a DETACHED subprocess that ADOPTS the pre-acquired single-flight
    lock. Mirrors the proven cron/service invocation (cwd=<root>, PYTHONPATH=<root>, venv python `sys.executable`,
    the script by path). `start_new_session=True` detaches it so a pm_web restart/deploy does NOT kill a 90-min
    sweep; stdout/stderr -> a per-run log so a failure is diagnosable. Raises if the process cannot be launched
    (the caller then releases the lock so it is never stranded 'running')."""
    root = Path(__file__).resolve().parents[3]                      # <root>/trading_corp/prediction_markets/web/app.py
    script = root / "trading_corp" / "scripts" / "pm_cli.py"
    env = dict(os.environ)
    env["PYTHONPATH"] = str(root) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    logdir = root / "data"                                          # azureuser-writable + gitignored (NOT the repo root)
    try:
        logdir.mkdir(exist_ok=True)
    except Exception:   # noqa: BLE001 -- data/ already exists in every real deployment; a log dir is best-effort
        logdir = root
    logf = open(logdir / ("pm_search_ui_run%d.log" % run_id), "ab")  # noqa: SIM115 -- child dups the fd; closed below
    try:
        subprocess.Popen(
            [sys.executable, str(script), "--db", db_path, "search", "--run-id", str(run_id),
             "--category", category],
            cwd=str(root), env=env, stdout=logf, stderr=logf, stdin=subprocess.DEVNULL,
            start_new_session=True, close_fds=True)
    finally:
        logf.close()   # the parent's copy; the detached child holds its own dup


def _acquire_and_launch(now_ts: int) -> dict:
    """Atomically take the single-flight lock and, if acquired, launch the detached sweep. Returns the acquire
    result dict ({'acquired': bool, 'run_id', ...}). A REFUSAL (a live run already in flight) launches nothing.
    If the launch itself fails, the lock is RELEASED (row -> error) so a failed spawn never strands 'running'."""
    from ..search_run import acquire_search_lock, close_search_run, DEFAULT_LEADERBOARD_LIMIT
    db_path = os.path.abspath(pm_db_path())    # the EXACT file connect() opens -> the detached child hits the same DB
    with connect() as conn:
        lk = acquire_search_lock(
            conn, now_ts=now_ts, leaderboard_category=_SEARCH_BUCKET,
            leaderboard_limit=DEFAULT_LEADERBOARD_LIMIT, min_resolved=search.DEFAULT_MIN_RESOLVED_FLOOR,
            recency_window_days=search.DEFAULT_RECENCY_DAYS, thin_sample_target=search.DEFAULT_THIN_TARGET,
            launcher="ui")
    if not lk.get("acquired"):
        return lk
    try:
        _spawn_search(lk["run_id"], category=_SEARCH_BUCKET, db_path=db_path)
    except Exception as e:   # noqa: BLE001 -- a failed spawn must not strand the lock
        log.exception("pm_web: search sweep failed to launch (run_id=%s)", lk.get("run_id"))
        with connect() as conn:
            close_search_run(conn, lk["run_id"], finished_ts=now_ts, n_discovered=0, n_backfilled=0,
                             status="error", summary="failed to launch sweep: %s" % (repr(e)[:200]))
        return {"acquired": False, "run_id": lk["run_id"], "reason": "launch_failed"}
    return lk


def _read_search_status(now_ts: int) -> dict:
    from ..search_run import latest_search_status
    with connect() as conn:
        return latest_search_status(conn, now_ts=now_ts)


async def _render_search_status(request: Request):
    """Render the discovery-panel status fragment (the htmx poll target): reads the latest run's live state
    (idle/running/done/error/stale) + whether the requester is admin (the button is admin-only)."""
    is_admin_flag = authz.is_admin(request)
    status = await asyncio.to_thread(_read_search_status, int(time.time()))
    return templates.TemplateResponse(
        request, "partials/pm_search_status.html",
        {"request": request, "search_status": status, "is_admin": is_admin_flag})


@app.post("/farm/search")
async def farm_search_action(request: Request):
    """START a Search sweep (admin-only, single-flighted). ADMIN-ONLY server-side (M4) -- Search spends ~1900
    Polymarket calls over ~90 min against the shared prod IP, the Refresh concern at ~50x scale, so a non-admin
    POST (curl / stale tab / second browser) is refused here regardless of what the page rendered. The
    single-flight lock (acquire_search_lock) refuses a SECOND concurrent run BELOW the UI -- the boundary, not
    the disabled button. On acquire, a detached subprocess runs the ~90-min sweep; the response is the 'underway'
    status fragment so the operator sees it started + cannot double-fire. POST-only (no GET mutates)."""
    forbidden = _forbid_if_not_admin(request)
    if forbidden is not None:
        return forbidden
    await asyncio.to_thread(_acquire_and_launch, int(time.time()))   # acquire + (if taken) launch; refusal is a no-op
    if request.headers.get("HX-Request"):
        return await _render_search_status(request)                 # swap in the running/underway (or already-running) panel
    return RedirectResponse("/farm", status_code=303)               # JS-off: PRG back to /farm (panel re-reads state)


@app.get("/farm/search/status", response_class=HTMLResponse)
async def farm_search_status(request: Request):
    """The discovery panel's status fragment, polled by htmx WHILE a sweep runs so the operator learns it
    FINISHED (done: N candidates) or FAILED (error/stale), not only that it started. Read-only."""
    return await _render_search_status(request)


@app.post("/live/{account_id}/{category}/attach/{wallet}")
async def promote_to_live_action(request: Request, account_id: str, category: str, wallet: str):
    """PROMOTE-TO-LIVE: attach a pinned pair to the (account_id, category) sub-division (joined ON CATEGORY).
    Creates the ATTACHMENT and nothing else -- NEVER an order. Idempotent (no duplicate attachment). 303 to the
    sub-division page so the operator SEES the whale now in its copy list; a bad target is a no-op (honest).
    ADMIN-ONLY (M4, server-side) -- attach is the highest-stakes farm action (it is what makes an account copy a
    whale), so the gate matters most here; a non-admin POST is refused before any write."""
    forbidden = _forbid_if_not_admin(request)
    if forbidden is not None:
        return forbidden
    # account_id is an EXACT-MATCH slug PK (strip-only, NOT lowercased) -- consistent with R3's /live/{account_id}
    # route; wallet/category are normalized because they are case-insensitive by nature, a slug is not. A mixed-case
    # account_id simply misses -> honest no_such_subdivision no-op (never a wrong write).
    account_id = (account_id or "").strip()
    category = (category or "").strip().lower()
    result = await asyncio.to_thread(_promote_live, account_id, category, (wallet or "").lower(), int(time.time()), authz.current_identity(request))
    # GUARD (2026-09-11): promote_to_live is idempotent (PK (account,category,wallet) + UPSERT -> never a second
    # row), but a repeat attach used to redirect silently as if it did something. Refuse it LOUD: 409 with a plain
    # message. The UI already hides Promote for an attached account (the "Live Whale" badge), so this backstops a
    # stale page / direct POST -- and it still never inserts a duplicate.
    if isinstance(result, dict) and result.get("reason") == "already_attached":
        return PlainTextResponse(
            "already attached: %s is already a LIVE whale on %s / %s -- no second attachment (idempotent)."
            % ((wallet or "").lower(), account_id, category), status_code=409)
    return RedirectResponse("/live/%s/%s" % (account_id, category), status_code=303)


# ── LIVE sub-divisions (Stage 3 R3) -- the top-of-hierarchy Account-Category tiles. READ-ONLY: renders tiles +
# sub-division config + an honest-empty live list. Places NOTHING, arms NOTHING, reaches NO order path (execution
# is R4+; pm_web imports no broker). DEFENSIVE: subdivision.* tolerate pm_account/pm_subdivision being absent
# (pre-migration-010) -> honest-empty, so /live deploys on a pm_web restart independent of the migration-010 deploy.

_STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
_LOGO_DIR = os.path.join(_STATIC_DIR, "logos")


def _sha8(path: str) -> str:
    """CR-stripped sha8 of a static asset -- the cache-bust ?v= (same scheme as pm_shell.html). '' if absent."""
    try:
        with open(path, "rb") as f:
            return hashlib.sha256(f.read().replace(b"\r", b"")).hexdigest()[:8]
    except OSError:
        return ""


def _logo_versions() -> dict:
    """{CODE(upper): sha8} for every static/logos/<CODE>.png -- the tile knows both WHICH codes have a logo (draw
    the plate image vs a monogram) and its cache-bust version. Computed once at import; empty if the dir is absent
    (every tile then draws a monogram -- honest, never a broken image)."""
    out: dict = {}
    try:
        for f in os.listdir(_LOGO_DIR):
            if f.lower().endswith(".png"):
                out[f.rsplit(".", 1)[0].upper()] = _sha8(os.path.join(_LOGO_DIR, f))
    except OSError:
        pass
    return out


_LOGO_VERSIONS = _logo_versions()
_SUBS_JS_V = _sha8(os.path.join(_STATIC_DIR, "pm_live_subs.js"))


def _load_live_list(active_account: str | None = None, identity: str | None = None,
                    is_admin_flag: bool = False) -> dict:
    """The REDESIGNED Live Sub-divisions tile page (2026-09-10): per-account tabs SCOPED to the viewer (R6 --
    admin sees all, a non-admin only their own account(s)), activity state (LIVE/UPCOMING/SETTLED/INACTIVE/
    UNATTACHED), ET-calendar money windows (today/week/month/all-time), a LIVE event block, and the armed-but-
    STALE alarm strip. All read-only: journal + persisted arm state + heartbeat + the poller's mark cache + the
    cached sports feed; NO venue, NO order path. OFF the loop."""
    from .. import heartbeat        # a LOCAL import keeps this hunk purely additive on the box-current app.py (graft-clean)
    from .. import leg_audit        # read-side leg-audit surfacing (Rung-3 observability, 2026-09-10); stdlib-only, pm_web-safe
    now_ts = int(time.time())
    marks, marks_as_of = _cache_marks()
    mark_age_sec = (now_ts - int(marks_as_of)) if marks_as_of else None
    snap = ui_cache.cache().snapshot()
    feed_games: dict = {}
    for sl in snap.slates.values():
        feed_games.update(sl.games)                       # merged so a night game across two ET dates still joins
    floor = search.DEFAULT_MIN_RESOLVED_FLOOR
    name_exceptions: list = []
    with connect() as conn:
        accts = {a["account_id"]: a for a in subdivision.active_accounts(conn)}       # carries owner_identity (M4)
        visible = authz.visible_account_ids(identity, is_admin_flag, accts.values())
        accounts_meta = [{"account_id": aid, "account_label": a.get("account_label") or aid, "venue": a.get("venue")}
                         for aid, a in accts.items() if aid in visible]
        # SCOPE the tile set first (R6), THEN hide INERT MATCHERLESS sub-divisions (item 3, 2026-09-15): a category
        # with no matcher (bare 'soccer'/'tennis') can NEVER trade -> a mis-attach orphan tile, hidden -- but ONLY
        # when it is footprint-free (0 whales AND 0 real orders), so money at risk is never hidden. A real tradable
        # category with 0 whales still shows (Jack notices an un-attached sub).
        subs = [s for s in subdivision.tiles_all(conn)
                if s["account_id"] in visible
                and _tile_visible(s["category"], int(s.get("n_whales") or 0) > 0 or int(s.get("n_live_trades") or 0) > 0)]
        arm_all = arm.read_display_all([(s["account_id"], s["category"]) for s in subs])
        liveness_present = heartbeat.table_present(conn)
        liveness_by_sub = {(r.account_id, r.category): r
                           for r in heartbeat.read_liveness(conn, now_ts=now_ts)} if liveness_present else {}
        pnl_all = subdivision.subdivision_pnl_all(conn)
        realized_windows = subdivision.realized_windows_all(conn, live_view.et_window_cutoffs(now_ts))
        last_events = subdivision.last_events_all(conn)
        max_order_id = subdivision.events_since(conn, 0)["max_id"]
        # page-top leg-audit safety strip: the engine's independent post-fill leg check, read BACK. Scoped to the
        # viewer's visible accounts (a wrong-side fill is money-critical -> surfaced regardless of the active tab).
        leg_audit_reviews = leg_audit.read_leg_audit_reviews(conn, account_ids=list(visible))
        positions_by_sub = {}
        for s in subs:                                     # open positions ONLY for attached subs
            if int(s.get("n_whales") or 0) > 0:
                key = (s["account_id"], s["category"])
                positions_by_sub[key] = subdivision.live_positions(conn, s["account_id"], s["category"])
    g = (arm_all or {}).get("global", {"state": "absent", "ts": None})
    global_arm = {"state": g.get("state"), "ts_age": live_view._ts_age(g.get("ts"), now_ts)}
    viewer_role = "admin" if is_admin_flag else "account"
    viewer_account = list(visible)[0] if (not is_admin_flag and len(visible) == 1) else None
    ctx = live_view.build_subdivisions_context(
        subs=subs, accounts_meta=accounts_meta, arm_all=arm_all, liveness_by_sub=liveness_by_sub,
        liveness_present=liveness_present, pnl_all=pnl_all, realized_windows=realized_windows,
        positions_by_sub=positions_by_sub, last_events=last_events, marks=marks, feed_games=feed_games,
        now_ts=now_ts, thin_floor=floor, mark_age_sec=mark_age_sec, active_account=active_account,
        viewer_role=viewer_role, viewer_account=viewer_account, logo_codes=set(_LOGO_VERSIONS),
        poll_interval=live_view.POLL_INTERVAL_SECONDS, global_arm=global_arm, max_order_id=max_order_id,
        leg_audit_reviews=leg_audit_reviews, name_exceptions=name_exceptions, starts=snap.starts)
    if name_exceptions:
        log.warning("pm_web /live: %d held position(s) named by CATEGORY fallback (no feed/mark/describe) -- %s",
                    len(name_exceptions), name_exceptions[:8])
    ctx["warming"] = not snap.ready
    ctx["logo_v"] = _LOGO_VERSIONS
    ctx["subs_js_v"] = _SUBS_JS_V
    return ctx


def _load_live_subdivision(account_id: str, category: str, now_ts: int,
                           identity: str | None = None, is_admin_flag: bool = False):
    """Per-sub-division read for the GAME-CARD view (UI rewrite): its config + copied whales + the journal, joined
    to the cached sports feed + Kalshi marks into game cards. None -> 404; `_FORBIDDEN` -> 403 (the account exists
    but is not this identity's -- R6 fail-closed scoping; scoping the tile page while leaving this route open would
    be security theatre, inventory add#5). Read-only -- no form, no order path, no arm control. The DB reads run
    here (off the loop); the feed/marks come from ui_cache, so the render never blocks on the network. The cards
    degrade honestly: feed-unavailable renders nothing feed-derived, a position with no mark renders 'no mark',
    and cost basis is always distinct from current value."""
    marks, _marks_as_of = _cache_marks()                                            # cached Kalshi marks (per-whale current value)
    today_start_ts = live_view.et_window_cutoffs(now_ts)["today"]                    # ET-calendar day start (roster "today")
    with connect() as conn:
        accts = subdivision.active_accounts(conn)                                    # carries owner_identity (M4)
        if account_id not in authz.visible_account_ids(identity, is_admin_flag, accts):
            return _FORBIDDEN if account_id in {a["account_id"] for a in accts} else None
        sub = subdivision.get_subdivision(conn, account_id, category)
        if sub is None:
            return None
        acct = next((a for a in accts if a["account_id"] == account_id), None)       # for the owner-or-admin Detach gate (R6)
        attached = subdivision.attached_whales(conn, account_id, category)
        orders = subdivision.live_orders(conn, account_id, category)
        n_live_trades = subdivision.live_order_count(conn, account_id, category)   # uncapped -> honest 'N of M' when truncated
        open_positions = subdivision.live_positions(conn, account_id, category)           # net-open per ticker (marks target)
        positions_by_whale = subdivision.live_positions_by_whale(conn, account_id, category)   # open per (ticker, whale)
        floor = search.DEFAULT_MIN_RESOLVED_FLOOR
        copies_by_whale = subdivision.live_copies_by_whale(conn, account_id, category, thin_floor=floor)
        # THE WHALE ROSTER (2026-09-12): per-whale live-copy record, on-roster vs formerly-live, with current value.
        whale_records = subdivision.whale_live_records(conn, account_id, category, marks=marks, now_ts=now_ts,
                                                       today_start_ts=today_start_ts, thin_floor=floor)
        # ★ keep the ANALYZE verdict visible on the LIVE roster too -- the score is keyed (wallet, category), so it
        # persists past Promote-to-live and must not vanish on the surface that matters most. Read-only attach.
        _score_map = _load_whale_score_map(conn, category)
        for _grp in ("on_roster", "formerly_live"):
            for _w in (whale_records.get(_grp) or []):
                _w["score"] = _score_cell(_score_map.get(_w.get("wallet")), now_ts)
        # L3 DRIVER LIVENESS for THIS sub (read-only): the one matching row from the expected-set liveness read.
        liveness_present = heartbeat.table_present(conn)
        _live = [r for r in heartbeat.read_liveness(conn, now_ts=now_ts)
                 if r.account_id == account_id and r.category == category]
        # SIZING (2026-09-12): the header control's current value + last-change (who/age) + the drawer's last-5 audit.
        sizing_state = sizing.read_sizing(conn, account_id, category, now_ts=now_ts)
        sizing_changes = sizing.recent_changes(conn, account_id, category, limit=5)
    ctx = live_view.build_from_cache(orders=orders, open_positions=open_positions,
                                     open_positions_by_whale=positions_by_whale,
                                     cache=ui_cache.cache(), now_ts=now_ts, category=category)
    can_detach = authz.can_act_on_account(identity, is_admin_flag, acct)   # R6: owner-or-admin (UI hint; the POST route is the gate)
    return {"sub": sub, "attached": attached, "n_live_trades": n_live_trades,
            "copies_by_whale": copies_by_whale, "thin_floor": floor, "now_ts": now_ts,
            "account_id": account_id, "category": category,
            "whale_records": whale_records, "can_detach": can_detach,
            # SIZING: `can_size` = owner-or-admin (may LOWER; the change link shows only for them); `viewer_is_admin`
            # gates the RAISE affordance. The POST/GET routes are the true boundary (server-side R1), not these hints.
            "sizing": sizing_state, "sizing_changes": sizing_changes, "can_size": can_detach,
            "viewer_is_admin": is_admin_flag,
            "arm_badge": _arm_badge(account_id, category, now_ts=now_ts),
            "liveness_present": liveness_present, "liveness": _live[0] if _live else None,
            "sizing_summary": subdivision.sizing_summary(sub), **ctx}


def _load_live_events(since_id: int, identity: str | None = None, is_admin_flag: bool = False) -> dict:
    """Events-pulse loader (redesign step 4): the REAL orders/closes with id > since_id, SCOPED to the viewer's
    visible accounts, each named meaningfully (R2). Read-only; never the order path."""
    now_ts = int(time.time())
    marks, _ = _cache_marks()
    with connect() as conn:
        accts = subdivision.active_accounts(conn)
        visible = authz.visible_account_ids(identity, is_admin_flag, accts)
        ev = subdivision.events_since(conn, int(since_id or 0))

    def _nm(r):
        return live_view.name_market(r["ticker"], r.get("leg"), (marks or {}).get(r["ticker"]), None, r["category"])[0]
    placed = [{"account": r["account_id"], "code": r["category"].upper(), "name": _nm(r)}
              for r in ev["placed"] if r["account_id"] in visible]
    closed = [{"account": r["account_id"], "code": r["category"].upper(),
               "result": ("won" if r["won"] == 1 else "lost" if r["won"] == 0 else None),
               "realized": r["realized"], "name": _nm(r)}
              for r in ev["closed"] if r["account_id"] in visible]
    return {"max_id": ev["max_id"], "placed": placed, "closed": closed, "now_ts": now_ts}


@app.get("/live/events")
async def live_events(request: Request, since: int = 0, account: str | None = None):
    """The events pulse (redesign step 4): REAL orders/closes with id > `since`, SCOPED to the viewer. The 60s
    poll calls this to animate just-placed / just-closed tiles + play the close tone. READ-ONLY JSON -- it only
    reads the journal the engine wrote, never the order path. `since` is the max id the client last saw."""
    identity, is_admin_flag = authz.current_identity(request), authz.is_admin(request)
    data = await asyncio.to_thread(_load_live_events, int(since or 0), identity, is_admin_flag)
    return JSONResponse(data)


@app.get("/live", response_class=HTMLResponse)
async def live_list_page(request: Request, account: str | None = None):
    """The LIVE sub-division tiles (redesign). Per-account tabs SCOPED to the viewer (M4/R6): admin sees all tabs,
    a non-admin only their own account(s); the ACTIVE tab is in ?account= so it works JS-off. Honest-empty until a
    sub-division exists. READ-ONLY -- no order path."""
    identity, is_admin_flag = authz.current_identity(request), authz.is_admin(request)
    active = (account or "").strip() or None
    data = await asyncio.to_thread(_load_live_list, active, identity, is_admin_flag)
    return templates.TemplateResponse(request, "pm_live_list.html", {"request": request, **data})


@app.get("/live/{account_id}/{category}", response_class=HTMLResponse)
async def live_subdivision_page(request: Request, account_id: str, category: str, tab: str | None = None):
    """One Account-Category sub-division as the GAME-CARD page: a card per game we hold, with the box score
    (cached sports feed), three fixed bet slots valued at contracts x BID (cached Kalshi marks), and a trade
    drawer. `?tab=complete` shows settled cards (server-rendered so it works JS-off). Absent -> 404; exists but
    not this identity's -> 403 (R6 scoping -- inventory add#5). READ-ONLY (no order path)."""
    account_id = (account_id or "").strip()
    category = (category or "").strip().lower()
    identity, is_admin_flag = authz.current_identity(request), authz.is_admin(request)
    data = await asyncio.to_thread(_load_live_subdivision, account_id, category, int(time.time()),
                                   identity, is_admin_flag)
    if data is None:
        return templates.TemplateResponse(
            request, "pm_live_404.html",
            {"request": request, "account_id": account_id, "category": category}, status_code=404)
    if data is _FORBIDDEN:
        return PlainTextResponse("forbidden: not your account", status_code=403)
    data["tab"] = "complete" if (tab or "").strip().lower() == "complete" else "active"
    return templates.TemplateResponse(request, "pm_live_subdivision.html", {"request": request, **data})


# ── Watchlist whale detail (Stage 2, phase 2) -- a PINNED whale's PAPER trades + paper stats ──────
# BASIS: paper (pm_paper_trade / pm_paper_category_stats), read via positions.paper_trades / paper_stats_row.
# DELIBERATELY a separate route + template from the completed /whale/{wallet}/{category} detail: a pinned whale's
# detail shows OUR paper trades, a prospect's shows its COMPLETED trades -- wiring a pinned row to the completed
# detail would be the exact basis violation this stage guards.

def _load_watchlist_whale(wallet: str, category: str, now_ts: int) -> dict:
    """A pinned whale's PAPER detail read: whale header + the paper-basis stats + ALL its paper trades, on ONE
    short-lived read connection, OFF the loop. Reads the PAPER lane ONLY -- never pm_closed_position."""
    with connect() as conn:
        whale = positions.whale_row(conn, wallet)
        pstats = positions.paper_stats_row(conn, wallet, category)
        trades = positions.paper_trades(conn, wallet, category)
        refresh = stats.refresh_band_state(stats.max_refresh_ts(conn), now_ts)
    # Item 2 (2026-09-12): decorate each paper trade with the SAME structural label rule as the /live positions table
    # + the trade drawer -- matchup + signed shorthand -- via the ONE shared formatter (live_view.poly_market_label,
    # which parses the Poly slug with the engine's canonical parse_poly_bet). Fail-closed: a non-structural category
    # or an unparseable/prop slug leaves mlabel/matchup None so the template keeps its honest title/slug display.
    for t in trades:
        mu, primary, secondary = live_view.poly_market_label(category, t.get("slug"), t.get("outcome"), t.get("title"))
        t["matchup"], t["mlabel"], t["msub"] = mu, primary, secondary
    return {"whale": whale, "pstats": pstats, "trades": trades, "refresh": refresh}


@app.get("/watchlist/{wallet}/{category}", response_class=HTMLResponse)
async def watchlist_whale(request: Request, wallet: str, category: str):
    """A pinned (Watchlist) whale's PAPER detail: all its paper trades + the paper-basis stats. Distinct from the
    completed `/whale/{wallet}/{category}` detail (which the Prospects section links to). Honest-empty for an
    unknown wallet / a pair with no paper trades yet -- never a fabrication."""
    wallet = (wallet or "").lower()
    data = await asyncio.to_thread(_load_watchlist_whale, wallet, category, int(time.time()))
    return templates.TemplateResponse(
        request, "pm_watchlist_whale.html", {"request": request, "wallet": wallet, "category": category, **data})
