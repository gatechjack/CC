"""Abstract broker interfaces.

Two ABCs, parent → child:

  ReadOnlyBroker
      connect / disconnect / snapshot / quote
      No order-placement methods. Adapters that subclass this CANNOT
      place orders — enforced by the type system, not by runtime flags.
      Use this for venues we want to read but never write to (e.g.
      Polymarket Phase 1, future read-only views of any broker).

  Broker(ReadOnlyBroker)
      Adds place_order + cancel_order.
      Use this for venues that route real orders.

Why split: read-only-by-missing-methods is a stronger guarantee than
read-only-by-config-flag. A code path that calls `broker.place_order`
on a `ReadOnlyBroker` is a static type error, not a runtime
NotImplementedError. CLAUDE.md §1 "Code path isolation" makes this
the rule for new read-only adapters.

Existing concrete brokers (paper, robinhood, coinbase, fidelity,
bitunix) all subclass `Broker` directly. They keep the full surface
including place_order; behavior is unchanged. The Fidelity-specific
migration to ReadOnlyBroker is tracked separately (CLAUDE.md §7
"Known sharp edges") and is NOT part of this split.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from trading_corp.persistence.models import FillEvent, Position, ProposedOrder


@dataclass
class AccountSnapshot:
    account: str
    equity: float
    buying_power: float
    cash: float
    positions: list[Position]
    # True  => `equity` summed ALL expected balance sources (a trustworthy read).
    # False => a balance source errored (e.g. a BitUnix 10006 on one stablecoin)
    #          and was dropped from the sum, so `equity` is UNDER-reported.
    # Defaults True so single-source brokers (robinhood/tasty/coinbase/polymarket/
    # kalshi/paper) and the stub are always "complete" with no change. Consumed by
    # the bitunix drawdown breaker, which ABSTAINS on an incomplete read rather
    # than act on a phantom (under-reported) drawdown. See
    # runbooks/2026-06-15_breaker_abstain_on_partial_equity_scoping.md.
    equity_complete: bool = True
    # SETTLED, PLACEABLE cash — the cash that can actually fund a NEW order right
    # now, EXCLUDING unsettled proceeds (T+1 on a cash account) and cash already
    # held for open orders. None => the broker does not expose it (paper/stub and
    # every non-RH adapter keep None, so nothing changes for them). Currently only
    # RobinhoodBroker populates it (from load_account_profile); consumed by the
    # PEAD derived, self-balancing sizer. Additive/optional by design.
    settled_cash: float | None = None
    # AVAILABLE (free) buying power — gross margin buying power LESS what is already
    # committed to open positions (option collateral); i.e. the free capacity that
    # can actually margin a NEW defined-risk spread right now (the "margin available
    # to invest" figure ~ RH's unleveraged_buying_power, distinct from gross
    # `buying_power`). None => the broker does not expose it (paper/stub and every
    # non-RH adapter keep None). Currently only RobinhoodBroker populates it (from
    # load_account_profile); consumed by MACE's reserve/deployment-cap gate as the
    # sizing basis. Additive/optional by design.
    available_buying_power: float | None = None


class ReadOnlyBroker(ABC):
    """Brokers that can read venue state but cannot place orders.

    Subclass this when the venue is observe-only (Polymarket Phase 1,
    any read-only data feed). Order-placement methods are deliberately
    absent — calling `place_order` on a ReadOnlyBroker is a static
    type error, not a runtime exception.
    """

    name: str = "base-readonly"
    paper: bool = True  # subclasses set False when in live mode

    @abstractmethod
    async def connect(self) -> None: ...

    @abstractmethod
    async def disconnect(self) -> None: ...

    @abstractmethod
    async def snapshot(self) -> AccountSnapshot: ...

    @abstractmethod
    async def quote(self, symbol: str) -> float:
        """Return last trade or mid price for `symbol`."""


class Broker(ReadOnlyBroker):
    """Full broker — read state AND place orders.

    Existing concrete brokers (paper, robinhood, coinbase, fidelity,
    bitunix) all subclass this. New adapters that need to place orders
    subclass this; new adapters that don't subclass `ReadOnlyBroker`
    above.

    `place_multi_leg` and `get_option_greeks` default to NotImplementedError
    rather than being abstract: only the brokers that need them (Robinhood
    for the iron-condor strategy in v1) override. Coinbase, Bitunix, Kalshi,
    Polymarket inherit the default and never see multi-leg traffic.
    """

    name: str = "base"

    @abstractmethod
    async def place_order(self, order: ProposedOrder) -> FillEvent: ...

    @abstractmethod
    async def cancel_order(self, order_id: str) -> bool: ...

    async def place_multi_leg(
        self, orders: list[ProposedOrder], *, ref_id: str | None = None,
    ) -> list[FillEvent]:
        """Submit a multi-leg option combo as a single atomic order.

        All `orders` must share `extra["combo_id"]` and represent legs of
        one combo. `combo_direction` ("credit" | "debit") and
        `net_limit_price` are carried in `extra` on each order — see the
        iron-condor strategy design doc for the full extra-key contract.
        Returns one FillEvent per leg; all share `combo_id` in audit
        downstream. Atomic at the exchange: all legs fill or none do.

        `ref_id` (optional): a deterministic client order id so a transient
        retry dedupes at the venue. When None the adapter mints its own.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support multi-leg combo orders"
        )

    async def get_option_greeks(self, option_id: str) -> dict[str, float | None]:
        """Return Greeks + IV + mark for an option by ID.

        Keys: delta, gamma, theta, vega, iv, mark_price. Values may be
        None if the venue does not publish a field. No open-position
        context required — looks up market data by `option_id` alone.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not expose option Greeks"
        )

    async def get_option_quote(
        self, symbol: str, expiration: str, strike: float, option_type: str,
    ) -> dict[str, float | None]:
        """Return live {bid, ask, mark} for one option contract by
        (symbol, expiration 'YYYY-MM-DD', strike, 'call'|'put'). Used by the
        combo dispatch to re-price a spread from the natural at approval time.
        Values may be None when the venue omits a field.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not expose option quotes"
        )


# ---------------------------------------------------------------------------
# Combo-cohesion validation helper
#
# Shared by every broker that implements `place_multi_leg` (live Robinhood
# and PaperExecutionBroker today). Centralising the checks here keeps
# error messages identical across live/paper paths, so strategy code can
# rely on the same exception text in tests regardless of which broker is
# wrapped.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ComboParams:
    """Combo-level parameters extracted after cohesion validation."""
    combo_id: str
    direction: str          # "credit" | "debit"
    net_limit: float        # always positive
    underlying: str
    quantity: int


def validate_combo_cohesion(orders: list[ProposedOrder]) -> ComboParams:
    """Verify all `orders` represent legs of one combo and return the
    combo-level parameters. Raises ValueError on any inconsistency.

    Checks:
      - At least one order in the list.
      - All legs share `extra.combo_id`.
      - All legs share `extra.combo_direction` ∈ {"credit", "debit"}.
      - All legs share `extra.net_limit_price` (parseable as a positive float).
      - All legs share `qty`.
      - All legs share `underlying` (from `extra.underlying` or `order.symbol`).

    Per-leg fields needed for the venue payload (expiration, strike,
    option_type, position_effect) are validated by the specific broker's
    `place_multi_leg` implementation, not here — they're broker-specific
    payload concerns, not cross-leg cohesion.
    """
    if not orders:
        raise ValueError("validate_combo_cohesion requires at least one order")

    first_extra = orders[0].extra or {}
    combo_id = first_extra.get("combo_id")
    direction = first_extra.get("combo_direction")
    net_limit = first_extra.get("net_limit_price")
    underlying = first_extra.get("underlying") or orders[0].symbol
    quantity = int(orders[0].qty)

    if combo_id is None:
        raise ValueError("place_multi_leg requires extra.combo_id on every leg")
    if direction not in ("credit", "debit"):
        raise ValueError(
            f"combo_direction must be 'credit' or 'debit', got {direction!r}"
        )
    if net_limit is None:
        raise ValueError("place_multi_leg requires extra.net_limit_price")
    try:
        net_limit_f = float(net_limit)
    except (TypeError, ValueError) as e:
        raise ValueError(f"net_limit_price not a number: {net_limit!r}") from e
    if net_limit_f <= 0:
        raise ValueError(f"net_limit_price must be positive, got {net_limit_f}")

    for o in orders:
        ex = o.extra or {}
        if ex.get("combo_id") != combo_id:
            raise ValueError(
                f"mixed combo_ids in place_multi_leg: "
                f"{combo_id!r} vs {ex.get('combo_id')!r}"
            )
        if ex.get("combo_direction") != direction:
            raise ValueError(f"mixed combo_direction in {combo_id!r}")
        if float(ex.get("net_limit_price", 0)) != net_limit_f:
            raise ValueError(f"mismatched net_limit_price in {combo_id!r}")
        if int(o.qty) != quantity:
            raise ValueError(f"mismatched qty in {combo_id!r}")
        if (ex.get("underlying") or o.symbol) != underlying:
            raise ValueError(f"mixed underlying in {combo_id!r}")

    return ComboParams(
        combo_id=str(combo_id),
        direction=direction,
        net_limit=net_limit_f,
        underlying=str(underlying),
        quantity=quantity,
    )
