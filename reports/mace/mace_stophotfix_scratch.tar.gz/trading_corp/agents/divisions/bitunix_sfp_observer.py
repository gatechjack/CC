"""Bitunix SFP division — engine-side signal loop + slim placement.

Holds, per traded symbol, a REAL and a CONSIDERABLE :class:`SfpDetector`
(``bitunix_sfp.py``) plus a 15m :class:`LiveBarCache`. A single SEQUENTIAL loop,
aligned to the 15m bar close, walks the configured ``symbols`` list, feeds each
symbol's freshly-closed bars to its detectors, and on a BOS-confirmed signal
builds a :class:`ProposedOrder`, runs the MANDATORY risk gate
(``RiskAgent.evaluate`` — the single chokepoint, CLAUDE.md #1), and places via a
slim writer that reuses the shared execution machinery: ``data_exec.place(
division="bitunix_sfp")`` places the entry + the atomic B1 server-side stop, and
``_place`` THEN rests a SINGLE full-qty native ``/tpsl/`` reduce-only TP leg
post-fill (OCO with the B1 stop) so a winning trade actually closes at 2R on the
venue — not just on the stop. ``place_order`` itself attaches ONLY the B1 stop;
the TP is a separate post-fill ``place_tpsl_order`` call (fail-soft + LOUD: any
TP-place failure leaves the filled entry + B1 stop intact and alerts, never
silent, never unwinds the entry). Live entries write a Path-C
``paper_trade_record`` row tagged ``execution_mode="live"`` + ``broker_order_id``
so the existing per-account reconciler / auto-book / ref-vs-fill track and book
the position UNCHANGED.

This is a NEW signal + division wired into proven execution — NOT new execution
logic. It deliberately does NOT reuse the 3500-line confluence observer (a
prod-surface md5-manifest file that hardcodes ``bitunix_futures``); the slim
placement writer below is the narrow slice it actually needs.

Symbol-agnostic by construction: the loop iterates the YAML ``symbols`` list
(BTC-only for now); nothing here hardcodes a coin. The per-(symbol,side)
concurrent-position guard prevents the division stacking a second same-side
position on any symbol.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from trading_corp.persistence import db
from trading_corp.agents.divisions import bitunix_sfp_research_log as research_log
from trading_corp.agents.strategies.bitunix_inst_levels import InstLevels
from trading_corp.agents.strategies import bitunix_rd_trend as rd_trend
from trading_corp.agents.strategies import bitunix_ps_trail_trend as ps_trail_trend
from trading_corp.persistence.models import (
    AccountState,
    PaperTradeRecord,
    ProposedOrder,
    StrategyState,
)
from trading_corp.agents.strategies.bitunix_sfp import (
    MODE_CONSIDERABLE,
    MODE_REAL,
    SfpBar,
    SfpDetector,
    SfpEntrySignal,
    SfpModeBDetector,
    compute_geometry,
)
from trading_corp.brokers.bitunix_symbols import to_wire_format

log = logging.getLogger(__name__)

DIVISION = "bitunix_sfp"
PEAK_EQUITY_AGENT_STATE_KEY = "account_peak_equity"
LOOP_HEARTBEAT_AGENT_STATE_KEY = "loop_last_evaluated"

# ── sfp_watch_state — OBSERVE-ONLY dashboard Tier-B persistence ─────────────
# One logical row per armed watch, UPSERT'd through ARMED → terminal by a stable
# watch_id = f"{symbol}:{mode}:{fired_bar_ts_ms}". CREATE IF NOT EXISTS is run
# defensively at observer init (the gated migration also creates it).
_SFP_WATCH_DDL = (
    "CREATE TABLE IF NOT EXISTS sfp_watch_state ("
    " watch_id TEXT PRIMARY KEY,"
    " fired_bar_ts INTEGER NOT NULL,"
    " symbol TEXT NOT NULL,"
    " mode TEXT NOT NULL,"
    " swept_level REAL NOT NULL,"
    " swept_wick REAL NOT NULL,"
    " bos_watch_level REAL,"
    " status TEXT NOT NULL,"
    " status_ts TEXT NOT NULL,"
    " armed_ts TEXT NOT NULL,"
    " terminal_bar_ts INTEGER,"
    " extra_json TEXT)"
)
_SFP_WATCH_IX1 = ("CREATE INDEX IF NOT EXISTS ix_sfp_watch_state_status "
                  "ON sfp_watch_state(status, status_ts)")
_SFP_WATCH_IX2 = ("CREATE INDEX IF NOT EXISTS ix_sfp_watch_state_symbol "
                  "ON sfp_watch_state(symbol, status)")
# armed_ts is NOT in the UPDATE set — the original ARMED insert's value is kept.
_SFP_WATCH_UPSERT = (
    "INSERT INTO sfp_watch_state "
    "(watch_id, fired_bar_ts, symbol, mode, swept_level, swept_wick, bos_watch_level, "
    " status, status_ts, armed_ts, terminal_bar_ts, extra_json) "
    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?) "
    "ON CONFLICT(watch_id) DO UPDATE SET "
    "  status=excluded.status, "
    "  status_ts=excluded.status_ts, "
    "  bos_watch_level=COALESCE(excluded.bos_watch_level, sfp_watch_state.bos_watch_level), "
    "  terminal_bar_ts=COALESCE(excluded.terminal_bar_ts, sfp_watch_state.terminal_bar_ts), "
    "  extra_json=COALESCE(excluded.extra_json, sfp_watch_state.extra_json)"
)
_WATCH_RECENT_WINDOW_SEC = 24 * 3600   # warm-start (b): only persist last 24h


def _watch_bars_from_hours(watch_hours: float, tf_minutes: int = 15) -> int:
    return int(watch_hours * 60 / tf_minutes)


# ── Regime component (engine-native; 2026-07-01 bidirectional deploy) ──────────
# 15m EMA-200 + 32-bar slope, PARITY-LOCKED to the research `regime_filter.py`
# `ema200_pos_slope`: FIRST-CLOSE-seeded streaming EMA (deliberately NOT
# `_ta_helpers.ema_series`, which is SMA-seeded + differently indexed and would
# break label parity), rising = em[-1] > em[-33]. Computed inline from the
# observer's own 15m bar cache (single source of truth). Fail-safe: returns None
# (→ side-gate skips, never fires without a regime) until >=232 closed 15m bars.
REGIME_ENGINE = "15m_ema200_slope"
REGIME_EMA_PERIOD = 200
REGIME_SLOPE_BARS = 32
REGIME_MIN_BARS = REGIME_EMA_PERIOD + REGIME_SLOPE_BARS   # 232 (formula minimum)

# Boot seed (2026-07-01, Option A): converge the EMA-200 from the APPEND-ONLY
# bitunix_bar_history 15m capture at boot (independent of the venue kline-fetch
# depth), then maintain inline from live closes. REGIME_SEED_BARS = working-set cap;
# the regime is gated OFF (None -> side-gate SKIPs, audit sfp_skip_regime_warmup)
# below REGIME_SEED_MIN so it NEVER fires on an unconverged EMA-200. Parity vs the
# research regime: 788 closes=99.96%, 1000=99.99%, 1500=100%.
REGIME_SEED_BARS = 1500
REGIME_SEED_MIN = 800    # operator-set gate (trade-from-minute-one; ~99.96% floor
                         # today, self-heals to ~100% as the capture deepens)


def _regime_ema200(closes: list[float]) -> list[float]:
    """First-close-seeded streaming EMA-200 (== research `regime_filter.ema`).
    One value per input close (out[0] == closes[0])."""
    a = 2.0 / (REGIME_EMA_PERIOD + 1.0)
    e: float | None = None
    out: list[float] = []
    for c in closes:
        e = c if e is None else a * c + (1.0 - a) * e
        out.append(e)
    return out


def compute_regime_label(closes: list[float]) -> str | None:
    """UP / DOWN / RANGE from 15m EMA-200 + 32-bar slope, or None if
    < REGIME_MIN_BARS (warmup fail-safe). k=1 causal: closes[-1] is the last
    CLOSED 15m bar; em[-33] is the slope reference 32 bars back."""
    if len(closes) < REGIME_MIN_BARS:
        return None
    em = _regime_ema200(closes)
    c = closes[-1]
    e = em[-1]
    rising = em[-1] > em[-(REGIME_SLOPE_BARS + 1)]
    if c > e and rising:
        return "up"
    if c < e and not rising:
        return "down"
    return "range"


# ── Short side (M2=0 reflection; 2026-07-01 bidirectional deploy) ──────────────
# The vendored detector is long-only; SHORT SFPs are detected by feeding the SAME
# byte-identical SfpModeBDetector a REFLECTED bar stream. M2=0 (reflected = -real,
# high/low swapped) is a UNIVERSAL constant that CANNOT drift — the one silent-
# failure mode (M2 drift corrupting stored reflected-coordinate pivot/swing/watch
# state) is impossible by construction. The detector is fully order-based so negative
# coords are fine and the fed path makes no positivity assumption. Un-reflect a
# reflected level L to real via (0 - L) = -L. Affine-invariance vs the research
# max+min midpoint reflection is PROVEN in short_parity_test.py (identical fires).
def reflect_neg(bars: list[SfpBar]) -> list[SfpBar]:
    """M2=0 reflection: reflected = -real, high/low swapped (reflected_high =
    -real_low, reflected_low = -real_high). A LONG SFP on the reflected series ==
    a SHORT SFP on the real series."""
    return [SfpBar(b.ts_ms, -b.open, -b.low, -b.high, -b.close) for b in bars]


def geometry_short(entry_ref: float, swept_high: float, *,
                   stop_buffer_pct: float, tp_r: float):
    """Short-side geometry in REAL space (mirror of the vendored long-only
    ``compute_geometry``, which stays byte-identical). stop = swept_high +
    stop_buffer_pct*entry (ABOVE entry); r = stop - entry; tp = entry - tp_r*r
    (BELOW entry). Returns (stop, tp, r) or None if r<=0 (degenerate: entry >=
    swept_high — never for a valid sweep-above-and-reclaim-down)."""
    stop = swept_high + stop_buffer_pct * entry_ref
    r = stop - entry_ref
    if r <= 0:
        return None
    tp = entry_ref - tp_r * r
    return stop, tp, r


@dataclass
class BitunixSfpConfig:
    """Parsed ``bitunix_sfp`` block from strategies.yaml. p6 ports
    (``pivot_len``/``back_to_break``/``stop_buffer_pct``/``tp_r``/``watch_hours``)
    must not drift without re-running the detector parity test."""
    enabled: bool = False
    auto_execute: bool = False
    execution_mode: str = "paper"           # "paper" | "live"
    division: str = DIVISION
    symbols: tuple[str, ...] = ("BTC/USDT.P",)
    detection_tf: str = "15m"            # "15m" (today) | "1h" (L4: SFP fires on 1h)
    swing_mode: str = "pivot50"          # "pivot50" (p6, today) | "two_candle" (L0: degree-2 fractal = validated construct)
    pivot_len: int = 50
    back_to_break: int = 4
    stop_buffer_pct: float = 0.001
    tp_r: float = 2.0
    watch_hours: float = 12.0
    side: str = "long"
    with_trend: bool = False             # L2: true = with-trend only (drop range; ema200 up/down)
    # L5 per-coin tight with-trend SOURCE (wire-keyed): 'ema200' (the live tight gate: 15m regime
    # up-only long / down-only short) | 'rd' (LuxAlgo Range-Detector 1h break-state os: os==+1 long,
    # os==-1 short, os==0/None sit out) | 'ps_trail30' (causal one-sided Pagan-Sossounov DAILY trend,
    # the causal-macro60 winner: prior-day st_ps_trail(30) state == 'bull' long / 'bear' short / None
    # sit out). Default 'ema200' for EVERY coin => behavior-identical until an explicit arm flips a coin.
    # Only consulted when with_trend is True; the LOOSE ema200 up/range side-gate (the base opportunity
    # set) is UNCHANGED regardless of trend_mode.
    trend_mode: dict[str, str] = field(default_factory=dict)
    fresh_inst: bool = False             # L3: true = require the swept level at a FRESH institutional level (BTC-first)
    risk_pct_real: float = 0.005
    risk_pct_considerable: float = 0.005
    leverage: float = 5.0
    max_hold_seconds: int = 604_800
    bar_cache_max_bars: int = 160
    loop_settle_seconds: int = 20
    # Mode B (15m SFP → 3m BOS). ``symbol_modes`` is OPTIONAL and BACKWARD-COMPAT:
    # when empty, every symbol uses (bos_tf=detection_tf, arm="trading") — today's
    # behavior exactly. Keyed by WIRE symbol → (bos_tf, arm) with
    # bos_tf ∈ {"15m","3m"}, arm ∈ {"trading","watch"} ("watch" runs the detector
    # but forces PAPER — a no-order forward-track).
    watch_hours_3m: float = 12.0
    symbol_modes: dict[str, tuple[str, str]] = field(default_factory=dict)

    def mode_for(self, wire: str) -> tuple[str, str]:
        """(bos_tf, arm) for a wire symbol; default (detection_tf, 'trading')."""
        return self.symbol_modes.get(wire, (self.detection_tf, "trading"))

    def trend_mode_for(self, wire: str) -> str:
        """Tight with-trend gate SOURCE for a wire symbol; default 'ema200' (behavior-identical).
        One of 'ema200'|'rd'|'ps_trail30'. NOTE the LIVE decision path fresh-reads the YAML per signal
        (``_yaml_trend_mode``) so an arm is HOT; this dataclass value is the boot-time default /
        fallback if the YAML read fails."""
        return self.trend_mode.get(wire, "ema200")

    @property
    def uses_mode_b(self) -> bool:
        return any(bos_tf == "3m" for bos_tf, _arm in self.symbol_modes.values())

    @classmethod
    def from_dict(cls, raw: dict[str, Any] | None) -> "BitunixSfpConfig":
        raw = raw or {}
        syms = raw.get("symbols") or ["BTC/USDT.P"]
        if isinstance(syms, str):
            syms = [syms]
        detection_tf = str(raw.get("detection_tf", "15m"))
        # Parse the optional per-symbol mode map (wire-keyed, validated).
        symbol_modes: dict[str, tuple[str, str]] = {}
        for disp, spec in (raw.get("symbol_modes") or {}).items():
            spec = spec or {}
            wire = to_wire_format(str(disp))
            bos_tf = str(spec.get("bos_tf", detection_tf)).lower()
            arm = str(spec.get("arm", "trading")).lower()
            if bos_tf not in ("15m", "3m"):
                raise ValueError(
                    f"bitunix_sfp.symbol_modes[{disp}].bos_tf must be 15m|3m, got {bos_tf!r}")
            if arm not in ("trading", "watch"):
                raise ValueError(
                    f"bitunix_sfp.symbol_modes[{disp}].arm must be trading|watch, got {arm!r}")
            symbol_modes[wire] = (bos_tf, arm)
        # L5 per-coin tight with-trend source map (wire-keyed, validated). Optional + backward-compat:
        # an absent/empty map => every coin defaults to 'ema200' = today's behavior exactly. Keys may be
        # display ("BTC/USDT.P") or already-wire ("BTCUSDT") — normalized to wire.
        trend_mode: dict[str, str] = {}
        for disp, val in (raw.get("trend_mode") or {}).items():
            mode = str(val).lower()
            if mode not in ("ema200", "rd", "ps_trail30"):
                raise ValueError(
                    f"bitunix_sfp.trend_mode[{disp}] must be ema200|rd|ps_trail30, got {mode!r}")
            try:
                wire = to_wire_format(str(disp))
            except Exception:
                wire = str(disp)          # already-wire key (e.g. 'BTCUSDT') passes through
            trend_mode[wire] = mode
        return cls(
            enabled=bool(raw.get("enabled", False)),
            auto_execute=bool(raw.get("auto_execute", False)),
            execution_mode=str(raw.get("execution_mode", "paper")).lower(),
            division=str(raw.get("division", DIVISION)),
            symbols=tuple(str(s) for s in syms),
            detection_tf=detection_tf,
            swing_mode=str(raw.get("swing_mode", "pivot50")).lower(),
            pivot_len=int(raw.get("pivot_len", 50)),
            back_to_break=int(raw.get("back_to_break", 4)),
            stop_buffer_pct=float(raw.get("stop_buffer_pct", 0.001)),
            tp_r=float(raw.get("tp_r", 2.0)),
            watch_hours=float(raw.get("watch_hours", 12.0)),
            side=str(raw.get("side", "long")).lower(),
            with_trend=bool(raw.get("with_trend", False)),
            trend_mode=trend_mode,
            fresh_inst=bool(raw.get("fresh_inst", False)),
            risk_pct_real=float(raw.get("risk_pct_real", 0.005)),
            risk_pct_considerable=float(raw.get("risk_pct_considerable", 0.005)),
            leverage=float(raw.get("leverage", 5.0)),
            max_hold_seconds=int(raw.get("max_hold_seconds", 604_800)),
            bar_cache_max_bars=int(raw.get("bar_cache_max_bars", 160)),
            loop_settle_seconds=int(raw.get("loop_settle_seconds", 20)),
            watch_hours_3m=float(raw.get("watch_hours_3m", 12.0)),
            symbol_modes=symbol_modes,
        )


class BitunixSfpObserver:
    """Engine-side SFP signal generator + slim placement for ``bitunix_sfp``."""

    def __init__(
        self,
        *,
        db_url: str,
        risk_agent: Any,
        data_exec: Any,
        logger_agent: Any,
        config: BitunixSfpConfig,
        bar_caches: dict[str, Any],        # wire symbol -> LiveBarCache (15m)
        bar_caches_3m: dict[str, Any] | None = None,  # wire -> LiveBarCache (3m), Mode B
        d1_caches: dict[str, Any] | None = None,      # wire -> LiveBarCache (1d), L3 fresh-inst (BTC-first)
        bar_caches_1h: dict[str, Any] | None = None,  # wire -> LiveBarCache (1h), L4 1h detection fire-feed
        strategies_yaml_path: str | None = None,
    ) -> None:
        self.db_url = db_url
        self.risk_agent = risk_agent
        self.data_exec = data_exec
        self.logger_agent = logger_agent
        self.config = config
        self.bar_caches = bar_caches
        self.bar_caches_3m = bar_caches_3m or {}
        self.d1_caches = d1_caches or {}
        self.bar_caches_1h = bar_caches_1h or {}
        self._strategies_yaml_path = strategies_yaml_path or str(
            Path(__file__).resolve().parents[3] / "config" / "strategies.yaml"
        )
        wb = _watch_bars_from_hours(config.watch_hours)
        wb3 = int(config.watch_hours_3m * 60 / 3)
        # L4: detection_tf drives the SFP-fire -> 3m-BOS bind anchor (15m=900_000, 1h=3_600_000).
        _htf_ms = 3_600_000 if config.detection_tf == "1h" else 900_000
        # Two detectors per symbol (REAL + CONSIDERABLE), pooled — mirrors the
        # oracle's two independent passes. Per symbol the BOS timeframe selects the
        # detector class: 15m → Mode-A SfpDetector (unchanged path); 3m → Mode-B
        # SfpModeBDetector. Backward-compat: an absent symbol_modes map leaves every
        # symbol on Mode-A, so _detectors/_last_ts and the existing loop are byte-
        # identical to today.
        self._detectors: dict[str, list[SfpDetector]] = {}
        self._detectors_b: dict[str, list[SfpModeBDetector]] = {}
        # SHORT SFP detectors: SAME byte-identical SfpModeBDetector, fed a REFLECTED
        # (M2=0) bar stream by the side-gate (Piece 3). Instantiated here; inert (not
        # fed) until then. Long detectors above are byte-unchanged.
        self._detectors_b_short: dict[str, list[SfpModeBDetector]] = {}
        self._symbol_arm: dict[str, str] = {}
        self._symbol_bos_tf: dict[str, str] = {}
        self._last_ts: dict[str, int] = {}
        self._last_ts3: dict[str, int] = {}
        self._last_ts1h: dict[str, int] = {}   # L4: 1h fire-feed high-water (detection_tf=1h)
        # Engine-native regime buffer: bitunix_bar_history boot seed + live appends.
        self._regime_closes: dict[str, list[float]] = {}
        self._regime_last_ts: dict[str, int] = {}
        self._last_regime: dict[str, str | None] = {}   # flip-watch state (change-only)
        for sym in config.symbols:
            wire = to_wire_format(sym)
            bos_tf, arm = config.mode_for(wire)
            self._symbol_arm[wire] = arm
            self._symbol_bos_tf[wire] = bos_tf
            self._last_ts[wire] = 0
            if bos_tf == "3m":
                self._detectors_b[wire] = [
                    SfpModeBDetector(mode=MODE_REAL, pivot_len=config.pivot_len,
                                     back_to_break=config.back_to_break, watch_bars_3m=wb3,
                                     swing_mode=config.swing_mode, htf_ms=_htf_ms),
                    SfpModeBDetector(mode=MODE_CONSIDERABLE, pivot_len=config.pivot_len,
                                     back_to_break=config.back_to_break, watch_bars_3m=wb3,
                                     swing_mode=config.swing_mode, htf_ms=_htf_ms),
                ]
                # SHORT engine (reflected-fed in Piece 3; inert now). Same params.
                self._detectors_b_short[wire] = [
                    SfpModeBDetector(mode=MODE_REAL, pivot_len=config.pivot_len,
                                     back_to_break=config.back_to_break, watch_bars_3m=wb3,
                                     swing_mode=config.swing_mode, htf_ms=_htf_ms),
                    SfpModeBDetector(mode=MODE_CONSIDERABLE, pivot_len=config.pivot_len,
                                     back_to_break=config.back_to_break, watch_bars_3m=wb3,
                                     swing_mode=config.swing_mode, htf_ms=_htf_ms),
                ]
                self._last_ts3[wire] = 0
            else:
                self._detectors[wire] = [
                    SfpDetector(mode=MODE_REAL, pivot_len=config.pivot_len,
                                back_to_break=config.back_to_break, watch_bars=wb),
                    SfpDetector(mode=MODE_CONSIDERABLE, pivot_len=config.pivot_len,
                                back_to_break=config.back_to_break, watch_bars=wb),
                ]
        self.uses_mode_b = bool(self._detectors_b)
        # OBSERVE-ONLY: ensure the dashboard watch-state table exists (idempotent;
        # the gated migration also creates it). Fail-soft, never raises.
        self._ensure_watch_schema()
        research_log.ensure_schema(self.db_url)   # isolated research catalog (fail-soft)
        research_log.ensure_flip_schema(self.db_url)   # regime-flip watch (fail-soft)

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #
    def warm_start_from_cache(self) -> None:
        """Rebuild detector state from each cache's bar history (restart-safe;
        the bars ARE the state). Signals produced during replay are discarded —
        they are historical, already past their entry bar."""
        for sym in self.config.symbols:
            wire = to_wire_format(sym)
            if self._symbol_bos_tf.get(wire) == "3m":
                self._warm_start_b(wire)
                continue
            cache = self.bar_caches.get(wire)
            if cache is None:
                continue
            bars = [self._to_sfp_bar(b) for b in getattr(cache, "bars", [])]
            for det in self._detectors[wire]:
                det.warm_start(bars)
                # OBSERVE-ONLY (warm-start decision b): persist only RECENT (24h)
                # transitions so a restart fills the dashboard without flooding
                # ancient backtest history. Idempotent UPSERT by watch_id.
                self._emit_watch_transitions(wire, det.drain_transitions(), recent_only=True)
            if bars:
                self._last_ts[wire] = bars[-1].ts_ms
        # Engine-native regime: seed from bitunix_bar_history (deep, venue-independent)
        # THEN extend with any fresher cache bars so the first tick has a converged EMA.
        self._seed_regime_from_history()
        for sym in self.config.symbols:
            w = to_wire_format(sym)
            c15 = self.bar_caches.get(w)
            if c15 is not None:
                self._extend_regime(w, [self._to_sfp_bar(b) for b in getattr(c15, "bars", [])])

    def _warm_start_b(self, wire: str) -> None:
        """Mode-B warm-start: replay ALL cached 15m bars (arm watches) then ALL
        cached 3m bars (bind + advance). The contiguity guard drops any 15m fire
        whose t0 3m bar predates the (shallower) 3m cache."""
        c15 = self.bar_caches.get(wire)
        c3 = self.bar_caches_3m.get(wire)
        bars15 = [self._to_sfp_bar(b) for b in getattr(c15, "bars", [])] if c15 else []
        bars3 = [self._to_sfp_bar(b) for b in getattr(c3, "bars", [])] if c3 else []
        # L4: the fire engine replays the DETECTION-TF bars (1h when detection_tf=1h, else 15m);
        # the 15m high-water/regime still track bars15. detection_tf=15m => fire_bars is bars15 (unchanged).
        fire_on_15m = (self.config.detection_tf != "1h")
        if fire_on_15m:
            fire_bars = bars15
        else:
            c1h = self.bar_caches_1h.get(wire)
            fire_bars = [self._to_sfp_bar(b) for b in getattr(c1h, "bars", [])] if c1h else []
        for det in self._detectors_b[wire]:
            det.warm_start(fire_bars, bars3)
            self._emit_watch_transitions(wire, det.drain_transitions(), recent_only=True)
        # SHORT engine warm-start on reflected bars (M2=0); transitions discarded.
        nfire, n3 = reflect_neg(fire_bars), reflect_neg(bars3)
        for det in self._detectors_b_short[wire]:
            det.warm_start(nfire, n3)
            det.drain_transitions()
        if bars15:
            self._last_ts[wire] = bars15[-1].ts_ms
        if not fire_on_15m and fire_bars:
            self._last_ts1h[wire] = fire_bars[-1].ts_ms
        if bars3:
            self._last_ts3[wire] = bars3[-1].ts_ms

    async def run_loop(self) -> None:
        """Sequential 15m-close-aligned loop. One pass per closed bar."""
        while True:
            try:
                await self._sleep_to_next_boundary()
                await self.process_once()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("bitunix_sfp loop tick failed (continuing)")

    async def _sleep_to_next_boundary(self, tf_seconds: int = 900) -> None:
        now = datetime.now(timezone.utc).timestamp()
        nxt = (int(now // tf_seconds) + 1) * tf_seconds + self.config.loop_settle_seconds
        await asyncio.sleep(max(1.0, nxt - now))

    async def process_once(self) -> None:
        """Refresh caches and feed any new closed bars to the detectors,
        SEQUENTIALLY across symbols (no parallel per-coin tasks — avoids racing
        the shared account-equity snapshot)."""
        for sym in self.config.symbols:
            wire = to_wire_format(sym)
            cache = self.bar_caches.get(wire)
            if cache is None:
                continue
            try:
                await cache.refresh()
            except Exception as e:
                log.warning("bitunix_sfp: %s cache refresh failed: %s", wire, e)
            await self._process_symbol(sym, wire, cache)
        # OBSERVE-ONLY heartbeat: one cheap agent_state write per loop cycle so the
        # dashboard can show an honest "loop last evaluated" age. Fail-soft.
        self._write_heartbeat()

    async def _process_symbol(self, symbol_display: str, wire: str, cache: Any) -> None:
        last = self._last_ts.get(wire, 0)
        new_bars = [b for b in getattr(cache, "bars", []) if int(b.ts_ms) > last]
        for raw in new_bars:
            bar = self._to_sfp_bar(raw)
            for det in self._detectors[wire]:
                sigs = det.on_closed_bar(bar)        # decision path UNCHANGED
                for sig in sigs:
                    await self._handle_signal(symbol_display, wire, sig, bar, side="long")
                # OBSERVE-ONLY: drain + persist lifecycle transitions. Fail-soft —
                # CANNOT raise into the loop; a persist failure never affects trading.
                self._emit_watch_transitions(wire, det.drain_transitions())
            self._last_ts[wire] = bar.ts_ms
            self._extend_regime(wire, [bar])            # engine-native regime, inline

    # ------------------------------------------------------------------ #
    # Mode B — ONE 3m-boundary master loop. Drives Mode-A symbols on their 15m
    # bars AND Mode-B symbols (15m arm + 3m BOS) in a SINGLE sequential task, so
    # two order-placement paths can never race the shared equity snapshot. The
    # existing run_loop / process_once / _process_symbol stay byte-unchanged and
    # are reused; main.py spawns run_loop_master iff any symbol is bos_tf=3m.
    # ------------------------------------------------------------------ #
    async def run_loop_master(self) -> None:
        """3m-aligned master loop. Mode-A symbols only act on NEW 15m bars (the
        _last_ts filter makes the extra ticks a no-op); Mode-B symbols arm on NEW
        15m bars and confirm on NEW 3m bars."""
        while True:
            try:
                await self._sleep_to_next_boundary(tf_seconds=180)
                await self.process_once_master()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("bitunix_sfp master loop tick failed (continuing)")

    async def process_once_master(self) -> None:
        for sym in self.config.symbols:
            wire = to_wire_format(sym)
            if self._symbol_bos_tf.get(wire) == "3m":
                c15 = self.bar_caches.get(wire)
                c3 = self.bar_caches_3m.get(wire)
                c1h = self.bar_caches_1h.get(wire) if self.config.detection_tf == "1h" else None
                for c in (c15, c3, c1h):
                    if c is None:
                        continue
                    try:
                        await c.refresh()
                    except Exception as e:
                        log.warning("bitunix_sfp: %s 3m-path cache refresh failed: %s", wire, e)
                await self._process_symbol_b(sym, wire, c15, c3, c1h)
            else:
                cache = self.bar_caches.get(wire)
                if cache is None:
                    continue
                try:
                    await cache.refresh()
                except Exception as e:
                    log.warning("bitunix_sfp: %s cache refresh failed: %s", wire, e)
                await self._process_symbol(sym, wire, cache)
        self._write_heartbeat()

    async def _process_symbol_b(self, symbol_display: str, wire: str,
                                c15: Any, c3: Any, c1h: Any = None) -> None:
        """Mode-B per-symbol pass. (0) NEW 15m bars ARM watches (detection_tf=15m) AND
        ALWAYS extend the 15m ema200 regime; (1) L4: when detection_tf=1h, NEW 1h bars ARM
        watches instead (the regime stays 15m); (2) NEW 3m bars ADVANCE/CONFIRM (entries
        fire only here). detection_tf=15m keeps step 0 byte-identical to the prior behavior."""
        fire_on_15m = (self.config.detection_tf != "1h")
        if c15 is not None:
            last15 = self._last_ts.get(wire, 0)
            for raw in [b for b in getattr(c15, "bars", []) if int(b.ts_ms) > last15]:
                bar15 = self._to_sfp_bar(raw)
                if fire_on_15m:
                    for det in self._detectors_b[wire]:
                        det.on_closed_15m_bar(bar15)        # arm only — returns []
                        self._emit_watch_transitions(wire, det.drain_transitions())
                    bar15_neg = reflect_neg([bar15])[0]     # M2=0 reflection for the SHORT arm
                    for det in self._detectors_b_short[wire]:
                        det.on_closed_15m_bar(bar15_neg)    # arm short watch (returns [])
                        det.drain_transitions()             # discard (short dashboard = Piece 5+)
                self._last_ts[wire] = bar15.ts_ms
                self._extend_regime(wire, [bar15])      # engine-native regime, inline (ALWAYS 15m)
            self._check_regime_flip(wire, symbol_display)   # flip-watch (read-only)
        # L4: detection_tf=1h -> ARM watches on NEW 1h bars (fire engine consumes 1h; the 15m
        # regime above is untouched). htf_ms=3_600_000 binds the 3m BOS window to the 1h close.
        if not fire_on_15m and c1h is not None:
            last1h = self._last_ts1h.get(wire, 0)
            for raw in [b for b in getattr(c1h, "bars", []) if int(b.ts_ms) > last1h]:
                bar1h = self._to_sfp_bar(raw)
                for det in self._detectors_b[wire]:
                    det.on_closed_15m_bar(bar1h)            # arm on the 1h bar — returns []
                    self._emit_watch_transitions(wire, det.drain_transitions())
                bar1h_neg = reflect_neg([bar1h])[0]
                for det in self._detectors_b_short[wire]:
                    det.on_closed_15m_bar(bar1h_neg)
                    det.drain_transitions()
                self._last_ts1h[wire] = bar1h.ts_ms
        if c3 is not None:
            last3 = self._last_ts3.get(wire, 0)
            for raw in [b for b in getattr(c3, "bars", []) if int(b.ts_ms) > last3]:
                bar3 = self._to_sfp_bar(raw)
                for det in self._detectors_b[wire]:
                    sigs = det.on_closed_3m_bar(bar3)
                    for sig in sigs:
                        await self._handle_signal(symbol_display, wire, sig, bar3, side="long")
                    self._emit_watch_transitions(wire, det.drain_transitions())
                # SHORT: same real bar reflected (M2=0); route with the REAL bar3 as the
                # entry anchor. Watch transitions drained+discarded (short dash = Piece 5+).
                bar3_neg = reflect_neg([bar3])[0]
                for det in self._detectors_b_short[wire]:
                    for sig in det.on_closed_3m_bar(bar3_neg):
                        await self._handle_signal(symbol_display, wire, sig, bar3, side="short")
                    det.drain_transitions()
                self._last_ts3[wire] = bar3.ts_ms

    @staticmethod
    def _to_sfp_bar(b: Any) -> SfpBar:
        return SfpBar(ts_ms=int(b.ts_ms), open=float(b.open), high=float(b.high),
                      low=float(b.low), close=float(b.close))

    def _seed_regime_from_history(self) -> None:
        """Boot seed: fill each traded symbol's regime closes buffer from the
        APPEND-ONLY bitunix_bar_history 15m capture, so the EMA-200 is converged
        WITHOUT depending on the venue kline-fetch depth. One-time; live 15m closes
        extend it inline thereafter (single source of truth going forward). Fail-soft
        — never raises into boot; a failed/empty seed leaves the regime None (skip)
        until live bars accrue past REGIME_SEED_MIN."""
        for sym in self.config.symbols:
            wire = to_wire_format(sym)
            try:
                with db.connect(self.db_url) as conn:
                    rows = conn.execute(
                        "SELECT ts_ms, close FROM bitunix_bar_history "
                        "WHERE symbol=? AND timeframe='15m' AND close IS NOT NULL "
                        "ORDER BY ts_ms DESC LIMIT ?",
                        (wire, REGIME_SEED_BARS),
                    ).fetchall()
                rows = sorted(rows, key=lambda r: int(r[0]))          # -> ascending
                self._regime_closes[wire] = [float(r[1]) for r in rows]
                self._regime_last_ts[wire] = int(rows[-1][0]) if rows else 0
                log.info("bitunix_sfp regime seed %s: %d 15m closes (gate=%d)",
                         wire, len(self._regime_closes[wire]), REGIME_SEED_MIN)
            except Exception as e:                                    # fail-soft
                self._regime_closes.setdefault(wire, [])
                self._regime_last_ts.setdefault(wire, 0)
                log.warning("bitunix_sfp regime seed %s FAILED (regime None until live "
                            "accrues): %s", wire, e)

    def _extend_regime(self, wire: str, bars15: list[SfpBar]) -> None:
        """Append NEW closed 15m closes (ts beyond the last seeded/applied) from the
        observer's own live cache and trim the working set — keeps the regime
        engine-native in steady state. Uses its OWN last-ts (independent of the
        detector's) so it dedups against the history seed."""
        buf = self._regime_closes.setdefault(wire, [])
        last = self._regime_last_ts.get(wire, 0)
        changed = False
        for b in bars15:
            if int(b.ts_ms) > last:
                buf.append(float(b.close)); last = int(b.ts_ms); changed = True
        if changed:
            self._regime_last_ts[wire] = last
            if len(buf) > REGIME_SEED_BARS:
                del buf[: len(buf) - REGIME_SEED_BARS]

    def _compute_regime(self, wire: str) -> str | None:
        """Engine-native 15m regime from the seeded+maintained closes buffer
        (bitunix_bar_history boot seed + inline live appends; single source of truth).
        Returns 'up'|'down'|'range', or None until the buffer holds >= REGIME_SEED_MIN
        closes (convergence fail-safe: NEVER fire on an unconverged EMA-200). The
        buffer is ascending, so closes[-1] is the last CLOSED 15m bar — k=1 causal."""
        closes = self._regime_closes.get(wire) or []
        if len(closes) < REGIME_SEED_MIN:
            return None
        return compute_regime_label(closes)

    def _check_regime_flip(self, wire: str, symbol_display: str) -> None:
        """Flip-watch (read-only monitor; NO trading logic). Uses the SAME
        _compute_regime the side-gate uses (single source — never a 2nd/different
        regime). Emits a flip row ONLY on a label->label change; warmup (None->label),
        teardown (label->None) and no-change do NOT emit. Fail-soft — a flip-logging
        error can never reach the trade path. Highest-value flip = -> UP (missing bull)."""
        try:
            new = self._compute_regime(wire)
            old = self._last_regime.get(wire)
            self._last_regime[wire] = new                    # always update (incl None)
            # ema200 + 32-bar slope from the SAME buffer — metadata, not a 2nd regime.
            closes = self._regime_closes.get(wire) or []
            ema200 = slope = None
            if len(closes) >= REGIME_MIN_BARS:
                em = _regime_ema200(closes)
                ema200 = em[-1]
                ref = em[-(REGIME_SLOPE_BARS + 1)]
                if ref:
                    slope = (em[-1] - ref) / ref
            ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
            # Always-current mirror (read-only display; the SAME `new`, single-source).
            if new is not None:
                research_log.upsert_regime_state(self.db_url, coin=wire, regime=new,
                                                 ema200=ema200, slope=slope, ts=ts)
            # Flip row + audit ONLY on a real label->label change.
            if research_log.is_regime_flip(old, new):
                research_log.log_flip(self.db_url, ts=ts, coin=wire, old_regime=old,
                                      new_regime=new, ema200=ema200, slope=slope)
                self._audit("sfp_regime_flip", {"symbol": symbol_display, "coin": wire,
                            "old_regime": old, "new_regime": new, "to_up": new == "up"})
        except Exception as e:                               # never into the trade path
            log.warning("bitunix_sfp regime-flip check failed (%s): %s", wire, e)

    # ------------------------------------------------------------------ #
    # Signal → order → risk → place
    # ------------------------------------------------------------------ #
    async def _handle_signal(
        self, symbol_display: str, wire: str, sig: SfpEntrySignal, bar: SfpBar,
        side: str = "long",
    ) -> None:
        # config.side kill-switch (operator lever; HOT — config-flippable, NO restart /
        # redeploy). Pure SUPPRESSION on top of the regime gate — never widens it.
        # regime = bidirectional; long = long-only (maiden-short rollback: shorts stop,
        # longs keep collecting); short = short-only. `side` = the DETECTOR-fired side.
        cfg_side = self._yaml_side()
        allowed = {"regime": ("long", "short"), "long": ("long",),
                   "short": ("short",)}[cfg_side]
        if side not in allowed:
            self._audit("sfp_skip_side_disabled", {
                "symbol": symbol_display, "side": side, "config_side": cfg_side,
                "sfp_mode": sig.sfp_mode})
            return
        # Entry reference = the BOS bar close (real; the fill is the live anchor).
        # Geometry BY SIDE: long from the swept wick low (vendored compute_geometry,
        # unchanged); short from the un-reflected swept HIGH (M2=0: real = -reflected)
        # via geometry_short (stop ABOVE entry, tp BELOW). `sig` for a short comes from
        # the reflected detector, but `bar` is the REAL 3m BOS bar (real entry_ref).
        entry_ref = bar.close
        if side == "short":
            geo = geometry_short(
                entry_ref, -sig.swept_low,
                stop_buffer_pct=self.config.stop_buffer_pct, tp_r=self.config.tp_r)
        else:
            geo = compute_geometry(
                entry_ref, sig.swept_low,
                stop_buffer_pct=self.config.stop_buffer_pct, tp_r=self.config.tp_r)
        if geo is None:
            self._audit("sfp_skip_invalid_geometry", {
                "symbol": symbol_display, "side": side, "sfp_mode": sig.sfp_mode,
                "entry_ref": entry_ref, "swept": sig.swept_low})
            return
        stop_price, tp_price, r_unit = geo

        # ── REGIME SIDE-GATE (Piece 3): the 15m regime PICKS the side; never counter-
        # trend. regime None (buffer < REGIME_SEED_MIN / unconverged) => never fire.
        regime = self._compute_regime(wire)
        if regime is None:
            self._audit("sfp_skip_regime_warmup", {
                "symbol": symbol_display, "side": side, "sfp_mode": sig.sfp_mode})
            return
        # LOOSE ema200 side-gate — the BASE opportunity set, ALWAYS-ON for every arm (never widened
        # by the tight filter below). A coin gated to RD must STILL pass this: RD tightens, never
        # loosens. Identical to the bake-off's always-on loose side-gate.
        loose_ok = ((regime in ("up", "range")) if side == "long"
                    else (regime in ("down", "range")))
        if not loose_ok:
            self._audit("sfp_skip_counter_trend", {
                "symbol": symbol_display, "side": side, "regime": regime,
                "sfp_mode": sig.sfp_mode})
            return
        if self.config.with_trend:
            # L2/L5 with-trend: the TIGHT direction filter. Its SOURCE is per-coin (HOT-read):
            #   'ema200' (default) -> fire ONLY with the 15m ema200 regime (up-only long / down-only
            #             short). = the live tight gate. NOTE: research with-trend used macro60 daily
            #             PS/BB, not ema200 (Deviation #1) — ema200 captures ~13% of that edge.
            #   'rd'               -> fire ONLY with the LuxAlgo Range-Detector 1h break-state os:
            #             os==+1 long, os==-1 short (os==0/None = ranging/insufficient -> sit out).
            #             RD won the with-trend gate bake-off on BTC/ETH/XRP (+0.095 pooled); a LEAD,
            #             not a null-cleared edge (66th pctile of its own drift-null).
            #   'ps_trail30'       -> fire ONLY with the causal one-sided Pagan-Sossounov DAILY trend
            #             (st_ps_trail(30) prior-day state == 'bull' long / 'bear' short; None -> sit
            #             out). The DAILY analog of the RD 1h gate + the causal WINNER of the causal-
            #             macro60 study (pooled +0.128; BTC +0.067) — the live-recoverable part of the
            #             non-causal macro60 gate. A LEAD, not a null-cleared edge.
            tmode = self._yaml_trend_mode(wire)
            if tmode == "rd":
                # entry_ts = the 3m bar AFTER the BOS bar (== the fresh-inst gate's convention); RD
                # looks up the last 1h bar CLOSED strictly before it (causal, no peek).
                entry_ts_rd = int(bar.ts_ms) + 180_000
                os_v = None
                try:
                    os_v = rd_trend.rd_os_at(self.db_url, wire, entry_ts_rd)
                except Exception as e:                       # fail-soft -> sit out, never fire blind
                    log.warning("bitunix_sfp: rd_os_at failed for %s (sit out): %s", wire, e)
                    os_v = None
                if os_v is None:
                    self._audit("sfp_skip_rd_no_data", {
                        "symbol": symbol_display, "side": side, "sfp_mode": sig.sfp_mode,
                        "trend_mode": "rd", "reason": "os_none_insufficient_1h_or_error"})
                    return
                aligned = ((os_v == 1) if side == "long" else (os_v == -1))
                if not aligned:
                    # os==0 (range/fresh) or opposite break -> counter-trend for RD; sit out. Log the
                    # RD os so live-vs-backtest RD agreement is checkable from the audit stream.
                    self._audit("sfp_skip_rd_range", {
                        "symbol": symbol_display, "side": side, "sfp_mode": sig.sfp_mode,
                        "trend_mode": "rd", "rd_os": os_v})
                    return
                # log the passing RD os too (audit payload) — live-vs-backtest checkable at each fire
                self._audit("sfp_rd_gate_pass", {
                    "symbol": symbol_display, "side": side, "sfp_mode": sig.sfp_mode,
                    "trend_mode": "rd", "rd_os": os_v, "regime": regime})
            elif tmode == "ps_trail30":
                # DAILY analog of the RD gate: causal one-sided Pagan-Sossounov trend (the causal-macro60
                # winner). entry_ts_ps = the 3m bar AFTER the BOS bar (== the RD/fresh-inst convention);
                # ps_trail30_label_at maps it to its own day bar and returns the PRIOR day's confirmed
                # st_ps_trail(30) state (strictly stale, no same-day peek). 'bull' long / 'bear' short.
                entry_ts_ps = int(bar.ts_ms) + 180_000
                lab = None
                try:
                    lab = ps_trail_trend.ps_trail30_label_at(self.db_url, wire, entry_ts_ps)
                except Exception as e:                       # fail-soft -> sit out, never fire blind
                    log.warning("bitunix_sfp: ps_trail30_label_at failed for %s (sit out): %s", wire, e)
                    lab = None
                if lab is None:
                    self._audit("sfp_skip_ps_no_data", {
                        "symbol": symbol_display, "side": side, "sfp_mode": sig.sfp_mode,
                        "trend_mode": "ps_trail30", "reason": "label_none_warmup_or_error"})
                    return
                aligned = ((lab == "bull") if side == "long" else (lab == "bear"))
                if not aligned:
                    # opposite daily trend (or the coin-vs-side mismatch) -> counter-trend for ps_trail30;
                    # sit out. Log the ps label so live-vs-backtest ps agreement is checkable per fire.
                    self._audit("sfp_skip_ps_counter", {
                        "symbol": symbol_display, "side": side, "sfp_mode": sig.sfp_mode,
                        "trend_mode": "ps_trail30", "ps_label": lab})
                    return
                # log the passing ps label too (audit payload) — live-vs-backtest checkable at each fire
                self._audit("sfp_ps_gate_pass", {
                    "symbol": symbol_display, "side": side, "sfp_mode": sig.sfp_mode,
                    "trend_mode": "ps_trail30", "ps_label": lab, "regime": regime})
            else:
                # ema200 tight gate (default) — BYTE-EQUIVALENT to the prior with_trend path.
                aligned = ((regime == "up") if side == "long"
                           else (regime == "down"))
                if not aligned:
                    self._audit("sfp_skip_counter_trend", {
                        "symbol": symbol_display, "side": side, "regime": regime,
                        "sfp_mode": sig.sfp_mode, "trend_mode": "ema200"})
                    return

        # L3 fresh-institutional gate (armed via config.fresh_inst; BTC-first — needs a 1d cache).
        # Require the swept swing level at a FRESH major institutional level (PDH/PDL/PWH/PWL/
        # PMH/PML/session) within 0.15xATR15. Fail-CLOSED: a coin with no 1d source SKIPS.
        if self.config.fresh_inst:
            c15 = self.bar_caches.get(wire)
            cd1 = self.d1_caches.get(wire)
            bars15 = list(getattr(c15, "bars", []) or [])
            bars1d = list(getattr(cd1, "bars", []) or [])
            if not bars15 or not bars1d:
                self._audit("sfp_skip_no_inst_source", {
                    "symbol": symbol_display, "side": side, "sfp_mode": sig.sfp_mode,
                    "has_15m": bool(bars15), "has_1d": bool(bars1d)})
                return
            level_real = (sig.swept_swing_level if side == "long"
                          else -sig.swept_swing_level)
            entry_ts = int(bar.ts_ms) + 180_000   # entry bar = the 3m AFTER the BOS bar
            try:
                tg = InstLevels(wire, bars15, bars1d).tag(level_real, entry_ts, side)
            except Exception as e:
                self._audit("sfp_skip_inst_error", {
                    "symbol": symbol_display, "side": side, "error": str(e)})
                return
            if not (tg["at_institutional"] and tg["freshness"] == "fresh"):
                self._audit("sfp_skip_not_fresh_inst", {
                    "symbol": symbol_display, "side": side, "sfp_mode": sig.sfp_mode,
                    "at_institutional": tg["at_institutional"], "freshness": tg["freshness"],
                    "tier": tg["tier"], "kinds": tg["kinds"]})
                return

        broker = self.data_exec.brokers.get(DIVISION) if hasattr(self.data_exec, "brokers") else None
        if broker is None:
            self._audit("sfp_skip_no_broker", {"symbol": symbol_display})
            return
        try:
            snap = await broker.snapshot()
            equity = float(getattr(snap, "equity", 0.0) or 0.0)
        except Exception as e:
            # No phantom-equity fallback on a live path — SKIP and surface.
            self._audit("sfp_skip_no_equity", {"symbol": symbol_display, "error": str(e)})
            return
        if equity <= 0:
            self._audit("sfp_skip_no_equity", {"symbol": symbol_display, "equity": equity})
            return

        risk_pct = (self.config.risk_pct_real if sig.sfp_mode == MODE_REAL
                    else self.config.risk_pct_considerable)
        qty = (equity * risk_pct) / r_unit if r_unit > 0 else 0.0
        if qty <= 0:
            self._audit("sfp_skip_nonpositive_qty", {
                "symbol": symbol_display, "qty": qty, "equity": equity,
                "risk_pct": risk_pct, "r_unit": r_unit})
            return

        # One-position-per-coin guard: block a new entry (EITHER side) if ANY live
        # position is open on this symbol. On the one-way venue a short-while-long
        # would REDUCE the long (net), not open a short — so RANGE both-sides can
        # NEVER open simultaneous opposite positions. Subsumes the per-(symbol,side) D4.
        order_side = "buy" if side == "long" else "sell"
        if self._has_open_live_position(symbol_display):
            self._audit("sfp_concurrent_position_blocked", {
                "symbol": symbol_display, "side": order_side, "sfp_mode": sig.sfp_mode,
                "reason": "position_open_this_coin"})
            return

        max_dollar_risk = equity * risk_pct
        order = ProposedOrder(
            strategy=DIVISION,
            symbol=symbol_display,
            side=order_side,
            qty=qty,
            order_type="market",
            rationale=(f"SFP-{sig.sfp_mode} BOS {side} {symbol_display} [{regime}]; "
                       f"swept={sig.swept_low:.4f} lvl={sig.swept_swing_level:.4f} "
                       f"stop={stop_price:.4f} tp2R={tp_price:.4f}"),
            extra={
                "stop_price": stop_price,           # B1 server-side stop reads this
                "take_profit_price": tp_price,
                "tp_r_multiple": self.config.tp_r,
                "rr_ratio": self.config.tp_r,
                "sfp_mode": sig.sfp_mode,
                "swept_low": sig.swept_low,
                "swept_swing_level": sig.swept_swing_level,
                "bos_ref_high": sig.bos_ref_high,
                "bos_bar_ts": sig.bos_bar_ts_ms,
                "entry_reference_price": entry_ref,
                "reduce_only": False,
                "leverage": self.config.leverage,
                "regime_label": regime,            # side-gate stamp (research-log, Piece 4)
                "side_semantic": side,             # "long" | "short"
                "source_signal": (f"sfp_{sig.sfp_mode.lower()}"
                                  + ("_3m_bos" if getattr(sig, "bos_tf", "15m") == "3m" else "")),
                "bos_tf": getattr(sig, "bos_tf", "15m"),
                "max_dollar_risk": max_dollar_risk,
                "expected_gain_if_tp_hit": max_dollar_risk * self.config.tp_r,
            },
        )

        # ── MANDATORY risk gate (single chokepoint) ──
        try:
            account = AccountState(account=DIVISION, equity=equity,
                                   peak_equity=self._tracked_peak_equity(equity))
            strat_state = StrategyState.from_persistence(DIVISION, db_url=self.db_url)
            verdict = self.risk_agent.evaluate(order, account, strat_state, None, None,
                                               db_url=self.db_url)
        except Exception as e:
            self._audit("sfp_skip_risk_error", {"symbol": symbol_display, "error": str(e),
                                                "order_id": order.id})
            return
        # Drawdown-breach (flatten_account) → BLOCK the new entry. v1 does NOT
        # auto-flatten; the open position rides its B1 server-side stop.
        if getattr(verdict, "flatten_account", False):
            order.status = "risk_rejected"
            order.risk_reason = getattr(verdict, "reason", "flatten_account")
            self.logger_agent.log_proposed_order(order)
            self._audit("sfp_drawdown_breach_block", {
                "symbol": symbol_display, "order_id": order.id,
                "reason": order.risk_reason})
            return
        if verdict.verdict == "reject":
            order.status = "risk_rejected"
            order.risk_reason = verdict.reason
            self.logger_agent.log_proposed_order(order)
            self._audit("sfp_risk_rejected", {"symbol": symbol_display,
                                              "order_id": order.id, "reason": verdict.reason})
            return
        if verdict.verdict == "resize" and getattr(verdict, "new_qty", None) is not None:
            order.qty = float(verdict.new_qty)

        await self._place(order, symbol_display, sig)

    def _htf_diagnostics(self, wire: str) -> dict:
        """LOGGED-NOT-ACTED HTF context for the research log: 1H/4H/1D EMA-200 + slope
        + a raw strength magnitude, read OUT-OF-BAND from bitunix_bar_history (fine —
        diagnostic only, NOT the trading regime). Each timeframe is fail-soft and NULL
        when < EMA_PERIOD closes (today: 1H feasible ~333/coin; 4H ~121 and 1D ~62 ->
        NULL until the append-only capture deepens)."""
        out: dict = {}
        for tf, px in (("1h", "htf_1h"), ("4h", "htf_4h"), ("1d", "htf_1d")):
            ema = slope = strength = None
            try:
                with db.connect(self.db_url) as conn:
                    rows = conn.execute(
                        "SELECT close FROM bitunix_bar_history WHERE symbol=? AND "
                        "timeframe=? AND close IS NOT NULL ORDER BY ts_ms DESC LIMIT 300",
                        (wire, tf)).fetchall()
                closes = [float(r[0]) for r in reversed(rows)]
                if len(closes) >= REGIME_EMA_PERIOD:
                    em = _regime_ema200(closes)
                    ema = em[-1]
                    if len(em) > 10 and em[-11]:
                        slope = (em[-1] - em[-11]) / em[-11]
                        dist = (closes[-1] - em[-1]) / em[-1] if em[-1] else 0.0
                        strength = abs(slope) + abs(dist)
            except Exception as e:                          # fail-soft per timeframe
                log.warning("bitunix_sfp htf-diag %s %s failed: %s", wire, tf, e)
            out[f"{px}_ema200"], out[f"{px}_slope"], out[f"{px}_strength"] = ema, slope, strength
        return out

    def _research_log_entry(self, order: ProposedOrder, fill: Any, symbol_display: str) -> None:
        """Fail-soft ENTRY stamp into the isolated research catalog. Belt-and-suspenders
        (research_log.log_entry is itself fail-soft) — a logging error NEVER reaches the
        trade path. Real swept/bos levels are un-reflected for shorts (M2=0: real = -x)."""
        try:
            import json
            e = order.extra or {}
            side = e.get("side_semantic", "long")
            swept = e.get("swept_low")
            bosref = e.get("bos_ref_high")
            wire = to_wire_format(symbol_display)
            row = {
                "order_id": order.id, "division": DIVISION, "coin": symbol_display,
                "side": side, "regime_label": e.get("regime_label"),
                "regime_engine": REGIME_ENGINE,
                "rr_target": e.get("tp_r_multiple", self.config.tp_r),
                "sfp_mode": e.get("sfp_mode"), "bos_tf": e.get("bos_tf"),
                "entry_ts": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
                "entry_px": e.get("entry_reference_price"),
                "stop_px": e.get("stop_price"), "target_px": e.get("take_profit_price"),
                "sfp_sweep_px": (swept if side == "long"
                                 else (-swept if swept is not None else None)),
                "bos_confirm_px": (bosref if side == "long"
                                   else (-bosref if bosref is not None else None)),
                "broker_order_id": getattr(fill, "order_id", None),
                "extra_json": json.dumps({"swept_swing_level": e.get("swept_swing_level"),
                                          "leverage": e.get("leverage")}),
            }
            row.update(self._htf_diagnostics(wire))
            research_log.log_entry(self.db_url, row)
        except Exception as ex:                             # never into the trade path
            log.warning("bitunix_sfp research-log entry failed (order_id=%s): %s",
                        getattr(order, "id", None), ex)

    async def _place(self, order: ProposedOrder, symbol_display: str, sig: SfpEntrySignal) -> None:
        """Slim placement writer. Paper → would_have_placed (never touches the
        broker). Live → data_exec.place + Path-C live row.

        Live placement requires ALL of: execution_mode:live, the runtime
        auto_execute kill switch ON, AND the registered broker actually being
        live (``paper=False``). The last clause prevents a half-flip
        (execution_mode:live but the slug absent from ``--live-divisions`` → a
        PaperExecutionBroker) from writing a mislabeled-live record."""
        broker = self.data_exec.brokers.get(DIVISION) if hasattr(self.data_exec, "brokers") else None
        broker_is_live = broker is not None and not getattr(broker, "paper", True)
        cfg_live = (self.config.execution_mode == "live") and self._yaml_auto_execute()
        if cfg_live and not broker_is_live:
            log.warning("bitunix_sfp: execution_mode=live + auto_execute but the "
                        "broker is paper/missing (slug not in --live-divisions?) — "
                        "routing PAPER to avoid a mislabeled-live record")
        is_live = cfg_live and broker_is_live
        # Mode-B watch-only symbols forward-track in PAPER (never live) regardless
        # of execution_mode — the detector runs and writes a paper record, but no
        # real order is placed. Default arm is "trading" → a no-op for armed symbols.
        if is_live and self._symbol_arm.get(to_wire_format(symbol_display)) == "watch":
            is_live = False
            self._audit("sfp_signal_watch_only", {
                "symbol": symbol_display, "sfp_mode": sig.sfp_mode,
                "order_id": order.id, "reason": "arm=watch_forward_track_paper"})
        intent = {
            "symbol": symbol_display, "side": order.side, "qty": order.qty,
            "sfp_mode": sig.sfp_mode, "order_id": order.id,
            "stop_price": order.extra.get("stop_price"),
            "take_profit_price": order.extra.get("take_profit_price"),
        }
        if not is_live:
            order.status = "would_have_placed"
            self.logger_agent.log_proposed_order(order)
            self._audit("would_have_placed", intent)
            self._write_record(order, live=False, fill=None)
            return

        intent_live = dict(intent)
        intent_live["execution_mode"] = "live"
        self._audit("live_order_placed", intent_live)   # write-ahead intent
        self.logger_agent.log_proposed_order(order)
        try:
            fill = await self.data_exec.place(order, division=DIVISION)
        except Exception as e:
            order.status = "live_order_rejected"
            self._audit("live_order_rejected", {**intent_live, "error": str(e),
                                                "error_type": type(e).__name__})
            return
        self._write_record(order, live=True, fill=fill)
        self._research_log_entry(order, fill, symbol_display)   # isolated catalog (fail-soft)
        # ── Post-fill TP placement ──────────────────────────────────────────
        # The entry + atomic B1 stop are now live. place_order does NOT submit a
        # TP, so rest the real /tpsl/ reduce-only TP leg here. Fail-soft + LOUD:
        # any failure leaves the entry + B1 stop intact (downside capped at the
        # structural stop) and alerts — NEVER silent, NEVER unwinds the entry.
        await self._place_tp_leg(order, symbol_display)

    def _write_record(self, order: ProposedOrder, *, live: bool, fill: Any) -> None:
        try:
            record = PaperTradeRecord.from_order(
                order, strategy=DIVISION, division=DIVISION,
                max_hold_seconds=self.config.max_hold_seconds,
            )
            record.extra = dict(order.extra)
            if live:
                record.extra["execution_mode"] = "live"
                if fill is not None:
                    record.extra["broker_order_id"] = getattr(fill, "order_id", None)
                    record.extra["entry_fee_usd"] = float(getattr(fill, "fee", 0.0) or 0.0)
                    # ref-vs-fill (2026-07-07): persist the ACTUAL entry fill VWAP
                    # (observed by place_order) so R/P&L book from the real fill,
                    # not the signal reference. The reconciler's _resolve_entry_price
                    # already prefers extra['actual_entry_fill_price']; the /sfp
                    # cockpit uses it for the entry line + R. Reference stays the
                    # fallback for paper rows / any fill without a price.
                    _fp = getattr(fill, "price", None)
                    try:
                        if _fp is not None and float(_fp) > 0:
                            record.extra["actual_entry_fill_price"] = float(_fp)
                    except (TypeError, ValueError):
                        pass
            db.insert_paper_trade_record(record.to_db_row(), db_url=self.db_url)
        except Exception as e:
            log.warning("bitunix_sfp: paper_trade_record write failed "
                        "(live=%s; broker may have placed): %s", live, e)

    # ------------------------------------------------------------------ #
    # Post-fill TP leg (the SFP edge depends on the 2R TP firing live)
    # ------------------------------------------------------------------ #
    async def _place_tp_leg(self, order: ProposedOrder, symbol_display: str) -> None:
        """Rest ONE full-qty native /tpsl/ reduce-only TP leg after the live entry
        fills (OCO with the atomic B1 stop, which is UNCHANGED). Fail-soft + LOUD
        on EVERY failure path: leave the position SL-only (downside capped at the
        structural stop) and alert (audit + telegram) — never silent, and never
        unwind the filled entry. NO retry loop (place_tpsl_order is idempotency-
        aware at the venue + the concurrent-position guard blocks re-entry)."""
        try:
            broker = (self.data_exec.brokers.get(DIVISION)
                      if hasattr(self.data_exec, "brokers") else None)
            tp_price = float(order.extra.get("take_profit_price") or 0.0)
            if broker is None or not hasattr(broker, "place_tpsl_order") or tp_price <= 0.0:
                await self._tp_alert("sfp_tp_unsupported", order,
                    f"no /tpsl/ broker or tp_price={tp_price} — position is SL-only",
                    {"tp_price": tp_price})
                return

            position_id, pos_qty = await self._resolve_position(broker, order)
            if not position_id:
                await self._tp_alert("sfp_tp_unresolved_position", order,
                    "venue positionId unresolved after fill — SL-only (B1 guards)",
                    {"requested_qty": float(order.qty)})
                return

            # Single full-qty leg; reuse build_bracket_legs for the 0.0003 BTC
            # min-leg floor + the 0-legs->SL-only branch (single source of truth).
            from trading_corp.agents.divisions.bitunix_bracket import build_bracket_legs
            qty = float(pos_qty or order.qty)
            legs, note = build_bracket_legs(
                qty, [{"leg": "tp1", "price": tp_price, "fraction": 1.0}])
            if not legs:
                await self._tp_alert("sfp_tp_skipped_submin", order,
                    f"entry qty {qty} below min leg — SL-only ({note})",
                    {"qty": qty, "note": note})
                return
            leg = legs[0]

            from trading_corp.brokers.bitunix_exceptions import BitunixUntrackedTpslOrder
            try:
                tp_order_id = await broker.place_tpsl_order(
                    symbol=order.symbol, position_id=position_id,
                    tp_price=tp_price, tp_qty=leg.qty,
                )
            except BitunixUntrackedTpslOrder as e:
                await self._tp_alert("sfp_tp_untracked", order,
                    "TP leg POST reached the venue but its id was uncaptured — the "
                    "leg may be RESTING UNTRACKED; RECONCILE. B1 stop still guards.",
                    {"position_id": position_id, "tp_price": tp_price,
                     "tp_qty": leg.qty, "error": str(e), "error_type": type(e).__name__})
                return
            except Exception as e:
                await self._tp_alert("sfp_tp_place_failed", order,
                    f"TP leg placement FAILED — SL-only (B1 stop guards): {e}",
                    {"position_id": position_id, "tp_price": tp_price,
                     "tp_qty": leg.qty, "error": str(e), "error_type": type(e).__name__})
                return

            if not tp_order_id:
                # Empty id WITHOUT an exception = idempotent duplicate (leg already
                # resting from a prior attempt). Not a new order; don't double-count.
                log.warning("bitunix_sfp: TP leg returned no id (idempotent "
                            "duplicate / already resting) order_id=%s", order.id)

            self._persist_tp(order, position_id, tp_price, leg.qty, tp_order_id or "")
            self._audit("sfp_bracket_placed", {
                "order_id": order.id, "symbol": symbol_display,
                "tp_order_id": tp_order_id or "", "tp_price": tp_price,
                "tp_qty": leg.qty, "position_id": position_id, "degrade_note": note})
        except Exception as e:
            # Belt-and-suspenders: the TP path must NEVER crash the loop or unwind
            # the (already filled) entry. Any uncaught error -> loud alert, entry intact.
            try:
                await self._tp_alert("sfp_tp_unexpected_error", order,
                    f"unexpected error placing TP — SL-only (B1 guards): {e}",
                    {"error": str(e), "error_type": type(e).__name__})
            except Exception:
                log.exception("bitunix_sfp: TP placement AND its alert both failed "
                              "(entry intact, B1 guards) order_id=%s",
                              getattr(order, "id", None))

    async def _resolve_position(self, broker: Any, order: ProposedOrder
                                ) -> tuple[str | None, float | None]:
        """Match the just-opened venue position by wire-symbol + side; return
        (positionId, qty). (None, None) if unresolved — caller leaves SL-only."""
        try:
            order_wire = to_wire_format(order.symbol or "")
        except Exception:
            order_wire = (order.symbol or "").upper()
        entry_side = (order.side or "").lower()
        try:
            positions = await broker.get_pending_positions()
        except Exception as e:
            log.warning("bitunix_sfp: get_pending_positions failed: %s", e)
            return None, None
        for p in positions or []:
            try:
                p_wire = to_wire_format(getattr(p, "symbol", "") or "")
            except Exception:
                p_wire = (getattr(p, "symbol", "") or "").upper()
            p_side_raw = str((getattr(p, "extra", None) or {}).get("side", "")).upper()
            p_side = "buy" if p_side_raw in ("LONG", "BUY") else "sell"
            if p_wire == order_wire and p_side == entry_side:
                pid = (getattr(p, "extra", None) or {}).get("positionId")
                if pid:
                    return str(pid), abs(float(getattr(p, "qty", 0.0) or 0.0))
        return None, None

    def _persist_tp(self, order: ProposedOrder, position_id: str,
                    tp_price: float, tp_qty: float, tp_order_id: str) -> None:
        """Inline UPDATE of the entry row's extra_json with the bracket TP state
        (mirrors the futures observer's inline db.connect UPDATE; no db.py helper).
        The row already exists (written at entry) so this MUST be an UPDATE."""
        import json
        try:
            with db.connect(self.db_url) as conn:
                row = conn.execute(
                    "SELECT extra_json FROM paper_trade_record WHERE order_id=?",
                    (order.id,),
                ).fetchone()
                extra: dict = {}
                if row and row["extra_json"]:
                    try:
                        extra = json.loads(row["extra_json"])
                    except (TypeError, ValueError):
                        extra = {}
                extra["bracket_tp_order_id"] = tp_order_id
                extra["bracket_position_id"] = position_id
                extra["bracket_tp_qty"] = tp_qty
                extra["bracket_tp_price"] = tp_price
                conn.execute(
                    "UPDATE paper_trade_record SET extra_json=? WHERE order_id=?",
                    (json.dumps(extra, default=str), order.id),
                )
        except Exception as e:
            log.error("bitunix_sfp: TP bracket-state persist failed "
                      "(leg may be placed at venue): %s", e)

    async def _tp_alert(self, kind: str, order: ProposedOrder, text: str,
                        payload: dict) -> None:
        """LOUD, never-silent alert for a TP-placement issue: audit_event (dashboard)
        + log.error + best-effort Telegram via data_exec.safety_notifier (guarded,
        never raises). The filled entry + B1 stop are intact regardless."""
        full = {"order_id": getattr(order, "id", None),
                "symbol": getattr(order, "symbol", None), **(payload or {})}
        self._audit(kind, full)
        log.error("bitunix_sfp: %s — %s (order_id=%s)",
                  kind, text, getattr(order, "id", None))
        notifier = getattr(self.data_exec, "safety_notifier", None)
        if notifier is not None:
            try:
                await notifier.push(
                    f"⚠ SFP TP NOT PLACED ({kind})\n{text}\n"
                    f"order_id={getattr(order, 'id', None)}",
                    audit_path="bitunix_sfp", audit_context=full,
                )
            except Exception as e:
                log.warning("bitunix_sfp: safety_notifier.push raised: %s", e)

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    def _has_open_live_position(self, symbol_display: str) -> bool:
        """True if this division holds ANY open live position on ``symbol`` (either
        side). One-position-per-coin: on the one-way venue an opposite-side entry
        would net against the open position, so RANGE both-sides must not stack."""
        return self._has_open_live_same_side(symbol_display, None)

    def _has_open_live_same_side(self, symbol_display: str, side: str | None) -> bool:
        """True if this division already holds an OPEN live position on ``symbol``
        matching ``side`` (``side=None`` matches ANY side). Keyed on the row's
        symbol (+ side unless None)."""
        try:
            with db.connect(self.db_url) as conn:
                rows = conn.execute(
                    "SELECT symbol, side, extra_json FROM paper_trade_record "
                    "WHERE division = ? AND result IS NULL AND extra_json IS NOT NULL",
                    (DIVISION,),
                ).fetchall()
        except Exception as e:
            # Fail SAFE: if we cannot verify, assume a position MAY exist and
            # block (never stack blind).
            log.warning("bitunix_sfp: concurrent-guard read failed: %s", e)
            return True
        import json
        for r in rows:
            try:
                extra = json.loads(r["extra_json"])
            except (TypeError, ValueError):
                continue
            if extra.get("execution_mode") != "live":
                continue
            if str(r["symbol"]) == symbol_display and (side is None or str(r["side"]) == side):
                return True
        return False

    def _tracked_peak_equity(self, current_equity: float) -> float:
        """Account high-water-mark for the drawdown breaker (per-division key).
        FAIL-SAFE: read failure → current (peak==current ⇒ drawdown 0 ⇒ no false
        flatten), mirroring the futures observer's helper."""
        try:
            loaded = db.load_agent_state(DIVISION, PEAK_EQUITY_AGENT_STATE_KEY,
                                         db_url=self.db_url)
        except Exception as e:
            log.warning("bitunix_sfp: peak-equity read failed: %s", e)
            return current_equity
        stored_peak = 0.0
        if loaded is not None:
            value, _updated = loaded
            try:
                stored_peak = (float(value.get("peak", 0.0))
                               if isinstance(value, dict) else float(value))
            except (TypeError, ValueError):
                stored_peak = 0.0
        peak = max(stored_peak, current_equity)
        if peak > stored_peak:
            try:
                db.set_agent_state(DIVISION, PEAK_EQUITY_AGENT_STATE_KEY,
                                   {"peak": peak}, db_url=self.db_url)
            except Exception as e:
                log.warning("bitunix_sfp: peak-equity write failed %.2f→%.2f: %s",
                            stored_peak, peak, e)
        return peak

    def _yaml_auto_execute(self) -> bool:
        """Fresh-read ``bitunix_sfp.auto_execute`` (the runtime kill switch).
        Fail-CLOSED to False on any error."""
        try:
            import yaml
            with open(self._strategies_yaml_path, encoding="utf-8") as f:
                raw = yaml.safe_load(f) or {}
            return bool((raw.get(DIVISION) or {}).get("auto_execute", False))
        except Exception as e:
            log.warning("bitunix_sfp: auto_execute read failed (fail-closed): %s", e)
            return False

    def _yaml_side(self) -> str:
        """Fresh-read ``bitunix_sfp.side`` (the operator side kill-switch:
        ``regime`` | ``long`` | ``short``). HOT — flipping it in strategies.yaml applies
        WITHOUT a restart (mirrors _yaml_auto_execute). Fail-SAFE to 'long' (shorts
        suppressed, longs keep collecting) on any read/parse error or unknown value —
        never leaves shorts on under uncertainty. Always returns one of the three."""
        try:
            import yaml
            with open(self._strategies_yaml_path, encoding="utf-8") as f:
                raw = yaml.safe_load(f) or {}
            s = str((raw.get(DIVISION) or {}).get("side", "long")).lower()
            return s if s in ("regime", "long", "short") else "long"
        except Exception as e:
            log.warning("bitunix_sfp: side read failed (fail-safe to long): %s", e)
            return "long"

    def _yaml_trend_mode(self, wire: str) -> str:
        """Fresh-read ``bitunix_sfp.trend_mode[<wire>]`` — the per-coin tight with-trend SOURCE
        ('ema200' | 'rd' | 'ps_trail30'). HOT: flipping it in strategies.yaml applies WITHOUT a restart
        (mirrors _yaml_side). Keys may be display or wire form; normalized to wire. Fail-SAFE to 'ema200'
        (the leaking-but-safe live gate — never silently swaps to another source under uncertainty) on
        any read/parse error, unknown value, or missing key; falls back to the boot config default."""
        try:
            import yaml
            with open(self._strategies_yaml_path, encoding="utf-8") as f:
                raw = yaml.safe_load(f) or {}
            tm = (raw.get(DIVISION) or {}).get("trend_mode") or {}
            norm: dict[str, str] = {}
            for disp, val in tm.items():
                try:
                    w = to_wire_format(str(disp))
                except Exception:
                    w = str(disp)
                norm[w] = str(val).lower()
            mode = norm.get(wire, self.config.trend_mode_for(wire))
            return mode if mode in ("ema200", "rd", "ps_trail30") else "ema200"
        except Exception as e:
            log.warning("bitunix_sfp: trend_mode read failed for %s (fail-safe to ema200): %s",
                        wire, e)
            return self.config.trend_mode_for(wire)

    # ------------------------------------------------------------------ #
    # OBSERVE-ONLY emit: watch-state + heartbeat (dashboard Tier-B).
    # NONE of these read into or alter any trade decision; all fail-soft.
    # ------------------------------------------------------------------ #
    def _ensure_watch_schema(self) -> None:
        """Idempotently create sfp_watch_state (defensive; the gated migration
        also creates it). Fail-soft — a schema error must not break the observer."""
        try:
            with db.connect(self.db_url) as conn:
                conn.execute(_SFP_WATCH_DDL)
                conn.execute(_SFP_WATCH_IX1)
                conn.execute(_SFP_WATCH_IX2)
        except Exception as e:
            log.warning("bitunix_sfp: sfp_watch_state ensure-schema failed "
                        "(emit will no-op until present): %s", e)

    def _write_heartbeat(self) -> None:
        """One cheap agent_state write per loop cycle (honest dashboard heartbeat).
        Fail-soft — observe-only."""
        try:
            db.set_agent_state(DIVISION, LOOP_HEARTBEAT_AGENT_STATE_KEY,
                               {"ts": datetime.now(timezone.utc).isoformat()},
                               db_url=self.db_url)
        except Exception as e:
            log.warning("bitunix_sfp: heartbeat write failed (observe-only): %s", e)

    def _emit_watch_transitions(self, wire: str, transitions: list,
                                *, recent_only: bool = False) -> None:
        """OBSERVE-ONLY: UPSERT lifecycle transitions into sfp_watch_state, keyed by
        watch_id = f"{symbol}:{mode}:{fired_bar_ts_ms}". MUST NOT raise into the
        trading loop — any failure is logged and swallowed. ``recent_only``
        (warm-start, decision b) skips transitions whose arming bar is older than
        24h so a restart does not flood ancient history."""
        if not transitions:
            return
        try:
            import json
            now_iso = datetime.now(timezone.utc).isoformat()
            cutoff_ms = None
            if recent_only:
                cutoff_ms = int(
                    (datetime.now(timezone.utc).timestamp() - _WATCH_RECENT_WINDOW_SEC) * 1000)
            with db.connect(self.db_url) as conn:
                for t in transitions:
                    fired_ms = int(getattr(t, "fired_bar_ts_ms", 0) or 0)
                    if cutoff_ms is not None and fired_ms < cutoff_ms:
                        continue
                    watch_id = f"{wire}:{t.mode}:{fired_ms}"
                    is_armed = (t.status == "ARMED")
                    terminal_bar = None if is_armed else int(t.status_bar_ts_ms)
                    extra = None
                    if t.status == "CONFIRMED":
                        extra = json.dumps({"bos_ref_high": t.bos_ref_high,
                                            "entry_bar_index": t.entry_bar_index})
                    bos = (float(t.bos_watch_level)
                           if t.bos_watch_level is not None else None)
                    conn.execute(_SFP_WATCH_UPSERT, (
                        watch_id, fired_ms, wire, t.mode,
                        float(t.swept_level), float(t.swept_wick), bos,
                        t.status, now_iso, now_iso, terminal_bar, extra,
                    ))
        except Exception as e:
            log.warning("bitunix_sfp: watch-state emit failed "
                        "(observe-only, trading unaffected): %s", e)

    def _audit(self, kind: str, payload: dict) -> None:
        payload = {**payload, "strategy": DIVISION, "division": DIVISION}
        try:
            self.logger_agent.log_event(actor=DIVISION, kind=kind, payload=payload)
        except Exception as e:
            log.warning("bitunix_sfp: audit %s failed: %s", kind, e)
