"""MACE strategy — PURE decision logic (plan § Behavior specifications).

No I/O: no broker, no DB, no yaml re-reads, no clock reads. Everything is a
function of injected neutral inputs (MaceConfig, domain types, ChainView,
IvrReading, RungState, economic_event dicts). The manager/execution layer
(Phase 3) fetches data, calls these functions, and performs the side effects.

Contents:
  - Entry pipeline (10 filters, first-failure-wins skip reason)
  - Condor build (expiry / delta strikes / UNIVERSAL wing-listing / FXI
    fallback width / risk band) + sizing + reserve
  - Overflow routing (T6 as ruled 2026-08-09) — inert at launch (universe=[SPY])
  - Management precedence (stop > time > exdiv)
  - Breaker math (alert-only; enforcement branches exist, ship 'off')

Marketability is NOT decided here (that is the execution ladder). This module
only decides WHICH condor, WHAT size, and PASS/SKIP.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import date, datetime, time as dtime, timedelta
from typing import Callable, Mapping, Sequence

from trading_corp.mace.config import MaceConfig, SymbolConfig
from trading_corp.mace.domain import (
    EXIT_EXDIV, EXIT_PT, EXIT_STOP, EXIT_TIME,
    IVR_OK, IVR_STALE, IVR_UNAVAILABLE,
    SKIP_BLACKOUT, SKIP_BUDGET, SKIP_CAPACITY, SKIP_COOLDOWN, SKIP_CREDIT_FLOOR,
    SKIP_IVR, SKIP_NO_DELTA_STRIKE, SKIP_NO_EQUITY_SNAPSHOT, SKIP_NO_EXPIRY,
    SKIP_NO_WING, SKIP_RESERVE, SKIP_RISK_BAND, SKIP_RISK_REJECT,
    SKIP_STRIKE_COLLISION, SKIP_WEEKLY_BUDGET,
    BreakerState, CondorSpec, EvalResult, OptionQuote, RungState, iso_week,
)

# Rung statuses that occupy a capacity slot (submitting/open/closing are live).
_LIVE_STATUSES = ("submitting", "open", "closing")


# ── neutral chain input ──────────────────────────────────────────────────

def _k(strike: float) -> float:
    return round(float(strike), 4)


@dataclass(frozen=True)
class ChainView:
    """Neutral per-symbol option-chain snapshot at eval time. The broker fetches
    it; strategy never calls the broker. `quotes` is keyed by
    (expiry, opt_type, rounded_strike)."""

    symbol: str
    spot: float | None
    expiries: tuple[date, ...]
    quotes: Mapping[tuple[date, str, float], OptionQuote]

    def listed(self, expiry: date, opt_type: str, strike: float) -> bool:
        return (expiry, opt_type, _k(strike)) in self.quotes

    def get(self, expiry: date, opt_type: str, strike: float) -> OptionQuote | None:
        return self.quotes.get((expiry, opt_type, _k(strike)))

    def strikes(self, expiry: date, opt_type: str) -> list[float]:
        return sorted(k for (e, t, k) in self.quotes if e == expiry and t == opt_type)


# ── shared entry context ─────────────────────────────────────────────────

@dataclass(frozen=True)
class EntryContext:
    """Everything the entry pipeline needs, injected. `rungs` is ALL rungs
    (every symbol/status) — per-symbol aggregates are derived here (pure).
    `events` are economic_event dicts (event_type/symbol_scope/event_date)."""

    session_date: date
    equity: float | None
    rungs: Sequence[RungState]
    events: Sequence[Mapping]
    ivr: Mapping[str, "object"]                 # symbol -> IvrReading
    chains: Mapping[str, ChainView]
    next_session_date: date | None = None
    risk_gate: Callable[[str, CondorSpec, int], bool] | None = None
    # Free/available buying power (the "margin available to invest" figure) — the
    # reserve/deployment-cap sizing basis when cfg.sizing.deployment_basis ==
    # 'available_buying_power'. None => not captured (gate falls back to equity).
    # Per-rung contract sizing (size_contracts) ALSO sizes on this now (2026-09-09:
    # base = SIZING_BASE_BP_PCT * this, via deployment_base) -- was ctx.equity.
    available_buying_power: float | None = None
    # Open max_risk at THIS eval's start (Option A, 2026-08-25). The available-BP
    # base is already net of collateral for positions open at the 15:40 snapshot AND
    # is snapshotted once per eval, so the reserve gate counts only rungs placed
    # WITHIN THIS EVAL = sum_open_max_risk(now) - this baseline. None on a direct
    # call (= a fresh eval, nothing placed yet -> within-eval committed is 0). The
    # manager sets it in build_entry_context; it survives the per-placement
    # dataclasses.replace(rungs=...). Unused by the legacy 'equity' (total-book) basis.
    eval_start_open_max_risk: float | None = None

    def next_session(self) -> date:
        return self.next_session_date or next_session(self.session_date)


# ── date helpers (business-day, holidays NOT modeled — safe over-count) ───

def next_session(d: date) -> date:
    nxt = d + timedelta(days=1)
    while nxt.weekday() >= 5:
        nxt += timedelta(days=1)
    return nxt


def business_sessions_between(start: date, end: date) -> int:
    """Mon-Fri days strictly after `start` up to and including `end`. 0 if
    end <= start. Mirrors data.ex_dividend_calendar semantics."""
    if end <= start:
        return 0
    n, cur = 0, start + timedelta(days=1)
    while cur <= end:
        if cur.weekday() < 5:
            n += 1
        cur += timedelta(days=1)
    return n


def _exit_date(rung: RungState):
    from trading_corp.utils.time import to_et
    et = to_et(rung.exit_ts)
    return et.date() if et else None


# ── per-symbol rung aggregates (derived, no marker tables) ───────────────

def open_rung_count(rungs: Sequence[RungState], symbol: str) -> int:
    return sum(1 for r in rungs if r.symbol == symbol and r.status in _LIVE_STATUSES)


def net_option_positions(rungs: Sequence[RungState], symbol: str) -> dict:
    """(expiry, opt_type, rounded_strike) -> NET signed contracts (long +, short -)
    across this symbol's LIVE rungs. The collision guard reads this: opening a leg
    OPPOSITE an existing net (buy where net<0, sell where net>0) is what Robinhood
    atomically rejects (buy-to-open you already hold short / sell-to-open you already
    hold long). Same-direction or flat strikes are fine (they just add contracts)."""
    net: dict = {}
    for r in rungs:
        if r.symbol != symbol or r.status not in _LIVE_STATUSES or r.spec is None:
            continue
        c = r.contracts or 0
        s = r.spec
        for opt_type, strike, sign in (
            ("put", s.short_put, -1), ("put", s.long_put, +1),
            ("call", s.short_call, -1), ("call", s.long_call, +1),
        ):
            key = (s.expiry, opt_type, _k(strike))
            net[key] = net.get(key, 0) + sign * c
    return net


def entries_this_week(rungs: Sequence[RungState], symbol: str, session_date: date) -> int:
    wk = iso_week(session_date)
    return sum(1 for r in rungs if r.symbol == symbol and r.entry_iso_week == wk)


def closures_before_today_this_week(
    rungs: Sequence[RungState], symbol: str, session_date: date,
) -> int:
    """Rungs for `symbol` that CLOSED earlier this ISO week (exit date < today).
    Refill: a close frees weekly budget from the NEXT session."""
    wk = iso_week(session_date)
    n = 0
    for r in rungs:
        if r.symbol != symbol or r.status != "closed":
            continue
        ed = _exit_date(r)
        if ed is not None and ed < session_date and iso_week(ed) == wk:
            n += 1
    return n


def sessions_since_last_stop(
    rungs: Sequence[RungState], symbol: str, session_date: date,
) -> int | None:
    """Business-day age of the most recent STOP exit for `symbol`, or None."""
    dates = [
        _exit_date(r) for r in rungs
        if r.symbol == symbol and r.exit_reason == EXIT_STOP
    ]
    dates = [d for d in dates if d is not None and d <= session_date]
    if not dates:
        return None
    return business_sessions_between(max(dates), session_date)


def sum_open_max_risk(rungs: Sequence[RungState]) -> float:
    return sum(float(r.max_risk_usd or 0.0)
               for r in rungs if r.status in _LIVE_STATUSES)


def _uses_available_bp(cfg: "MaceConfig", ctx: "EntryContext") -> bool:
    """True when the reserve gate should run in the Option-A available-BP model:
    the configured basis is available_buying_power AND a usable value is present.
    When False (legacy 'equity' basis, OR available_buying_power configured but the
    broker didn't expose it) the gate degrades to the equity total-book model —
    base AND committed-risk are then chosen together, never mixed."""
    return (cfg.sizing.deployment_basis == "available_buying_power"
            and ctx.available_buying_power is not None
            and ctx.available_buying_power > 0)


def deployment_base(cfg: "MaceConfig", ctx: "EntryContext") -> float:
    """The reserve/deployment-cap DENOMINATOR (strategy filter 9):
      available_buying_power (present) -> ctx.available_buying_power — free BP after
          existing option collateral (the "margin available to invest" figure), so
          the cap never authorizes a rung the account can't actually margin.
      else                              -> ctx.equity — the settled-cash basis
          (legacy 'equity' basis, or a safe fall-back when available BP is absent).
    Per-rung contract sizing (size_contracts) now sizes on this SAME base too
    (2026-09-09: base = SIZING_BASE_BP_PCT * this), so sizing and the reserve cap
    share one denominator (falling back to ctx.equity together when BP is absent)."""
    if _uses_available_bp(cfg, ctx):
        return float(ctx.available_buying_power)
    return float(ctx.equity or 0.0)


def reserve_committed(cfg: "MaceConfig", ctx: "EntryContext") -> float:
    """Risk that counts against the deployment cap, per basis (Option A ruling,
    Jack 2026-08-25):
      available_buying_power (present): ONLY rungs placed WITHIN THIS EVAL. The base
          is already net of collateral for positions open at the 15:40 snapshot, so
          re-subtracting pre-existing open rungs would DOUBLE-COUNT. But the base is
          snapshotted once per eval, so a single eval's sequential placements are not
          yet reflected -> subtract them (= sum_open_max_risk(now) - eval-start
          baseline) so one eval can't over-commit against the stale snapshot. On a
          direct/first-pass call (eval_start_open_max_risk is None) nothing has been
          placed yet -> 0.
      equity (legacy / available-BP fall-back): ALL open rungs — the total-book cap
          on gross account value (pre-existing rungs consume it)."""
    total_open = sum_open_max_risk(ctx.rungs)
    if _uses_available_bp(cfg, ctx):
        baseline = ctx.eval_start_open_max_risk
        if baseline is None:                      # direct call = fresh eval start
            baseline = total_open
        return max(0.0, total_open - float(baseline))
    return total_open


def day_realized(rungs: Sequence[RungState], session_date: date) -> float:
    """Realized P&L from rungs that CLOSED today (derived; no marker table)."""
    return sum(float(r.realized_pnl or 0.0) for r in rungs
               if r.status == "closed" and _exit_date(r) == session_date)


def week_realized(rungs: Sequence[RungState], session_date: date) -> float:
    """Realized P&L from rungs that CLOSED this ISO week (derived)."""
    wk = iso_week(session_date)
    total = 0.0
    for r in rungs:
        if r.status != "closed":
            continue
        ed = _exit_date(r)
        if ed is not None and iso_week(ed) == wk:
            total += float(r.realized_pnl or 0.0)
    return total


def is_blackout(
    symbol: str, symbol_cfg: SymbolConfig, events: Sequence[Mapping],
    session_date: date, next_session_date: date,
) -> bool:
    """True iff any economic_event with a type in the symbol's blackout list,
    scope in {ALL, symbol}, falls on today OR the next trading session."""
    if not symbol_cfg.blackout_event_types:
        return False
    window = {session_date.isoformat(), next_session_date.isoformat()}
    types = set(symbol_cfg.blackout_event_types)
    for e in events:
        if str(e.get("event_type", "")).upper() not in types:
            continue
        scope = str(e.get("symbol_scope", "")).upper()
        if scope not in ("ALL", symbol.upper()):
            continue
        if str(e.get("event_date", "")) in window:
            return True
    return False


# ── condor build ─────────────────────────────────────────────────────────

def choose_expiry(chain: ChainView, dte_min: int, dte_max: int, session_date: date):
    """Highest DTE within [dte_min, dte_max] (prefer more time). None if empty."""
    best = None
    for e in chain.expiries:
        dte = (e - session_date).days
        if dte_min <= dte <= dte_max:
            if best is None or dte > (best - session_date).days:
                best = e
    return best


def select_short_strike(chain: ChainView, expiry: date, opt_type: str,
                        target: float, band: tuple[float, float]):
    """Listed strike whose |delta| is nearest `target` within `band`. Returns
    (strike, OptionQuote) or None. Requires a delta on the quote."""
    lo, hi = band
    best = None
    best_dist = None
    for k in chain.strikes(expiry, opt_type):
        q = chain.get(expiry, opt_type, k)
        if q is None or q.delta is None:
            continue
        ad = abs(float(q.delta))
        if ad < lo or ad > hi:
            continue
        dist = abs(ad - target)
        if best_dist is None or dist < best_dist:
            best, best_dist = (k, q), dist
    return best


@dataclass(frozen=True)
class BuildResult:
    spec: CondorSpec | None = None
    credit_mid: float | None = None
    width: float | None = None
    skip_reason: str | None = None
    detail: str = ""


# ── skip observability (diagnostic only — NEVER feeds selection/decisions) ──
# These annotate the detail string on a build skip so audit_event alone tells
# why (spot, expiry, nearest-delta candidate, wing strikes + reject reason).
# They read the chain; they do not change what build_condor decides.

def _fmt_spot(spot) -> str:
    return f"{spot:.2f}" if spot is not None else "none"


def _nearest_delta_strike(chain: "ChainView", expiry, opt_type: str, target: float):
    """(strike, delta) whose |delta| is closest to `target` among listed strikes
    carrying a delta; None if the side is empty. Diagnostic ONLY."""
    best = None
    best_dist = None
    for k in chain.strikes(expiry, opt_type):
        q = chain.get(expiry, opt_type, k)
        if q is None or q.delta is None:
            continue
        dist = abs(abs(float(q.delta)) - target)
        if best_dist is None or dist < best_dist:
            best, best_dist = (k, float(q.delta)), dist
    return best


def _cand(c) -> str:
    return f"{c[0]:g}@{c[1]:.2f}" if c else "none"


def _wing_leg_diag(chain: "ChainView", expiry, opt_type: str, strike: float,
                   band: float, spot) -> str:
    """Why one wing leg is unusable: unpriceable (listed, but no buyable price --
    no ask AND no mark; a bare zero-bid with a valid ask is now priceable, since
    we BUY the wing), out-of-band (absent AND beyond +/-band of spot -> the
    chain() fetch clipped it), or unlisted (absent, inside band)."""
    tag = ("P" if opt_type == "put" else "C") + f"{strike:g}"
    q = chain.get(expiry, opt_type, strike)
    if q is not None:
        return f"{tag}=unpriceable" if q.long_price is None else f"{tag}=ok"
    if spot and band and abs(float(strike) / float(spot) - 1.0) > band:
        return f"{tag}=out-of-band"
    return f"{tag}=unlisted"


def _wing_diag(chain: "ChainView", expiry, short_put: float, short_call: float,
               widths, band: float, spot) -> str:
    return " ".join(
        f"w{w:g}:" + _wing_leg_diag(chain, expiry, "put", short_put - w, band, spot)
        + "," + _wing_leg_diag(chain, expiry, "call", short_call + w, band, spot)
        for w in widths)


def _short_candidates(chain: ChainView, expiry: date, opt_type: str,
                      target: float, band: tuple[float, float]):
    """Listed, PRICEABLE shorts with |delta| in `band`, ordered nearest-to-target
    first. The head == what select_short_strike returns. The tail is the SHIFT
    reservoir the collision guard walks when the nearest short's condor collides."""
    lo, hi = band
    out = []
    for k in chain.strikes(expiry, opt_type):
        q = chain.get(expiry, opt_type, k)
        if q is None or q.delta is None or q.mid is None:
            continue
        ad = abs(float(q.delta))
        if ad < lo or ad > hi:
            continue
        out.append((abs(ad - target), k, q))
    out.sort(key=lambda t: (t[0], t[1]))
    return [(k, q) for _, k, q in out]


def _snap_wing(chain: ChainView, expiry: date, opt_type: str,
               short: float, min_width: float):
    """Nearest LISTED wing at least `min_width` out from `short` (down for puts,
    up for calls). Fine grids return short-/+min_width exactly; a coarse grid (GDX
    OTM calls are $5-spaced) snaps OUT to the next listed strike, so the ACTUAL
    width can exceed min_width. None if no listed strike is far enough out (or the
    fetch window clipped it). Returns the wing strike."""
    if opt_type == "put":
        tgt = short - min_width
        cands = [k for k in chain.strikes(expiry, "put") if k <= tgt]
        return max(cands) if cands else None       # closest listed at/below target
    tgt = short + min_width
    cands = [k for k in chain.strikes(expiry, "call") if k >= tgt]
    return min(cands) if cands else None            # closest listed at/above target


def _snap_condor_wings(chain: ChainView, expiry: date, short_put: float,
                       short_call: float, min_width: float):
    """Snap BOTH wings >= min_width out, then WIDEN the narrower side to the
    max-loss (eff) width so the condor is ~symmetric. Rationale: the credit floor
    and risk band scale with the max-side width, but iron-condor credit is driven
    by the (fixed ~20-delta) SHORT, not the width — so a $5 grid-forced call side
    with a $2 put side collects too little to clear 0.30x5. Widening the put side
    to $5 too (its cheaper, further-OTM long) restores the credit/width ratio.
    Returns (long_put, long_call, eff_width) or None if either side has no listed
    wing far enough out (fine grids are unchanged: short-/+min_width exactly)."""
    lp = _snap_wing(chain, expiry, "put", short_put, min_width)
    lc = _snap_wing(chain, expiry, "call", short_call, min_width)
    if lp is None or lc is None:
        return None
    eff = max(short_put - lp, lc - short_call)
    if short_put - lp < eff:
        lp2 = _snap_wing(chain, expiry, "put", short_put, eff)
        if lp2 is not None:
            lp = lp2
    if lc - short_call < eff:
        lc2 = _snap_wing(chain, expiry, "call", short_call, eff)
        if lc2 is not None:
            lc = lc2
    return (lp, lc, max(short_put - lp, lc - short_call))


def _leg_conflicts(net: dict | None, expiry: date, opt_type: str,
                   strike: float, side: str) -> bool:
    """A candidate leg conflicts if OPENING it opposes an existing net position at
    the same contract — RH rejects buy-to-open where net<0 (held short) or
    sell-to-open where net>0 (held long)."""
    if not net:
        return False
    n = net.get((expiry, opt_type, _k(strike)), 0)
    return (side == "buy" and n < 0) or (side == "sell" and n > 0)


def _separation_conflict(net: dict | None, expiry: date, short_put: float,
                         short_call: float, min_sep: float) -> bool:
    """Optional (min_sep>0) diversification guard: True if the candidate's short
    put/call lands within `min_sep` dollars of ANY existing same-expiry SHORT
    (net<0) on the same side. Default OFF (min_sep=0) -> never fires."""
    if not net or min_sep <= 0:
        return False
    for (e_exp, e_type, e_strike), n in net.items():
        if e_exp != expiry or n >= 0:
            continue
        cand = short_put if e_type == "put" else short_call
        if abs(float(cand) - float(e_strike)) < min_sep:
            return True
    return False


def build_condor(symbol: str, symbol_cfg: SymbolConfig, chain: ChainView,
                 cfg: MaceConfig, session_date: date,
                 net_positions: dict | None = None) -> BuildResult:
    """Build a priced iron condor per the entry filter-6 spec. Returns a
    BuildResult with a spec+credit_mid+width or a skip_reason
    (no_expiry|no_delta_strike|no_wing|risk_band|credit_floor|strike_collision).

    `net_positions` (from evaluate_entry via net_option_positions) drives the
    COLLISION guard (P1.1): the short is SHIFTED within the delta band so no leg
    opens opposite an existing same-expiry position; strike_collision only when no
    in-band shift clears. Wings SNAP to the nearest listed strike >= width out
    (P1.3), so GDX/XLE build on their real $5-spaced OTM-call grid; the actual
    (max-side) width drives the risk band, credit floor, and sizing."""
    e = cfg.entry
    expiry = choose_expiry(chain, e.dte_min, e.dte_max, session_date)
    if expiry is None:
        return BuildResult(skip_reason=SKIP_NO_EXPIRY,
                           detail=f"spot={_fmt_spot(chain.spot)} "
                                  f"no-expiry-in-DTE[{e.dte_min},{e.dte_max}] "
                                  f"listed={len(chain.expiries)}")

    put_cands = _short_candidates(chain, expiry, "put", e.short_delta_target, e.short_delta_band)
    call_cands = _short_candidates(chain, expiry, "call", e.short_delta_target, e.short_delta_band)
    if not put_cands or not call_cands:
        lo, hi = e.short_delta_band
        return BuildResult(
            skip_reason=SKIP_NO_DELTA_STRIKE,
            detail=f"spot={_fmt_spot(chain.spot)} exp={expiry} "
                   f"delta_band=[{lo:g},{hi:g}] "
                   f"put_near={_cand(_nearest_delta_strike(chain, expiry, 'put', e.short_delta_target))} "
                   f"call_near={_cand(_nearest_delta_strike(chain, expiry, 'call', e.short_delta_target))}")

    widths = [symbol_cfg.width_dollars]
    if symbol_cfg.fallback_width_dollars:
        widths.append(symbol_cfg.fallback_width_dollars)
    min_sep = getattr(e, "min_strike_separation_usd", 0.0)

    def _price_pair(short_put, sp_q, short_call, sc_q):
        """Price ONE short pair across the width list with snap-to-grid wings.
        Returns ('ok', spec, credit, width) for a clean condor; ('collide', ...)
        for a valid condor that would be atomically rejected (opposite an existing
        same-expiry leg, or within min_sep); else ('skip', reason, detail) with the
        furthest-progress reason for THIS pair. No cross-short shifting here — that
        is the caller's job, and ONLY when a pair collides."""
        p_wing = p_band = False
        p_cf_detail = ""
        p_cf_gap = None
        for width in widths:
            snapped = _snap_condor_wings(chain, expiry, short_put, short_call, width)
            if snapped is None:
                continue                              # no listed wing far enough out
            long_put, long_call, eff_width = snapped
            lp_q = chain.get(expiry, "put", long_put)
            lc_q = chain.get(expiry, "call", long_call)
            # Long wings we BUY: priceable on a valid ask/mark even with no bid
            # (long_price), NOT the two-sided mid the shorts require. Shorts still
            # price at .mid below, so the credit basis for the sold legs is UNCHANGED.
            if lp_q is None or lc_q is None or lp_q.long_price is None or lc_q.long_price is None:
                continue                              # wing unpriceable (no ask AND no mark)
            p_wing = True
            credit_mid = (sp_q.mid - lp_q.long_price) + (sc_q.mid - lc_q.long_price)
            if e.enforce_risk_band:
                max_risk = (eff_width - credit_mid) * 100.0
                if not (e.risk_band_min_per_width_usd * eff_width <= max_risk <= e.risk_band_max_usd):
                    continue                          # out of risk band
            p_band = True
            floor = e.credit_floor_pct_of_width * eff_width
            if credit_mid < floor:
                gap = credit_mid - floor
                if p_cf_gap is None or gap > p_cf_gap:
                    p_cf_gap, p_cf_detail = gap, f"credit {credit_mid:.2f} < floor {floor:.2f}"
                continue                              # below credit floor
            spec = CondorSpec(symbol=symbol, expiry=expiry, short_put=short_put,
                              long_put=long_put, short_call=short_call,
                              long_call=long_call, width_dollars=eff_width)
            legs = (("put", short_put, "sell"), ("put", long_put, "buy"),
                    ("call", short_call, "sell"), ("call", long_call, "buy"))
            if any(_leg_conflicts(net_positions, expiry, t, k, s) for t, k, s in legs) \
                    or _separation_conflict(net_positions, expiry, short_put, short_call, min_sep):
                return ("collide", spec, credit_mid, eff_width)  # valid but would reject
            return ("ok", spec, credit_mid, eff_width)
        # no valid condor at any width for this pair
        _diag = (f"spot={_fmt_spot(chain.spot)} exp={expiry} SP={short_put:g} "
                 f"SC={short_call:g} | "
                 + _wing_diag(chain, expiry, short_put, short_call, widths,
                              e.strike_band_pct, chain.spot))
        if p_band:
            return ("skip", SKIP_CREDIT_FLOOR, p_cf_detail, None)
        if p_wing:
            return ("skip", SKIP_RISK_BAND, _diag + " (all widths out of risk band)", None)
        return ("skip", SKIP_NO_WING, _diag, None)

    # Try short pairs nearest-to-target first. The nearest pair decides the outcome
    # UNLESS it collides — only then do we SHIFT to alternative shorts (P1.1). This
    # keeps a plain no_wing/risk_band/credit_floor identical to the old single-short
    # behavior (snap-to-grid, not the short-shift, is what unblocks GDX/XLE wings).
    saw_collision = False
    for pi, (short_put, sp_q) in enumerate(put_cands):
        for ci, (short_call, sc_q) in enumerate(call_cands):
            kind, a, b_, c = _price_pair(short_put, sp_q, short_call, sc_q)
            if kind == "ok":
                return BuildResult(spec=a, credit_mid=b_, width=c)
            if kind == "collide":
                saw_collision = True
                continue                              # shift to the next short pair
            # kind == "skip": if NO collision has forced a shift, the nearest pair's
            # skip IS the answer (do not explore other shorts for a plain skip).
            if not saw_collision and pi == 0 and ci == 0:
                return BuildResult(skip_reason=a, detail=b_)
            # else we are shifting (a collision was seen) — keep scanning for an 'ok'.

    # Exhausted all shifts with no clean condor: a valid condor existed but every
    # one collided / violated separation.
    return BuildResult(
        skip_reason=SKIP_STRIKE_COLLISION,
        detail=f"spot={_fmt_spot(chain.spot)} exp={expiry} "
               f"every in-band condor overlaps an existing same-expiry leg "
               f"(shift exhausted across {len(put_cands)}x{len(call_cands)} shorts; "
               f"min_sep={min_sep:g})")


# ── sizing + reserve ─────────────────────────────────────────────────────

# Per-rung sizing policy (2026-09-09, replaces the equity/settled-cash budget).
# base = SIZING_BASE_BP_PCT * gross available buying power (the SAME figure the
# reserve/deploy-cap gate sizes on, see deployment_base) so per-rung sizing and
# the deploy cap share one denominator. The $400 floor guarantees each rung can
# fund at least one contract (incl. a $5-wide GDX at ~$380 max-loss) so the tail
# of capital actually deploys instead of stranding when rung_risk_pct*base alone
# would fall short; the min(..., base) guard means the floor can NEVER exceed the
# base (a small account spends at most its whole base -> unfundable -> SKIP_BUDGET).
SIZING_BASE_BP_PCT = 0.95
MIN_RUNG_BUDGET_USD = 400.0


def rung_budget(buying_power: float, rung_risk_pct: float) -> float:
    """Per-rung sizing budget:
        base   = SIZING_BASE_BP_PCT * buying_power
        budget = min( max(rung_risk_pct * base, MIN_RUNG_BUDGET_USD), base )
    Precedence: rung_risk_pct*base > $400 -> the PERCENTAGE governs (higher BP);
    rung_risk_pct*base < $400 <= base -> the $400 FLOOR governs; base < $400 ->
    the BASE caps it (can't deploy what isn't there)."""
    base = SIZING_BASE_BP_PCT * float(buying_power)
    return min(max(rung_risk_pct * base, MIN_RUNG_BUDGET_USD), base)


def size_contracts(buying_power: float, width: float, credit_mid: float,
                   rung_risk_pct: float, max_contracts: int) -> int:
    per_contract_risk = (width - credit_mid) * 100.0
    if per_contract_risk <= 0:
        return 0
    raw = math.floor(rung_budget(buying_power, rung_risk_pct) / per_contract_risk)
    return max(0, min(raw, max_contracts))


def max_risk_usd(width: float, credit_mid: float, contracts: int) -> float:
    return (width - credit_mid) * 100.0 * contracts


# ── entry pipeline ───────────────────────────────────────────────────────

def _skip(symbol: str, reason: str, *, ivr_status: str = IVR_OK,
          ivr_value=None, overflow=False, detail="") -> EvalResult:
    return EvalResult(symbol=symbol, entered=False, skip_reason=reason,
                      ivr_status=ivr_status, ivr_value=ivr_value,
                      overflow=overflow, detail=detail)


def evaluate_entry(symbol: str, cfg: MaceConfig, ctx: EntryContext,
                   *, is_overflow: bool = False) -> EvalResult:
    """Run the 10-filter entry pipeline for one symbol. First failing filter is
    the recorded skip reason. `is_overflow` skips ONLY the weekly-budget filter
    (T6). Returns an EvalResult (entered=True carries spec/credit/contracts)."""
    sc = cfg.symbols.get(symbol)
    if sc is None:
        return _skip(symbol, SKIP_CAPACITY, detail="no symbol config")
    e = cfg.entry

    # 0. equity snapshot must exist (sizing basis)
    if ctx.equity is None or ctx.equity <= 0:
        return _skip(symbol, SKIP_NO_EQUITY_SNAPSHOT)

    # 1. capacity
    if open_rung_count(ctx.rungs, symbol) >= e.max_rungs_per_symbol:
        return _skip(symbol, SKIP_CAPACITY, overflow=is_overflow)

    # 2. weekly budget (+ refill) — EXEMPT for overflow entries (T6)
    if not is_overflow:
        budget = e.weekly_new_rungs_per_symbol + closures_before_today_this_week(
            ctx.rungs, symbol, ctx.session_date)
        if entries_this_week(ctx.rungs, symbol, ctx.session_date) >= budget:
            return _skip(symbol, SKIP_WEEKLY_BUDGET)

    # 3. cooldown (no stop-loss exit within the last stop_cooldown_sessions)
    since = sessions_since_last_stop(ctx.rungs, symbol, ctx.session_date)
    if since is not None and since < e.stop_cooldown_sessions:
        return _skip(symbol, SKIP_COOLDOWN, overflow=is_overflow,
                     detail=f"{since} sessions since last stop")

    # 4. blackout (today OR next trading session)
    if is_blackout(symbol, sc, ctx.events, ctx.session_date, ctx.next_session()):
        return _skip(symbol, SKIP_BLACKOUT, overflow=is_overflow)

    # 5. IVR — stale/unavailable SKIP THE FILTER (annotate), do not reject
    r = ctx.ivr.get(symbol)
    ivr_status = getattr(r, "status", IVR_UNAVAILABLE) if r is not None else IVR_UNAVAILABLE
    ivr_value = getattr(r, "ivr", None) if r is not None else None
    if ivr_status == IVR_OK:
        if ivr_value is None or ivr_value < e.ivr_floor:
            return _skip(symbol, SKIP_IVR, ivr_status=ivr_status,
                         ivr_value=ivr_value, overflow=is_overflow)
    # IVR_STALE / IVR_UNAVAILABLE: continue (credit floor + blackout still gate)

    # 6. build (expiry / delta strikes / universal wing + snap-to-grid / width
    #    fallback / risk band / credit floor / strike-collision shift — build_condor
    #    returns a spec only when a short pair clears ALL of them; b.detail carries
    #    the furthest-progress miss). net_positions drives the collision guard so a
    #    new long leg never opens opposite an existing same-expiry short (RH reject).
    chain = ctx.chains.get(symbol)
    if chain is None:
        return _skip(symbol, SKIP_NO_EXPIRY, ivr_status=ivr_status,
                     ivr_value=ivr_value, overflow=is_overflow,
                     detail="no chain")
    b = build_condor(symbol, sc, chain, cfg, ctx.session_date,
                     net_positions=net_option_positions(ctx.rungs, symbol))
    if b.skip_reason is not None:
        return _skip(symbol, b.skip_reason, ivr_status=ivr_status,
                     ivr_value=ivr_value, overflow=is_overflow, detail=b.detail)

    # 7. credit floor: now enforced INSIDE build_condor's width loop (filter 6)
    #    so the fallback width is tried when the primary is below floor. A
    #    returned spec has already cleared the floor at b.width (2026-08-14 fix).

    # 8. size
    # Sizing base = the gross available buying power (deployment_base = the SAME
    # denominator the reserve/deploy-cap gate uses below), scaled inside
    # size_contracts by SIZING_BASE_BP_PCT. (Was ctx.equity / settled cash.)
    contracts = size_contracts(deployment_base(cfg, ctx), b.width, b.credit_mid,
                               cfg.sizing.rung_risk_pct, cfg.max_contracts)
    if contracts <= 0:
        return _skip(symbol, SKIP_BUDGET, ivr_status=ivr_status,
                     ivr_value=ivr_value, overflow=is_overflow)
    mr = max_risk_usd(b.width, b.credit_mid, contracts)

    # 9. reserve — deployment cap. deployable = deployment_basis * deployment_target_pct;
    #    a new rung SKIPs if committed + this rung's max_risk would breach it.
    #    committed is basis-dependent (see reserve_committed): available-BP counts only
    #    WITHIN-EVAL placements (the base already nets pre-existing collateral, Option A);
    #    equity counts all open rungs (total-book). Enforced HERE at entry eval BEFORE
    #    any placement, and again on the per-placement fresh-rungs recheck in the manager
    #    (so N rungs in ONE eval cannot collectively exceed base*target). Per-rung sizing
    #    above stays on equity.
    if (reserve_committed(cfg, ctx) + mr
            > cfg.sizing.deployment_target_pct * deployment_base(cfg, ctx)):
        return _skip(symbol, SKIP_RESERVE, ivr_status=ivr_status,
                     ivr_value=ivr_value, overflow=is_overflow)

    # 10. risk gate (per-leg; any reject aborts the whole condor)
    if ctx.risk_gate is not None and not ctx.risk_gate(symbol, b.spec, contracts):
        return _skip(symbol, SKIP_RISK_REJECT, ivr_status=ivr_status,
                     ivr_value=ivr_value, overflow=is_overflow)

    return EvalResult(symbol=symbol, entered=True, skip_reason=None, spec=b.spec,
                      credit_mid=b.credit_mid, contracts=contracts,
                      max_risk_usd=mr, ivr_status=ivr_status, ivr_value=ivr_value,
                      overflow=is_overflow,
                      detail=f"{b.spec.strikes_label()} x{contracts} credit {b.credit_mid:.2f}")


# ── overflow routing (T6 as ruled 2026-08-09) ────────────────────────────

# Skip reasons that FORFEIT capital a primary would have deployed (they route
# to overflow). Structural/no-data skips do NOT forfeit deployable capital.
_FORFEITING_SKIPS = frozenset({
    SKIP_WEEKLY_BUDGET, SKIP_COOLDOWN, SKIP_BLACKOUT, SKIP_IVR,
    SKIP_NO_DELTA_STRIKE, SKIP_NO_WING, SKIP_RISK_BAND, SKIP_CREDIT_FLOOR,
})


def route_overflow(primary_results: Sequence[EvalResult], cfg: MaceConfig,
                   ctx: EntryContext) -> list[EvalResult]:
    """T6: capital forfeited by a failed primary filter routes to IBIT first
    (enabled + overflow_only, bounded by ibit_overflow_cap rungs), then the
    highest-IVR ENABLED primary that did NOT already enter this session.
    Overflow entries skip the weekly-budget filter; all OTHER filters apply;
    capped at overflow_max_per_symbol_session per receiver.

    Single pass: each receiver is attempted at most once (correct for the
    shipped cap of 1/symbol/session). Multi-placement reserve/capacity
    accounting across a session is the manager's job (re-evaluate with updated
    rungs after each placement). Inert at launch (universe=[SPY], IBIT
    disabled) — no receivers, so forfeits go nowhere."""
    forfeits = sum(1 for r in primary_results
                   if not r.entered and r.skip_reason in _FORFEITING_SKIPS)
    if forfeits <= 0:
        return []

    def ivr_of(sym: str) -> float:
        rr = ctx.ivr.get(sym)
        v = getattr(rr, "ivr", None) if rr is not None else None
        return v if v is not None else -1.0

    # A receiver must be NEITHER a symbol that ENTERED this round NOR one that
    # FORFEITED it. Excluding ENTERED is the 2026-08-12 fix: routing forfeited
    # capital onto a just-placed symbol re-enters it (the pre-placement rung
    # snapshot hides its new rung) -> a duplicate order fires (live: SPY entered,
    # GLD forfeited, router re-picked SPY, RH rejected the duplicate ref_id).
    # Excluding FORFEITED keeps a symbol from receiving its own capital back and
    # bypassing the filter it just failed. Net: overflow routes only to genuinely
    # idle receivers (IBIT-style overflow_only, or a primary that neither entered
    # nor forfeited).
    forfeiting = {r.symbol for r in primary_results
                  if not r.entered and r.skip_reason in _FORFEITING_SKIPS}
    entered = {r.symbol for r in primary_results if r.entered}
    excluded = forfeiting | entered
    ibit = [s for s, c in cfg.symbols.items() if c.enabled and c.overflow_only]
    primaries = sorted(
        (s for s, c in cfg.symbols.items()
         if c.enabled and not c.overflow_only and s not in excluded),
        key=ivr_of, reverse=True)
    ordered = ibit + primaries

    results: list[EvalResult] = []
    remaining = forfeits
    for sym in ordered:
        if remaining <= 0:
            break
        if (cfg.symbols[sym].overflow_only
                and open_rung_count(ctx.rungs, sym) >= cfg.entry.ibit_overflow_cap):
            continue
        res = evaluate_entry(sym, cfg, ctx, is_overflow=True)
        if res.entered:
            results.append(res)
            remaining -= 1
    return results


# ── management precedence ────────────────────────────────────────────────

@dataclass(frozen=True)
class ManageDecision:
    rung_id: str
    exit_reason: str | None      # EXIT_STOP | EXIT_PT | EXIT_TIME | EXIT_EXDIV | None (hold)
    detail: str = ""

    @property
    def should_exit(self) -> bool:
        return self.exit_reason is not None


def evaluate_management(rung: RungState, mark: float | None, spot: float | None,
                        now_et: datetime, cfg: MaceConfig, symbol_cfg: SymbolConfig,
                        *, exdiv_within: bool) -> ManageDecision:
    """Precedence: stop > PT > time > exdiv. `mark` = cost-to-close at mid (net
    debit to exit). The 09:35 tick IS the gap rule (no separate branch).
    `exdiv_within` is the calendar side (caller uses mace.exdiv.MaceExDiv).

    PT is the T9 SYNTHETIC profit target (Board ruling 2026-08-10, on the T9 basis):
    there is NO resting-GTC PT order — the manage tick IS the PT. When the
    cost-to-close (`mark`) has decayed to <= pt_pct_of_credit x credit received, we
    close via the emulated-market exit ladder (reason `pt`); since mark <= the PT
    target, the ladder's natural debit is already at/under target, so the close
    books at/inside the profit target. stop (a loss) and PT (a win) are mutually
    exclusive on `mark`; PT is ordered before time/exdiv so a hit target closes
    favorably regardless of DTE, and the exit is labelled `pt` (not `time`)."""
    m = cfg.management
    # stop: mark >= stop_multiple x credit received
    if mark is not None and rung.credit_actual is not None:
        if mark >= m.stop_multiple * rung.credit_actual:
            return ManageDecision(rung.rung_id, EXIT_STOP,
                                  f"mark {mark:.2f} >= {m.stop_multiple}x credit "
                                  f"{rung.credit_actual:.2f}")
    # PT (T9 synthetic): mark <= pt_pct_of_credit x credit received -> lock the win.
    if mark is not None and rung.credit_actual is not None:
        pt_target = m.pt_pct_of_credit * rung.credit_actual
        if mark <= pt_target:
            return ManageDecision(rung.rung_id, EXIT_PT,
                                  f"mark {mark:.2f} <= {m.pt_pct_of_credit}x credit "
                                  f"{rung.credit_actual:.2f} (synthetic PT)")
    # time: DTE <= time_exit_dte AND now >= time_exit_at_et
    dte = (rung.expiry - now_et.date()).days
    if dte <= m.time_exit_dte and now_et.time() >= dtime.fromisoformat(m.time_exit_at_et):
        return ManageDecision(rung.rung_id, EXIT_TIME, f"DTE {dte} at/after {m.time_exit_at_et}")
    # exdiv: guard on AND short call ITM (spot > short-call strike) AND ex-div near
    if (symbol_cfg.exdiv_guard and exdiv_within and spot is not None
            and spot > rung.spec.short_call):
        return ManageDecision(rung.rung_id, EXIT_EXDIV,
                              f"short call ITM (spot {spot} > {rung.spec.short_call}) + ex-div near")
    return ManageDecision(rung.rung_id, None, "hold")


# ── PT mark-trust guard (2026-09-18) ─────────────────────────────────────
# The synthetic PT (evaluate_management above) fires on the fresh cost-to-close MID. On 2026-09-18 a
# STALE/erroneous mark (0.13, identical twice) falsely satisfied the 50% PT on an XLE condor that was
# NOT near profit (true value ~0.41; the identical-strike shorter-dated sibling marked 0.205 -> a
# longer-dated same-strike condor cannot be worth LESS). This guard gates ONLY the PT fire on a mark
# that is TIMELY (not frozen) + SANE (no arbitrage / structural violation). PURE: the manager fetches
# the sibling fresh-marks + tracks the per-rung state and passes them in; here we only decide.

@dataclass(frozen=True)
class MarkTrust:
    trusted: bool
    reason: str          # ok | frozen | arbitrage | structural | no_baseline | leg_inversion
    alert: bool          # True -> emit the untrusted alert; False -> silent one-cycle hold (no_baseline)
    detail: str = ""


def shorter_dated_same_strike_siblings(
    rungs: Sequence[RungState], rung: RungState,
) -> list[RungState]:
    """LIVE rungs (submitting/open/closing) for the same symbol with the SAME 4 strikes as `rung`
    and a STRICTLY SHORTER expiry (excludes `rung` itself). A longer-dated same-strike condor cannot
    cost LESS to close than a shorter-dated one, so these give an arbitrage LOWER bound on `rung`'s
    cost-to-close mark. (PT's failure mode is a too-LOW mark, so only the shorter-dated lower bound
    matters; longer-dated siblings are not used here.)"""
    if rung.spec is None:
        return []
    s = rung.spec
    out: list[RungState] = []
    for r in rungs:
        if (r.rung_id == rung.rung_id or r.symbol != rung.symbol
                or r.status not in _LIVE_STATUSES or r.spec is None):
            continue
        o = r.spec
        if (_k(o.short_put) == _k(s.short_put) and _k(o.long_put) == _k(s.long_put)
                and _k(o.short_call) == _k(s.short_call) and _k(o.long_call) == _k(s.long_call)
                and o.expiry < s.expiry):
            out.append(r)
    return out


def assess_pt_mark_trust(
    rung: RungState, mark: float | None, cfg: MaceConfig, *,
    sibling_marks: Sequence[float | None], unchanged_repeat: int,
    last_trusted_mark: float | None, dte: int,
    leg_marks: Mapping[str, float | None] | None = None,
) -> MarkTrust:
    """PURE. Decide whether a PT-eligible `mark` (cost-to-close mid that just satisfied the synthetic
    PT) is trustworthy enough to FIRE the profit-target close.

      TIMELY  — reject if `mark` has been bit-identical (to the cent) across >= frozen_cycles
                consecutive PT-eligible ticks (`unchanged_repeat`, tracked by the caller): a frozen
                upstream quote.
      SANE    — structural: reject a nonsensical mark (< 0 or >= width; arbitrage-impossible for a
                defined-risk short condor being bought back). LEG (2026-10-02): reject if a LONG wing
                is marked >= the SHORT it protects (long put >= short put, or long call >= short call,
                beyond sane_epsilon_usd) -- the vertical would have <= 0 cost-to-close, which is
                arbitrage-impossible; catches a corrupted illiquid-wing mark INDEPENDENT of any
                sibling (fires even with none). Needs leg_marks (keys sp/lp/sc/lc); skipped when
                absent. Sibling (PRIMARY): reject if `mark < max(sibling_marks) - epsilon`
                (longer-dated same-strike cannot be cheaper). Fallback (no sibling): reject if
                `dte > time_exit_dte` AND `mark < last_trusted_mark * (1 - max_cycle_drop_pct)` (an
                implausibly fast single-cycle collapse far from the time-exit window). No sibling AND
                no baseline -> fail-closed HOLD for one tick (silent, alert=False); the caller seeds
                the baseline and PT fires next tick (Board-accepted one-cycle delay; PT is not
                deadline-driven).

    Returns MarkTrust(trusted, reason, alert, detail)."""
    mg = cfg.management.mark_guard
    if not mg.enabled:
        return MarkTrust(True, "ok", False, "guard disabled")

    # TIMELY (frozen) — the caller passes the current consecutive-identical count including this tick.
    if unchanged_repeat >= mg.frozen_cycles:
        return MarkTrust(False, "frozen", True,
                         f"mark {mark:.2f} unchanged across {unchanged_repeat} consecutive PT-eligible ticks")

    # SANE — structural (mark==0 is allowed: a legitimately worthless near-expiry condor = max profit;
    # a spurious 0 at high DTE is caught by the sibling/fallback/frozen checks, not here).
    if mark is None or mark < 0.0 or mark >= rung.width_dollars:
        return MarkTrust(False, "structural", True,
                         f"mark {mark} outside [0, width {rung.width_dollars})")

    # SANE — intra-condor leg sanity (2026-10-02). A LONG wing cannot be marked dearer than the SHORT
    # it protects: the vertical it forms would have <= 0 cost-to-close = arbitrage-impossible. Catches
    # a corrupted/illiquid wing mark (e.g. a zero-bid far-OTM long whose stale wide-midpoint inverts
    # the structure and makes the whole condor look falsely cheap -- the 2026-10-02 XLE 60/59/70/71
    # incident: long 71C marked 0.22 > short 70C 0.15) INDEPENDENT of any sibling, so it fires even
    # when no shorter-dated sibling exists. Skipped when leg marks are unavailable.
    if leg_marks:
        eps = mg.sane_epsilon_usd
        sp, lp = leg_marks.get("sp"), leg_marks.get("lp")
        sc, lc = leg_marks.get("sc"), leg_marks.get("lc")
        if sp is not None and lp is not None and lp > sp + eps:
            return MarkTrust(False, "leg_inversion", True,
                             f"long put mark {lp:.2f} >= short put {sp:.2f} (+{eps}) "
                             f"-- arbitrage-impossible inverted wing")
        if sc is not None and lc is not None and lc > sc + eps:
            return MarkTrust(False, "leg_inversion", True,
                             f"long call mark {lc:.2f} >= short call {sc:.2f} (+{eps}) "
                             f"-- arbitrage-impossible inverted wing")

    # SANE — sibling arbitrage (primary).
    sibs = [s for s in (sibling_marks or []) if s is not None]
    if sibs:
        max_sib = max(sibs)
        if mark < max_sib - mg.sane_epsilon_usd:
            return MarkTrust(False, "arbitrage", True,
                             f"mark {mark:.2f} < shorter-dated same-strike sibling {max_sib:.2f} "
                             f"- {mg.sane_epsilon_usd} (arbitrage-impossible)")
        return MarkTrust(True, "ok", False, f"mark {mark:.2f} >= sibling {max_sib:.2f}")

    # SANE — fallback decay (no same-strike shorter-dated sibling).
    if last_trusted_mark is None:
        return MarkTrust(False, "no_baseline", False,
                         "no sibling + no trusted baseline; hold one tick (seed + fire next)")
    if dte > cfg.management.time_exit_dte and mark < last_trusted_mark * (1.0 - mg.max_cycle_drop_pct):
        return MarkTrust(False, "arbitrage", True,
                         f"mark {mark:.2f} collapsed > {mg.max_cycle_drop_pct:.0%} vs last-trusted "
                         f"{last_trusted_mark:.2f} at DTE {dte} > {cfg.management.time_exit_dte}")
    return MarkTrust(True, "ok", False, f"mark {mark:.2f} within fallback bound")


# ── breakers (alert-only) ────────────────────────────────────────────────

def evaluate_breakers(day_realized: float, week_realized: float,
                      equity: float | None, hwm: float | None,
                      cfg: MaceConfig) -> BreakerState:
    """Signed realized P&L in (day_realized, week_realized) — negative = loss.
    A loss >= day/week pct of E fires; equity below hwm_soft/hwm_hard x HWM fires.
    Alert-only: BreakerState is advisory; enforcement is a separate switch."""
    b = cfg.breakers
    e_ok = equity is not None and equity > 0
    h_ok = hwm is not None and hwm > 0
    day_hit = bool(e_ok and day_realized <= -b.day_loss_pct * equity)
    week_hit = bool(e_ok and week_realized <= -b.week_loss_pct * equity)
    soft_hit = bool(h_ok and equity < b.hwm_soft_pct * hwm)
    hard_hit = bool(h_ok and equity < b.hwm_hard_pct * hwm)
    return BreakerState(
        day_loss_hit=day_hit, week_loss_hit=week_hit,
        hwm_soft_hit=soft_hit, hwm_hard_hit=hard_hit,
        day_realized=day_realized, week_realized=week_realized,
        equity=equity, hwm=hwm,
    )
