"""Phase-3 adversarial tests for mace/execution.py.

Drives MaceExecutor against a scriptable FakePort + an in-memory mace_rung DB.
Coverage: entry credit ladder (walk-down, distinct ref_ids, floor drift, cutoff,
exhaustion), cancel races at every stage, the absolute fake-fill guard (exception
/ partial / unconfirmed NEVER books and NEVER double-places), the resting-GTC PT
lifecycle, the emulated-market exit debit ladder (walk-up, ceiling, exhaustion ->
stays CLOSING + URGENT), and the reconcile state machine (PT poll, crash-recovery
drain by combo_id, abandon past horizon).
"""
from __future__ import annotations

import dataclasses
import sqlite3
from datetime import date, datetime
from pathlib import Path
from types import SimpleNamespace

import pytest

from trading_corp.mace import broker_port as bp
from trading_corp.mace import execution as ex
from trading_corp.mace.broker_port import OptionsBrokerPort, OpenOrder, OrderResult
from trading_corp.mace.config import load_mace_config
from trading_corp.mace.domain import (
    CondorSpec, OptionQuote, EXIT_PT, EXIT_STOP, EXIT_TIME, EXIT_EXDIV,
    RUNG_ABANDONED, RUNG_CLOSED, RUNG_CLOSING, RUNG_OPEN, RUNG_SUBMITTING,
)
from trading_corp.mace.manager import MaceManager
from trading_corp.mace.notify import MaceNotifier
from trading_corp.persistence import db as dbmod
from trading_corp.utils.time import ET, UTC

ROOT = Path(__file__).resolve().parents[1]
CFG = load_mace_config(ROOT / "config" / "mace.yaml",
                       exdiv_calendar_path=ROOT / "config" / "ex_dividend_calendar.yaml")
# The ladder-MECHANISM tests below were written against the launch 5x60 entry
# ladder. The shipped config is 2x30 as of 2026-08-13 (Board 3-active memo) —
# shipped values are asserted in test_mace_config.py. Pin the old shape here so
# walk-down / exhaustion / cancel-race coverage stays byte-identical.
CFG = dataclasses.replace(CFG, execution=dataclasses.replace(
    CFG.execution, entry_max_attempts=5, entry_fill_wait_sec=60))

SESSION = date(2026, 8, 10)          # Monday
EXPIRY = date(2026, 9, 18)
SPEC = CondorSpec("SPY", EXPIRY, 585.0, 582.0, 615.0, 618.0, 3.0)  # width 3
RUNG_ID = SPEC.rung_id(SESSION)
ISO_WK = "2026-W33"


# ── scriptable fake port ───────────────────────────────────────────────────

class FakePort(OptionsBrokerPort):
    def __init__(self) -> None:
        self.quotes: dict[tuple[str, float], OptionQuote] = {}
        self.place_script: list = []       # OrderResult | Exception, popped per place
        self.place_calls: list = []
        self.status_script: dict = {}       # order_id -> OrderResult | list | Exception
        self.status_calls: list = []
        self.cancel_calls: list = []
        self.resting_script: list = []      # id str | Exception, popped
        self.resting_calls: list = []
        self.open_orders_ret = []
        self.positions_ret = []
        self._pt = 0

    async def chain(self, symbol):  # unused here
        raise NotImplementedError

    async def leg_quote(self, symbol, expiry, opt_type, strike):
        return self.quotes.get((opt_type, round(float(strike), 4)))

    async def place_condor(self, spec, contracts, net_limit, combo_id, *,
                           direction, time_in_force, fill_timeout_s):
        self.place_calls.append(SimpleNamespace(
            spec=spec, contracts=contracts, net_limit=net_limit, combo_id=combo_id,
            direction=direction, tif=time_in_force, timeout=fill_timeout_s))
        item = self.place_script.pop(0)
        if isinstance(item, Exception):
            raise item
        return item

    async def place_resting_close(self, spec, contracts, net_debit_limit, ref_id):
        self.resting_calls.append(SimpleNamespace(
            ref_id=ref_id, debit=net_debit_limit, contracts=contracts))
        if self.resting_script:
            item = self.resting_script.pop(0)
            if isinstance(item, Exception):
                raise item
            return item
        self._pt += 1
        return f"PT-{self._pt}"

    async def cancel(self, order_id):
        self.cancel_calls.append(order_id)

    async def order_status(self, order_id):
        self.status_calls.append(order_id)
        v = self.status_script.get(order_id)
        if v is None:
            raise KeyError(f"no status script for {order_id}")
        if isinstance(v, Exception):
            raise v
        if isinstance(v, list):
            return v.pop(0) if len(v) > 1 else v[0]
        return v

    async def open_orders(self):
        if isinstance(self.open_orders_ret, Exception):
            raise self.open_orders_ret
        return list(self.open_orders_ret)

    async def open_positions(self):
        return list(self.positions_ret)

    async def snapshot(self):
        return bp.PortSnapshot(equity=10000.0)

    async def account_assertions(self):
        return bp.AccountInfo(account_number="116637293063", option_level=3,
                              account_type="joint", margin=True)


# ── helpers ────────────────────────────────────────────────────────────────

class RecChannel:
    def __init__(self):
        self.msgs: list[str] = []

    def push(self, t):
        self.msgs.append(t)

    def push_split(self, t):
        self.msgs.append(t)

    def any(self, needle: str) -> bool:
        return any(needle in m for m in self.msgs)


def _conn():
    c = sqlite3.connect(":memory:")
    c.row_factory = sqlite3.Row
    c.executescript(dbmod.SCHEMA)
    return c


def _res(state, order_id="O", pq=0.0):
    return OrderResult(order_id=order_id, state=state, processed_quantity=pq)


def _entry_quotes(port: FakePort):
    """credit_mid = (1.00-0.40)+(1.10-0.50) = 1.20; floor = 0.30*3 = 0.90."""
    port.quotes = {
        ("put", 585.0): OptionQuote("SPY", EXPIRY, 585.0, "put", 0.98, 1.02, -0.20),
        ("put", 582.0): OptionQuote("SPY", EXPIRY, 582.0, "put", 0.38, 0.42, -0.12),
        ("call", 615.0): OptionQuote("SPY", EXPIRY, 615.0, "call", 1.08, 1.12, 0.20),
        ("call", 618.0): OptionQuote("SPY", EXPIRY, 618.0, "call", 0.48, 0.52, 0.12),
    }


def _low_credit_quotes(port: FakePort):
    """credit_mid = 0.91 so attempt-1 limit 0.89 < floor 0.90 -> credit_floor_drift."""
    port.quotes = {
        ("put", 585.0): OptionQuote("SPY", EXPIRY, 585.0, "put", 0.83, 0.87, -0.20),   # mid .85
        ("put", 582.0): OptionQuote("SPY", EXPIRY, 582.0, "put", 0.38, 0.42, -0.12),   # mid .40
        ("call", 615.0): OptionQuote("SPY", EXPIRY, 615.0, "call", 0.94, 0.98, 0.20),  # mid .96
        ("call", 618.0): OptionQuote("SPY", EXPIRY, 618.0, "call", 0.48, 0.52, 0.12),  # mid .50
    }  # (.85-.40)+(.96-.50)=.45+.46=.91


def _exit_quotes(port: FakePort):
    """natural = (sp.ask+sc.ask) - (lp.bid+lc.bid) = (2.0+0.10)-(0.05+0.01)=2.04."""
    port.quotes = {
        ("put", 585.0): OptionQuote("SPY", EXPIRY, 585.0, "put", 1.90, 2.00, -0.55),
        ("put", 582.0): OptionQuote("SPY", EXPIRY, 582.0, "put", 0.05, 0.07, -0.30),
        ("call", 615.0): OptionQuote("SPY", EXPIRY, 615.0, "call", 0.06, 0.10, 0.10),
        ("call", 618.0): OptionQuote("SPY", EXPIRY, 618.0, "call", 0.01, 0.03, 0.05),
    }


def _executor(port, store, chan, *, et_h=15, et_mi=45, risk_gate=None, resting_pt=True,
              now_et_fn=None):
    notifier = MaceNotifier(channel=chan, enabled=True)
    # Default to an APPROVING gate — the place-funnel is fail-closed (no gate =>
    # raises), so lifecycle tests inject a passing gate; the risk-chokepoint tests
    # (test_mace_risk_chokepoint.py) inject rejecting / absent gates on purpose.
    if risk_gate is None:
        risk_gate = lambda spec, contracts, direction: True   # noqa: E731
    # These lifecycle tests were written against the resting-GTC PT path, so they
    # default resting_pt=True (the seam). The T9 SYNTHETIC PT (production default,
    # resting_pt=False) is covered by the T9 section at the bottom of this file.
    return ex.MaceExecutor(
        CFG, port, ex.RungStore(store) if isinstance(store, sqlite3.Connection) else store,
        notifier, risk_gate=risk_gate, resting_pt=resting_pt,
        now_utc_fn=lambda: datetime(2026, 8, 10, 19, 45, tzinfo=UTC),
        now_et_fn=now_et_fn or (lambda: datetime(2026, 8, 10, et_h, et_mi, tzinfo=ET)),
        poll_interval_s=0.001, poll_timeout_s=0.01)


def _ev(contracts=1):
    return SimpleNamespace(spec=SPEC, contracts=contracts, max_risk_usd=182.0)


def _open_rung(store: ex.RungStore, *, credit=1.18, pt="PT1", pt_debit=0.59):
    store.insert_submitting(RUNG_ID, SPEC, 1, entry_ts="2026-08-10T19:40:00+00:00",
                            entry_iso_week=ISO_WK, max_risk_usd=182.0)
    store.promote_open(RUNG_ID, credit_actual=credit, entry_order_id="O1",
                       entry_ts="2026-08-10T19:40:00+00:00")
    if pt:
        store.set_pt(RUNG_ID, pt, pt_debit)
    return store.get(RUNG_ID)


# ── ENTRY LADDER ────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_entry_fills_first_attempt_books_and_places_pt():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_FILLED, "O1")]
    out = await _executor(port, store, chan).run_entry(_ev(), SESSION)
    assert out.filled and out.credit == pytest.approx(1.18)
    r = store.get(RUNG_ID)
    assert r.status == RUNG_OPEN and r.credit_actual == pytest.approx(1.18)
    assert r.pt_order_id == "PT-1" and r.pt_debit == pytest.approx(0.59)
    assert port.resting_calls[0].ref_id.endswith("-pt")
    assert chan.any("MACE ENTRY")
    # marketability + credit basis: submitted a CREDIT combo at the mid-0.02 limit
    assert port.place_calls[0].direction == bp.DIR_CREDIT
    assert port.place_calls[0].net_limit == pytest.approx(1.18)


@pytest.mark.asyncio
async def test_entry_walks_credit_down_distinct_ref_ids_fills_third():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_QUEUED, "O1"), _res(bp.STATE_QUEUED, "O2"),
                         _res(bp.STATE_FILLED, "O3")]
    port.status_script = {"O1": _res(bp.STATE_CANCELLED, "O1"),
                          "O2": _res(bp.STATE_CANCELLED, "O2")}
    out = await _executor(port, store, chan).run_entry(_ev(), SESSION)
    assert out.filled and out.attempts == 3
    assert out.credit == pytest.approx(1.16)          # 1.20 - 0.02 - 2*0.01
    combos = [c.combo_id for c in port.place_calls]
    assert combos == [f"{RUNG_ID}-a1", f"{RUNG_ID}-a2", f"{RUNG_ID}-a3"]
    assert len(set(combos)) == 3                      # distinct ref_id per attempt
    assert [c.net_limit for c in port.place_calls] == pytest.approx([1.18, 1.17, 1.16])
    assert "O1" in port.cancel_calls and "O2" in port.cancel_calls


@pytest.mark.asyncio
async def test_entry_cancel_race_fill_books_off_confirmed_state():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_QUEUED, "O1")]     # pending -> cancel -> race
    port.status_script = {"O1": _res(bp.STATE_FILLED, "O1")}  # filled in the race
    out = await _executor(port, store, chan).run_entry(_ev(), SESSION)
    assert out.filled and out.credit == pytest.approx(1.18)
    assert "O1" in port.cancel_calls
    assert store.get(RUNG_ID).status == RUNG_OPEN


@pytest.mark.asyncio
async def test_entry_exception_never_books_and_keeps_anchor_for_reconcile():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [RuntimeError("network lost after submit")]
    out = await _executor(port, store, chan).run_entry(_ev(), SESSION)
    assert not out.filled and out.standdown_reason == "error"
    r = store.get(RUNG_ID)
    assert r is not None and r.status == RUNG_SUBMITTING     # anchor kept, NOT booked
    assert r.credit_actual == pytest.approx(1.18)            # basis persisted pre-place
    assert chan.any("rejected")


@pytest.mark.asyncio
async def test_entry_definitive_reject_deletes_anchor_same_session():
    # 2026-08-20 P1.2: a DEFINITIVE broker reject (MaceOrderRejected -> nothing
    # placed) is distinct from an ambiguous error. It does a CLEAN stand-down that
    # DELETES the submitting anchor immediately, freeing the capacity slot THIS
    # session (the 8/19 position_effect collision reject stranded a slot before).
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [bp.MaceOrderRejected(
        "Robinhood did not accept the credit combo on SPY x1: "
        "{'position_effect': \"can't buy to open ... already short\"}")]
    out = await _executor(port, store, chan).run_entry(_ev(), SESSION)
    assert not out.filled and out.standdown_reason == "rejected"
    assert store.get(RUNG_ID) is None                       # anchor DELETED, slot freed


@pytest.mark.asyncio
async def test_entry_partial_fill_is_urgent_never_booked():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_PARTIAL, "O1", pq=1.0)]
    out = await _executor(port, store, chan).run_entry(_ev(), SESSION)
    assert not out.filled and out.standdown_reason == "partial"
    assert store.get(RUNG_ID).status == RUNG_SUBMITTING
    assert chan.any("URGENT") and chan.any("PARTIAL")


@pytest.mark.asyncio
async def test_entry_cancel_race_unconfirmed_stands_down_and_keeps_anchor():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_QUEUED, "O1")]
    port.status_script = {"O1": _res(bp.STATE_QUEUED, "O1")}   # never confirms terminal
    out = await _executor(port, store, chan).run_entry(_ev(), SESSION)
    assert not out.filled and out.standdown_reason == "unconfirmed"
    assert store.get(RUNG_ID).status == RUNG_SUBMITTING       # not double-placed
    assert len(port.place_calls) == 1                          # refused a 2nd attempt


@pytest.mark.asyncio
async def test_entry_credit_floor_drift_stands_down_clean():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _low_credit_quotes(port)
    out = await _executor(port, store, chan).run_entry(_ev(), SESSION)
    assert not out.filled and out.standdown_reason == "credit_floor_drift"
    assert store.get(RUNG_ID) is None                          # clean stand-down deletes anchor
    assert port.place_calls == []                              # never placed below floor
    assert chan.any("stand-down")


@pytest.mark.asyncio
async def test_entry_cutoff_stands_down_before_placing():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    out = await _executor(port, store, chan, et_h=15, et_mi=59).run_entry(_ev(), SESSION)
    assert not out.filled and out.standdown_reason == "cutoff"
    assert store.get(RUNG_ID) is None
    assert port.place_calls == []


@pytest.mark.asyncio
async def test_entry_exhausts_five_attempts_no_fill_is_no_trade():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_QUEUED, f"O{k}") for k in range(1, 6)]
    port.status_script = {f"O{k}": _res(bp.STATE_CANCELLED, f"O{k}") for k in range(1, 6)}
    out = await _executor(port, store, chan).run_entry(_ev(), SESSION)
    assert not out.filled and out.standdown_reason == "exhausted" and out.attempts == 5
    assert len(port.place_calls) == 5
    assert store.get(RUNG_ID) is None                          # no fill = no trade, anchor cleaned


@pytest.mark.asyncio
async def test_run_entry_risk_reject_never_places_clean_standdown():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_FILLED, "O1")]          # would fill IF it ever placed
    out = await _executor(port, store, chan,
                          risk_gate=lambda s, c, d: False).run_entry(_ev(), SESSION)
    assert not out.filled and out.standdown_reason == "risk_reject"
    assert port.place_calls == []                              # single-chokepoint: NEVER placed
    assert store.get(RUNG_ID) is None                          # clean stand-down
    assert chan.any("risk-rejected")


# ── OQ-2 WINDOW BUDGET (manager's per-symbol deadline) ─────────────────────
# run_entry calls _now_et() exactly ONCE per attempt (top of loop) — a popping
# clock advances the ladder one attempt per pop.

class _SeqClock:
    """Pops one ET datetime per _now_et() call; sticks on the last."""

    def __init__(self, *times):
        self.times = list(times)

    def __call__(self):
        return self.times.pop(0) if len(self.times) > 1 else self.times[0]


def _et(h, mi, s=0):
    return datetime(2026, 8, 10, h, mi, s, tzinfo=ET)


@pytest.mark.asyncio
async def test_entry_window_budget_exhausted_stands_down_before_placing():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    out = await _executor(port, store, chan, et_h=15, et_mi=47).run_entry(
        _ev(), SESSION, deadline=_et(15, 46))
    assert not out.filled and out.standdown_reason == "window_budget"
    assert store.get(RUNG_ID) is None                          # clean: anchor deleted
    assert port.place_calls == []                              # nothing ever placed


@pytest.mark.asyncio
async def test_entry_window_budget_mid_ladder_stands_down_clean():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_QUEUED, "O1")]
    port.status_script = {"O1": _res(bp.STATE_CANCELLED, "O1")}
    clk = _SeqClock(_et(15, 45), _et(15, 47))                  # attempt 2 finds now>deadline
    out = await _executor(port, store, chan, now_et_fn=clk).run_entry(
        _ev(), SESSION, deadline=_et(15, 46))
    assert not out.filled and out.standdown_reason == "window_budget"
    assert out.attempts == 1 and len(port.place_calls) == 1
    assert store.get(RUNG_ID) is None                          # attempt 1 confirmed dead -> clean


@pytest.mark.asyncio
async def test_entry_cutoff_wins_reason_over_window_budget():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    out = await _executor(port, store, chan, et_h=15, et_mi=59).run_entry(
        _ev(), SESSION, deadline=_et(15, 50))                  # both exceeded
    assert not out.filled and out.standdown_reason == "cutoff"  # global cutoff wins
    assert store.get(RUNG_ID) is None and port.place_calls == []


@pytest.mark.asyncio
async def test_entry_thin_budget_attempt_one_fires_and_books():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_FILLED, "O1")]
    out = await _executor(port, store, chan).run_entry(
        _ev(), SESSION, deadline=_et(15, 45, 30))              # 30s of budget at 15:45
    assert out.filled and out.credit == pytest.approx(1.18)
    assert store.get(RUNG_ID).status == RUNG_OPEN              # attempt-1 floor honored


@pytest.mark.asyncio
async def test_entry_cancel_race_fill_past_deadline_still_books():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_QUEUED, "O1")]
    port.status_script = {"O1": _res(bp.STATE_FILLED, "O1")}   # fills in the cancel race
    clk = _SeqClock(_et(15, 45), _et(15, 47))                  # wall clock passes deadline
    out = await _executor(port, store, chan, now_et_fn=clk).run_entry(
        _ev(), SESSION, deadline=_et(15, 46))
    assert out.filled                                          # deadline never recalls in-flight work
    assert store.get(RUNG_ID).status == RUNG_OPEN


@pytest.mark.asyncio
async def test_entry_unconfirmed_with_deadline_behavior_identical():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_QUEUED, "O1")]
    port.status_script = {"O1": _res(bp.STATE_QUEUED, "O1")}   # never confirms terminal
    out = await _executor(port, store, chan).run_entry(
        _ev(), SESSION, deadline=_et(15, 57))
    assert not out.filled and out.standdown_reason == "unconfirmed"
    assert store.get(RUNG_ID).status == RUNG_SUBMITTING        # anchor kept; reconcile owns
    assert len(port.place_calls) == 1                          # refused a 2nd attempt


@pytest.mark.asyncio
async def test_entry_cancel_error_with_deadline_proceeds_next_attempt():
    # cancel 404s (brokeback quirk) but the poll confirms dead -> next attempt
    # fires normally within budget; deadline changes nothing on this path.
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_QUEUED, "O1"), _res(bp.STATE_FILLED, "O2")]
    port.status_script = {"O1": _res(bp.STATE_CANCELLED, "O1")}

    async def bad_cancel(oid):
        port.cancel_calls.append(oid)
        raise RuntimeError("404 not found")

    port.cancel = bad_cancel
    out = await _executor(port, store, chan).run_entry(
        _ev(), SESSION, deadline=_et(15, 57))
    assert out.filled and out.attempts == 2
    assert port.cancel_calls == ["O1"]
    assert store.get(RUNG_ID).status == RUNG_OPEN


# ── EXIT LADDER + PT-FIRST ─────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_exit_cancels_pt_first_then_debit_ladder_fills():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _exit_quotes(port)
    rung = _open_rung(store)
    port.status_script = {"PT1": _res(bp.STATE_CANCELLED, "PT1")}
    port.place_script = [_res(bp.STATE_FILLED, "X1")]
    out = await _executor(port, store, chan).close_rung(rung, EXIT_STOP)
    assert out.closed and out.reason == EXIT_STOP
    assert out.exit_debit == pytest.approx(2.04)               # natural rounded up
    assert out.realized_pnl == pytest.approx((1.18 - 2.04) * 100.0)
    assert port.cancel_calls[0] == "PT1"                       # PT cancelled FIRST
    assert port.place_calls[0].direction == bp.DIR_DEBIT
    assert port.place_calls[0].combo_id == f"{RUNG_ID}-x1"
    assert store.get(RUNG_ID).status == RUNG_CLOSED


@pytest.mark.asyncio
async def test_exit_pt_fills_in_race_books_pt_and_stops():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _exit_quotes(port)
    rung = _open_rung(store)
    port.status_script = {"PT1": _res(bp.STATE_FILLED, "PT1")}   # PT fills during cancel-confirm
    out = await _executor(port, store, chan).close_rung(rung, EXIT_STOP)
    assert out.closed and out.pt_race and out.reason == EXIT_PT
    assert out.realized_pnl == pytest.approx((1.18 - 0.59) * 100.0)
    assert port.place_calls == []                               # NO second closing order
    r = store.get(RUNG_ID)
    assert r.status == RUNG_CLOSED and r.exit_reason == EXIT_PT


@pytest.mark.asyncio
async def test_exit_aborts_when_pt_cancel_not_confirmed():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _exit_quotes(port)
    rung = _open_rung(store)
    port.status_script = {"PT1": _res(bp.STATE_QUEUED, "PT1")}   # never confirms cancelled
    out = await _executor(port, store, chan).close_rung(rung, EXIT_STOP)
    assert out.aborted and not out.closed
    assert port.place_calls == []                               # refused to double-close
    assert store.get(RUNG_ID).status == RUNG_OPEN               # unchanged; retry next tick
    assert chan.any("URGENT") and chan.any("EXIT ABORTED")


@pytest.mark.asyncio
async def test_fake_cancel_guard_requires_terminal_readback():
    # FAKE-CANCEL GUARD: port.cancel "succeeds" (returns normally, no exception) but
    # the PT never reads back terminal -> execution must NOT believe the cancellation:
    # it issues the cancel REQUEST, then refuses to place any closing order and leaves
    # the rung untouched. The truth is the terminal read-back, never the cancel call.
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _exit_quotes(port)
    rung = _open_rung(store)
    port.status_script = {"PT1": _res(bp.STATE_QUEUED, "PT1")}   # cancel returns; never terminal
    out = await _executor(port, store, chan).close_rung(rung, EXIT_STOP)
    assert "PT1" in port.cancel_calls          # the cancel REQUEST was issued...
    assert out.aborted and not out.closed       # ...but the cancellation was NOT believed
    assert port.place_calls == []               # no closing order placed against a maybe-live PT
    assert store.get(RUNG_ID).status == RUNG_OPEN


@pytest.mark.asyncio
async def test_exit_ladder_exhausted_stays_closing_urgent():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _exit_quotes(port)
    rung = _open_rung(store)
    port.status_script = {"PT1": _res(bp.STATE_CANCELLED, "PT1")}
    port.place_script = [_res(bp.STATE_QUEUED, f"X{k}") for k in range(1, 6)]
    for k in range(1, 6):
        port.status_script[f"X{k}"] = _res(bp.STATE_CANCELLED, f"X{k}")
    out = await _executor(port, store, chan).close_rung(rung, EXIT_STOP)
    assert out.exhausted and not out.closed and out.attempts == 5
    assert store.get(RUNG_ID).status == RUNG_CLOSING           # stays CLOSING (manual backstop)
    assert chan.any("URGENT") and chan.any("EXIT UNFILLED")


@pytest.mark.asyncio
async def test_exit_exception_never_books_stays_closing():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _exit_quotes(port)
    rung = _open_rung(store)
    port.status_script = {"PT1": _res(bp.STATE_CANCELLED, "PT1")}
    port.place_script = [RuntimeError("submit failed")]
    out = await _executor(port, store, chan).close_rung(rung, EXIT_STOP)
    assert out.exhausted and not out.closed
    r = store.get(RUNG_ID)
    assert r.status == RUNG_CLOSING and r.realized_pnl is None


@pytest.mark.asyncio
async def test_exit_debit_never_exceeds_width_ceiling():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    # natural blown out beyond the width -> limit clamps to width*1.00 = 3.00
    port.quotes = {
        ("put", 585.0): OptionQuote("SPY", EXPIRY, 585.0, "put", 3.40, 3.50, -0.9),
        ("put", 582.0): OptionQuote("SPY", EXPIRY, 582.0, "put", 0.02, 0.04, -0.6),
        ("call", 615.0): OptionQuote("SPY", EXPIRY, 615.0, "call", 0.02, 0.04, 0.1),
        ("call", 618.0): OptionQuote("SPY", EXPIRY, 618.0, "call", 0.01, 0.03, 0.05),
    }  # natural = (3.50+0.04)-(0.02+0.01)=3.51 > ceiling 3.00
    rung = _open_rung(store)
    port.status_script = {"PT1": _res(bp.STATE_CANCELLED, "PT1")}
    port.place_script = [_res(bp.STATE_FILLED, "X1")]
    await _executor(port, store, chan).close_rung(rung, EXIT_STOP)
    assert port.place_calls[0].net_limit == pytest.approx(3.00)   # clamped to width ceiling


# ── RECONCILE STATE MACHINE ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_reconcile_pt_fill_books_exit():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _open_rung(store)
    port.status_script = {"PT1": _res(bp.STATE_FILLED, "PT1")}
    await _executor(port, store, chan).reconcile(SESSION)
    r = store.get(RUNG_ID)
    assert r.status == RUNG_CLOSED and r.exit_reason == EXIT_PT
    assert r.realized_pnl == pytest.approx((1.18 - 0.59) * 100.0)
    assert chan.any("MACE EXIT")


@pytest.mark.asyncio
async def test_reconcile_pt_unexpectedly_dead_replaces():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _open_rung(store)
    port.status_script = {"PT1": _res(bp.STATE_CANCELLED, "PT1")}
    await _executor(port, store, chan).reconcile(SESSION)
    r = store.get(RUNG_ID)
    assert r.status == RUNG_OPEN and r.pt_order_id == "PT-1"    # re-placed
    assert chan.any("re-placing")


@pytest.mark.asyncio
async def test_reconcile_open_rung_missing_pt_gets_one():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _open_rung(store, pt=None)                                   # open, no resting PT
    await _executor(port, store, chan).reconcile(SESSION)
    assert store.get(RUNG_ID).pt_order_id == "PT-1"


@pytest.mark.asyncio
async def test_reconcile_drains_submitting_fill_to_open():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    # crash left a submitting anchor with a persisted broker id + credit basis
    store.insert_submitting(RUNG_ID, SPEC, 1, entry_ts="2026-08-10T19:40:00+00:00",
                            entry_iso_week=ISO_WK, max_risk_usd=182.0)
    store.set_pending_credit(RUNG_ID, 1.16)
    store.set_entry_order(RUNG_ID, "O3")
    port.status_script = {"O3": _res(bp.STATE_FILLED, "O3")}
    port.open_orders_ret = []
    await _executor(port, store, chan).reconcile(SESSION)
    r = store.get(RUNG_ID)
    assert r.status == RUNG_OPEN and r.credit_actual == pytest.approx(1.16)
    assert r.pt_order_id == "PT-1"                              # PT placed on promote
    assert chan.any("MACE ENTRY")


@pytest.mark.asyncio
async def test_reconcile_matches_submitting_by_combo_id_prefix():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    store.insert_submitting(RUNG_ID, SPEC, 1, entry_ts="2026-08-10T19:40:00+00:00",
                            entry_iso_week=ISO_WK, max_risk_usd=182.0)
    store.set_pending_credit(RUNG_ID, 1.16)
    # no persisted broker id (place-raised window); reconcile matches by ref prefix
    port.open_orders_ret = [OpenOrder(order_id="OB", state="queued",
                                      ref_id=f"{RUNG_ID}-a1")]
    port.status_script = {"OB": _res(bp.STATE_FILLED, "OB")}
    await _executor(port, store, chan).reconcile(SESSION)
    assert store.get(RUNG_ID).status == RUNG_OPEN


@pytest.mark.asyncio
async def test_reconcile_abandons_submitting_past_horizon():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    store.insert_submitting(RUNG_ID, SPEC, 1, entry_ts="2026-08-03T14:00:00+00:00",  # 5 sessions ago
                            entry_iso_week="2026-W32", max_risk_usd=182.0)
    store.set_entry_order(RUNG_ID, "Odead")
    port.status_script = {"Odead": _res(bp.STATE_CANCELLED, "Odead")}
    port.open_orders_ret = []
    await _executor(port, store, chan).reconcile(SESSION)
    assert store.get(RUNG_ID).status == RUNG_ABANDONED
    assert chan.any("abandoned")


@pytest.mark.asyncio
async def test_reconcile_leaves_submitting_within_horizon():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    store.insert_submitting(RUNG_ID, SPEC, 1, entry_ts="2026-08-10T14:00:00+00:00",  # today
                            entry_iso_week=ISO_WK, max_risk_usd=182.0)
    store.set_entry_order(RUNG_ID, "Odead")
    port.status_script = {"Odead": _res(bp.STATE_CANCELLED, "Odead")}
    port.open_orders_ret = []
    await _executor(port, store, chan).reconcile(SESSION)
    assert store.get(RUNG_ID).status == RUNG_SUBMITTING        # within horizon -> leave


@pytest.mark.asyncio
async def test_reconcile_status_error_never_books_and_leaves_anchor():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    store.insert_submitting(RUNG_ID, SPEC, 1, entry_ts="2026-08-03T14:00:00+00:00",
                            entry_iso_week="2026-W32", max_risk_usd=182.0)
    store.set_entry_order(RUNG_ID, "Oerr")
    port.status_script = {"Oerr": RuntimeError("status api down")}  # unknown -> in-flight (safe)
    port.open_orders_ret = []
    await _executor(port, store, chan).reconcile(SESSION)
    # even past horizon, an unconfirmable order is treated as in-flight -> NOT abandoned
    assert store.get(RUNG_ID).status == RUNG_SUBMITTING


# ── tick rounding (marketability direction) ────────────────────────────────

def test_round_to_tick_directions():
    assert ex.round_to_tick(1.184, 0.01, "down") == pytest.approx(1.18)  # credit floors down
    assert ex.round_to_tick(2.031, 0.01, "up") == pytest.approx(2.04)    # debit ceilings up
    assert ex.round_to_tick(0.595, 0.01, "nearest") == pytest.approx(0.60)


# ── T9 SYNTHETIC PROFIT TARGET (production default: resting_pt=False) ─────────
# Board ruling 2026-08-10 (go-live on the T9 basis): NO resting-GTC PT order — the
# manage loop closes when mark <= pt_debit. The resting-GTC path stays a tested
# seam (the lifecycle tests above default resting_pt=True); these assert the DEFAULT.

def test_executor_default_pt_is_synthetic():
    conn = _conn()
    e = ex.MaceExecutor(CFG, FakePort(), ex.RungStore(conn),
                        MaceNotifier(enabled=False), risk_gate=lambda s, c, d: True)
    assert e._resting_pt is False        # go-live default = T9 synthetic (no resting order)


@pytest.mark.asyncio
async def test_t9_entry_records_synthetic_pt_no_resting_order():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _entry_quotes(port)
    port.place_script = [_res(bp.STATE_FILLED, "O1")]
    out = await _executor(port, store, chan, resting_pt=False).run_entry(_ev(), SESSION)
    assert out.filled
    r = store.get(RUNG_ID)
    assert r.status == RUNG_OPEN
    assert r.pt_debit == pytest.approx(0.59)     # target recorded (0.5 x 1.18)
    assert r.pt_order_id is None                  # NO resting order placed
    assert port.resting_calls == []              # place_resting_close never called


@pytest.mark.asyncio
async def test_t9_reconcile_open_no_pt_is_noop():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _open_rung(store, pt=None)                    # open, no resting PT — the T9 norm
    await _executor(port, store, chan, resting_pt=False).reconcile(SESSION)
    r = store.get(RUNG_ID)
    assert r.status == RUNG_OPEN and r.pt_order_id is None   # NOT re-placed
    assert port.resting_calls == []


@pytest.mark.asyncio
async def test_t9_drain_promote_records_synthetic_target():
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    store.insert_submitting(RUNG_ID, SPEC, 1, entry_ts="2026-08-10T19:40:00+00:00",
                            entry_iso_week=ISO_WK, max_risk_usd=182.0)
    store.set_pending_credit(RUNG_ID, 1.16)
    store.set_entry_order(RUNG_ID, "O3")
    port.status_script = {"O3": _res(bp.STATE_FILLED, "O3")}
    port.open_orders_ret = []
    await _executor(port, store, chan, resting_pt=False).reconcile(SESSION)
    r = store.get(RUNG_ID)
    assert r.status == RUNG_OPEN and r.credit_actual == pytest.approx(1.16)
    assert r.pt_order_id is None and r.pt_debit == pytest.approx(0.58)  # 0.5 x 1.16
    assert port.resting_calls == []


@pytest.mark.asyncio
async def test_t9_close_rung_pt_reason_no_resting_to_cancel():
    # A synthetic-PT close: the rung has NO resting pt_order_id, so close_rung SKIPS
    # the cancel-PT block entirely and books the debit ladder with reason `pt`.
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _exit_quotes(port)
    rung = _open_rung(store, pt=None, pt_debit=0.59)     # T9: target set, no order
    port.place_script = [_res(bp.STATE_FILLED, "X1")]
    out = await _executor(port, store, chan, resting_pt=False).close_rung(rung, EXIT_PT)
    assert out.closed and out.reason == EXIT_PT
    assert port.cancel_calls == []                        # no resting PT to cancel
    r = store.get(RUNG_ID)
    assert r.status == RUNG_CLOSED and r.exit_reason == EXIT_PT


# ── GDX P1: winner (TIME/PT) mid-band cap + defer; STOP unchanged (2026-09-11) ──────

def _gdx_wide_quotes(port: FakePort):
    """Wide-spread (illiquid GDX-style) condor on SPEC's strikes: credit_mid = 1.05,
    natural = 1.54 (spread 0.49 >> the 0.10 winner band). A winner close caps at
    mid+band = 1.15 and can NOT reach natural -> it defers (never gives back the spread)."""
    port.quotes = {
        ("put", 585.0): OptionQuote("SPY", EXPIRY, 585.0, "put", 1.10, 1.70, -0.55),   # mid 1.40
        ("put", 582.0): OptionQuote("SPY", EXPIRY, 582.0, "put", 0.30, 0.50, -0.30),   # mid 0.40
        ("call", 615.0): OptionQuote("SPY", EXPIRY, 615.0, "call", 0.05, 0.15, 0.10),  # mid 0.10
        ("call", 618.0): OptionQuote("SPY", EXPIRY, 618.0, "call", 0.01, 0.09, 0.05),  # mid 0.05
    }  # mid=(1.40+0.10)-(0.40+0.05)=1.05 ; natural=(1.70+0.15)-(0.30+0.01)=1.54


@pytest.mark.asyncio
async def test_time_winner_starts_at_mid_caps_at_band_and_defers():
    """TIME winner: starts at MID (1.05), walks only to mid+band (1.15), NEVER crosses to
    natural (1.54); unfillable within the band -> DEFER, rung stays OPEN (the GDX P1)."""
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _gdx_wide_quotes(port)
    rung = _open_rung(store, credit=1.58, pt=None)         # T9 synthetic: pt_order_id NULL
    port.place_script = [_res(bp.STATE_QUEUED, f"X{k}") for k in range(1, 6)]
    for k in range(1, 6):
        port.status_script[f"X{k}"] = _res(bp.STATE_CANCELLED, f"X{k}")
    out = await _executor(port, store, chan, resting_pt=False).close_rung(
        rung, EXIT_TIME, pricing="winner", defer_on_unfilled=True)
    assert out.deferred and not out.closed and not out.exhausted
    limits = [c.net_limit for c in port.place_calls]
    assert limits[0] == pytest.approx(1.05)               # STARTS at mid, not natural 1.54
    assert max(limits) <= 1.15 + 1e-9                     # capped at mid+band (0.10)
    assert all(l < 1.54 for l in limits)                  # never crosses to natural
    assert store.get(RUNG_ID).status == RUNG_OPEN         # DEFER keeps the rung OPEN


@pytest.mark.asyncio
async def test_time_winner_fills_within_band_preserves_profit_gdx_replay():
    """Replay GDX #1 (credit 1.58, mid 1.05): a fill at the mid+band CAP (1.15) books
    +$43 -- vs the actual +$6 today when it crossed to natural 1.52/1.67."""
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _gdx_wide_quotes(port)
    rung = _open_rung(store, credit=1.58, pt=None)
    port.place_script = ([_res(bp.STATE_QUEUED, f"X{k}") for k in range(1, 5)]
                         + [_res(bp.STATE_FILLED, "X5")])   # fills on the attempt at the cap
    for k in range(1, 5):
        port.status_script[f"X{k}"] = _res(bp.STATE_CANCELLED, f"X{k}")
    out = await _executor(port, store, chan, resting_pt=False).close_rung(
        rung, EXIT_TIME, pricing="winner", defer_on_unfilled=True)
    assert out.closed and out.reason == EXIT_TIME
    assert out.exit_debit == pytest.approx(1.15)          # filled AT the cap, not natural 1.54
    assert out.realized_pnl == pytest.approx((1.58 - 1.15) * 100)   # = +43.00 (vs actual +6)
    assert store.get(RUNG_ID).status == RUNG_CLOSED


@pytest.mark.asyncio
async def test_stop_unchanged_starts_at_natural_band_not_applied():
    """STOP: pricing defaults marketable -> starts at NATURAL (1.54), band NOT applied
    (a loser must fill). Contrast: a winner would have capped at 1.15."""
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _gdx_wide_quotes(port)
    rung = _open_rung(store, credit=1.58, pt=None)
    port.place_script = [_res(bp.STATE_FILLED, "X1")]
    out = await _executor(port, store, chan, resting_pt=False).close_rung(rung, EXIT_STOP)
    assert out.closed and out.reason == EXIT_STOP
    assert out.exit_debit == pytest.approx(1.54)          # NATURAL (cross-spread), not mid 1.05
    assert store.get(RUNG_ID).status == RUNG_CLOSED


@pytest.mark.asyncio
async def test_pt_winner_defers_if_unfilled_no_floor():
    """PT winner: same mid-band cap; unfillable -> DEFER, rung stays OPEN (a winner is fine
    to keep; PT has no DTE floor and retries next tick)."""
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _gdx_wide_quotes(port)
    rung = _open_rung(store, credit=1.58, pt=None)
    port.place_script = [_res(bp.STATE_QUEUED, f"X{k}") for k in range(1, 6)]
    for k in range(1, 6):
        port.status_script[f"X{k}"] = _res(bp.STATE_CANCELLED, f"X{k}")
    out = await _executor(port, store, chan, resting_pt=False).close_rung(
        rung, EXIT_PT, pricing="winner", defer_on_unfilled=True)
    assert out.deferred and store.get(RUNG_ID).status == RUNG_OPEN
    assert max(c.net_limit for c in port.place_calls) <= 1.15 + 1e-9


@pytest.mark.asyncio
async def test_spy_winner_unaffected_natural_within_band():
    """SPY (tight): natural 2.04 is INSIDE mid+band (mid 1.95, cap 2.05) -> the winner ladder
    reaches ~natural and FILLS (does not defer). SPY behaves as before."""
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    _exit_quotes(port)                                    # SPY mid 1.95, natural 2.04
    rung = _open_rung(store, credit=2.20, pt=None)
    port.place_script = ([_res(bp.STATE_QUEUED, f"X{k}") for k in range(1, 5)]
                         + [_res(bp.STATE_FILLED, "X5")])
    for k in range(1, 5):
        port.status_script[f"X{k}"] = _res(bp.STATE_CANCELLED, f"X{k}")
    out = await _executor(port, store, chan, resting_pt=False).close_rung(
        rung, EXIT_TIME, pricing="winner", defer_on_unfilled=True)
    assert out.closed and not out.deferred               # FILLS (natural within band), no defer
    assert out.exit_debit <= 2.05 + 1e-9                  # within mid+band ~= natural


def test_close_pricing_routing_time_floor_pt_stop():
    """Manager routing: TIME>floor -> winner+defer; TIME<=floor -> FORCE marketable;
    PT -> winner+defer (no floor); STOP/exdiv -> marketable (unchanged)."""
    conn = _conn(); store = ex.RungStore(conn); port = FakePort(); chan = RecChannel()
    ex_ = _executor(port, store, chan, resting_pt=False)
    mgr = MaceManager(CFG, port, store, ex_, MaceNotifier(channel=chan, enabled=True))
    rung = _open_rung(store, pt=None)                     # expiry 2026-09-18
    hi = datetime(2026, 8, 28, 15, 30, tzinfo=ET)         # dte 21 (> 14 floor)
    at = datetime(2026, 9, 4, 15, 30, tzinfo=ET)          # dte 14 (== floor)
    lo = datetime(2026, 9, 10, 15, 30, tzinfo=ET)         # dte 8  (< floor)
    assert mgr._close_pricing(EXIT_TIME, rung, hi) == ("winner", True)
    assert mgr._close_pricing(EXIT_TIME, rung, at) == ("marketable", False)   # floor forces
    assert mgr._close_pricing(EXIT_TIME, rung, lo) == ("marketable", False)
    assert mgr._close_pricing(EXIT_PT, rung, lo) == ("winner", True)          # PT: no floor
    assert mgr._close_pricing(EXIT_STOP, rung, hi) == ("marketable", False)
    assert mgr._close_pricing(EXIT_EXDIV, rung, hi) == ("marketable", False)
